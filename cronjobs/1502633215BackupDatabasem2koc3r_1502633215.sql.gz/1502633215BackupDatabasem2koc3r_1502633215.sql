-- [MySQL -  Database Backup] Created time: 13/08/2017 - 21:06:55

-- Host: localhost
-- Server version: 5.6.26
-- Collation: utf8_unicode_ci
-- Time zone: SE Asia Standard Time

-- Database: dnw_calendar


CREATE TABLE `olala3w_agency` (
  `agency_id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(5) NOT NULL DEFAULT '-no-',
  `symbol` varchar(10) NOT NULL DEFAULT '-no-',
  `name` varchar(255) NOT NULL,
  `img` varchar(255) NOT NULL DEFAULT 'no',
  `address` varchar(255) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `email` varchar(255) NOT NULL,
  `parent` int(11) NOT NULL DEFAULT '0',
  `sort` int(11) NOT NULL DEFAULT '1',
  `is_active` int(1) NOT NULL DEFAULT '1',
  `created_time` int(11) NOT NULL DEFAULT '0',
  `modified_time` int(11) NOT NULL DEFAULT '0',
  `user_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`agency_id`),
  UNIQUE KEY `symbol` (`symbol`)
) ENGINE=InnoDB AUTO_INCREMENT=65 DEFAULT CHARSET=utf8;

INSERT INTO olala3w_agency VALUES('30','-no-','ndn','Công ty CP Đầu tư Phát triển Nhà Đà Nẵng','ndn_84a6a33205ac72647d2fd9440868994f.jpg','38 Nguyễn Chí Thanh, P. Thạch Thang, Q. Hải Châu, Tp. Đà Nẵng','(0511) 3872.213','info@ndn.com.vn','0','1','1','1472208835','1472208835','2');
INSERT INTO olala3w_agency VALUES('51','-no-','ptc','Phòng Tài Chính','no','38 Nguyễn Chí Thanh','','','30','1','1','1468806588','1468813778','1');
INSERT INTO olala3w_agency VALUES('53','-no-','pth','Phòng Tổng Hợp','no','38 Nguyễn Chí Thanh','','','30','2','1','1468806641','1468813778','1');
INSERT INTO olala3w_agency VALUES('55','-no-','pkt','Phòng Kỹ Thuật','no','38 Nguyễn Chí Thanh','','','30','4','1','1468806699','1468902654','1');
INSERT INTO olala3w_agency VALUES('56','-no-','pct','Phòng Công Trình','no','38 Nguyễn Chí Thanh','','','30','3','1','1468806729','1468813793','1');
INSERT INTO olala3w_agency VALUES('57','-no-','dnsc','Công ty CP Chứng Khoán Đà Nẵng','dnsc_e6dd373d60c76f5dc79d766dce74826b.jpg','102 Nguyễn Thị Minh Khai','0511 3 888456','info@dnsc.com.vn','0','1','1','1472208870','1472208870','2');
INSERT INTO olala3w_agency VALUES('58','-no-','mg','Phòng Môi Giới','no','102 Nguyễn Thị Minh Khai','0511 3888858','','57','3','1','1471425435','1474428951','1');
INSERT INTO olala3w_agency VALUES('59','-no-','kt','Phòng Kế Toán','no','102, Nguyễn Thị Minh Khai, Đà Nẵng','','','57','2','1','1471425481','1471425481','1');
INSERT INTO olala3w_agency VALUES('61','-no-','ndx','Công ty CP Xây lắp Phát triển Nhà Đà Nẵng','ndx_f4a8dd9d755e7be914c07272a2a65804.jpg','31 Núi Thành, Phường Hòa Thuận Đông, Quận Hải Châu, TP Đà Nẵng','0511 3 631 157','info@ndx.com.vn','0','3','1','1472209296','1472209296','2');
INSERT INTO olala3w_agency VALUES('62','-no-','tsm','Công ty Cp Đầu tư Tia Sáng Mới','tsm_e2d12a0edd01ed656a6d19b322a411dd.jpg','31 Núi Thành, P.Hòa Thuận Đông, Q.Hải Châu, TP Đà Nẵng','0511 3 634 988','info@tsm.net.vn','0','4','1','1472208961','1472208961','2');
INSERT INTO olala3w_agency VALUES('63','-no-','bgd','Ban Giám Đốc','no','102 Nguyễn Thị Minh khai','','','57','1','1','1472453759','1474534046','1');
INSERT INTO olala3w_agency VALUES('64','-no-','bqlm','BQL KHU PHỨC HỢP MONARCHY','no','Trần Hưng Đạo','','','30','5','1','1474258387','1474258387','1');

-- --------------------------------------------------------

CREATE TABLE `olala3w_calendar` (
  `calendar_id` int(11) NOT NULL AUTO_INCREMENT,
  `type` int(1) NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL,
  `level` int(11) NOT NULL DEFAULT '0',
  `to_personal` text NOT NULL,
  `to_role` text NOT NULL,
  `to_agency` text NOT NULL,
  `to_matches` int(11) NOT NULL DEFAULT '0',
  `address` varchar(255) NOT NULL,
  `start_time` int(11) NOT NULL DEFAULT '0',
  `end_time` int(11) NOT NULL DEFAULT '0',
  `supervisor` int(11) NOT NULL DEFAULT '0',
  `supervisor_matches` int(11) NOT NULL DEFAULT '0',
  `file` varchar(255) NOT NULL DEFAULT '-no-',
  `note` text NOT NULL,
  `report_result` varchar(255) NOT NULL,
  `report_time` int(11) NOT NULL DEFAULT '0',
  `report_file` varchar(255) NOT NULL DEFAULT '-no-',
  `report_note` text NOT NULL,
  `report_user` int(11) NOT NULL DEFAULT '0',
  `is_active` int(1) NOT NULL DEFAULT '1',
  `status` int(1) NOT NULL DEFAULT '0',
  `disable` int(1) NOT NULL DEFAULT '0',
  `created_time` int(11) NOT NULL DEFAULT '0',
  `modified_time` int(11) NOT NULL DEFAULT '0',
  `user_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`calendar_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

INSERT INTO olala3w_calendar VALUES('1','1','Lao công nhé','2','1','','','0','Đà Nẵng','1502424000','1504411200','0','0','Personal_1501555792_lao-cong-nhe.jpg','Hảy chú ý đến lịch trình nhé ban','','0','-no-','','0','1','1','0','1501555740','1501555740','1');
INSERT INTO olala3w_calendar VALUES('2','1','Tìm hiểu các BC hiện có, cách thức kiểm tra','1','85','','','0','Đà Nẵng','1502161200','1502251200','0','0','-no-','Hảy sớm hoàn thành nhanh công việc này nhé ','','1502160300','-no-','Đã hoàn thành công việc được giao trước hạn đinh','85','1','1','0','1502160240','1502160300','85');
INSERT INTO olala3w_calendar VALUES('3','1','Tìm hiểu các BC hiện có, cách thức kiểm tra','1','85','','','0','Đà Nẵng','1502161200','1502251200','0','0','-no-','Hảy sớm hoàn thành nhanh công việc này nhé ','','0','-no-','','0','1','0','0','1502160240','1502160240','85');
INSERT INTO olala3w_calendar VALUES('4','1','Làm việc tại văn phòng','3','85','','','0','111 Đinh Núp, Phường An Khê, Quận Thanh Khê, Tp Đà Nẵng','1502246760','1502341200','0','0','-no-','Nhanh chóng thực hiện nhé ','','0','-no-','','0','1','0','1','1502160420','1502160420','85');
INSERT INTO olala3w_calendar VALUES('5','1','Dán nhãn sắp xếp hồ sơ','1','85','','','0','dại lý xe ford','1502157600','1502247600','0','0','-no-','dưqdwq','','0','-no-','','0','1','0','0','1502160540','1502160540','85');
INSERT INTO olala3w_calendar VALUES('6','1','DK KQKD Q3.2016','1','85','','','0','Ngân hàng','1501642140','1501901340','0','0','-no-','Đã trể ngày làm việc nhé','','0','-no-','','0','1','0','0','1502160660','1502160600','85');

-- --------------------------------------------------------

CREATE TABLE `olala3w_calendar_extend` (
  `calendar_extend_id` int(11) NOT NULL AUTO_INCREMENT,
  `calendar` int(11) NOT NULL DEFAULT '0',
  `propose_time` int(11) NOT NULL DEFAULT '0',
  `file` varchar(255) NOT NULL DEFAULT '-no-',
  `note` text NOT NULL,
  `propose_user` int(11) NOT NULL DEFAULT '0',
  `status` int(1) NOT NULL DEFAULT '0',
  `extend_time` int(11) NOT NULL DEFAULT '0',
  `request` text NOT NULL,
  `matches` int(11) NOT NULL DEFAULT '0',
  `supervisor_matches` int(11) NOT NULL DEFAULT '0',
  `handlers_user` int(11) NOT NULL DEFAULT '0',
  `complete` int(1) NOT NULL DEFAULT '0',
  `created_time` int(11) NOT NULL DEFAULT '0',
  `modified_time` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`calendar_extend_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO olala3w_calendar_extend VALUES('1','6','1502160600','-no-','Qúa Bận Trong Triển Khai Công Việc','85','0','0','','0','0','0','0','1502160600','0');

-- --------------------------------------------------------

CREATE TABLE `olala3w_calendar_user` (
  `calendar_user_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `calendar` int(11) NOT NULL DEFAULT '0',
  `user_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`calendar_user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

INSERT INTO olala3w_calendar_user VALUES('1','1','1');
INSERT INTO olala3w_calendar_user VALUES('2','2','85');
INSERT INTO olala3w_calendar_user VALUES('3','3','85');
INSERT INTO olala3w_calendar_user VALUES('4','4','85');
INSERT INTO olala3w_calendar_user VALUES('5','5','85');
INSERT INTO olala3w_calendar_user VALUES('6','6','85');
INSERT INTO olala3w_calendar_user VALUES('7','7','1');

-- --------------------------------------------------------

CREATE TABLE `olala3w_category` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `type_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `slug` varchar(30) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `keywords` text NOT NULL,
  `comment` text NOT NULL,
  `is_active` int(1) NOT NULL DEFAULT '1',
  `hot` int(1) NOT NULL DEFAULT '0',
  `sort` int(11) NOT NULL DEFAULT '1',
  `sort_hide` int(11) NOT NULL DEFAULT '1',
  `img` varchar(255) NOT NULL DEFAULT 'no',
  `icon` varchar(255) NOT NULL,
  `menu_main` int(1) NOT NULL DEFAULT '0',
  `menu_sm` int(1) NOT NULL DEFAULT '0',
  `created_time` int(11) NOT NULL DEFAULT '0',
  `modified_time` int(11) NOT NULL DEFAULT '0',
  `user_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`category_id`)
) ENGINE=MyISAM AUTO_INCREMENT=54 DEFAULT CHARSET=utf8;


-- --------------------------------------------------------

CREATE TABLE `olala3w_category_type` (
  `type_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `slug` varchar(30) NOT NULL,
  `sort` int(11) NOT NULL DEFAULT '1',
  `is_active` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`type_id`)
) ENGINE=MyISAM AUTO_INCREMENT=20 DEFAULT CHARSET=utf8;

INSERT INTO olala3w_category_type VALUES('1','Bài viết','article_manager','1','1');
INSERT INTO olala3w_category_type VALUES('2','Hình ảnh','gallery_manager','2','1');
INSERT INTO olala3w_category_type VALUES('7','Email đămg ký','register_email','0','0');
INSERT INTO olala3w_category_type VALUES('6','Sàn giao dịch','product_manager','4','1');
INSERT INTO olala3w_category_type VALUES('8','Đặt mua hàng','order_list','0','0');
INSERT INTO olala3w_category_type VALUES('9','Tour du lịch','tour_manager','0','0');
INSERT INTO olala3w_category_type VALUES('10','Đồ lưu niệm','gift_manager','0','0');
INSERT INTO olala3w_category_type VALUES('11','Thuê xe','car_manager','0','0');
INSERT INTO olala3w_category_type VALUES('12','Vị trí địa lý','location_manager','6','1');
INSERT INTO olala3w_category_type VALUES('13','Dữ liệu đường phố','street_manager','8','1');
INSERT INTO olala3w_category_type VALUES('14','Dữ liệu phương hướng','direction_manager','9','1');
INSERT INTO olala3w_category_type VALUES('15','Dữ liệu khác','others_manager','11','1');
INSERT INTO olala3w_category_type VALUES('16','Chiều rộng đường','road_manager','7','1');
INSERT INTO olala3w_category_type VALUES('17','Dự án','project_manager','3','1');
INSERT INTO olala3w_category_type VALUES('18','BĐS kinh doanh','bds_business_manager','5','0');
INSERT INTO olala3w_category_type VALUES('19','Dữ liệu tên dự án','prjname_manager','10','1');

-- --------------------------------------------------------

CREATE TABLE `olala3w_constant` (
  `constant_id` int(11) NOT NULL AUTO_INCREMENT,
  `constant` varchar(50) NOT NULL,
  `value` text NOT NULL,
  `name` varchar(255) NOT NULL,
  `type` int(2) NOT NULL DEFAULT '0',
  `sort` int(11) NOT NULL,
  PRIMARY KEY (`constant_id`),
  UNIQUE KEY `constant` (`constant`)
) ENGINE=MyISAM AUTO_INCREMENT=110 DEFAULT CHARSET=utf8;

INSERT INTO olala3w_constant VALUES('1','date','d/m/Y','Kiểu hiển thị ngày tháng năm','3','1');
INSERT INTO olala3w_constant VALUES('2','time','H:i','Kiểu hiển thị giờ phút','3','2');
INSERT INTO olala3w_constant VALUES('3','timezone','Asia/Bangkok','Múi giờ','3','4');
INSERT INTO olala3w_constant VALUES('4','title','Công ty CP Đầu tư Phát triển Nhà Đà Nẵng','Meta title (home)','0','1');
INSERT INTO olala3w_constant VALUES('5','description','Công ty CP Đầu tư Phát triển Nhà Đà Nẵng','Meta description (home)','0','2');
INSERT INTO olala3w_constant VALUES('6','keywords','Công ty CP Đầu tư Phát triển Nhà Đà Nẵng','Meta keywords (home)','0','3');
INSERT INTO olala3w_constant VALUES('74','script_body','','Script sau body','4','6');
INSERT INTO olala3w_constant VALUES('86','website','www.ndn.com.vn','Website','0','8');
INSERT INTO olala3w_constant VALUES('76','link_linkedin','https://www.linkedin.com/','LinkedIn','5','5');
INSERT INTO olala3w_constant VALUES('7','email_contact','info@ndn.com.vn','E-mail liên hệ','0','5');
INSERT INTO olala3w_constant VALUES('8','tell_contact','05113 872.212','Điện thoại','0','7');
INSERT INTO olala3w_constant VALUES('9','fulldate','D, d/m/Y - H:i','Kiểu hiển ngày đầy đủ','3','3');
INSERT INTO olala3w_constant VALUES('10','SMTP_username','mail.danaweb@gmail.com','Tài khoản email','1','0');
INSERT INTO olala3w_constant VALUES('11','SMTP_password','123456987abc','Mật khẩu email','1','0');
INSERT INTO olala3w_constant VALUES('12','error_page','<p>Vì lý do kỹ&nbsp;thuật website tạm ngưng&nbsp;hoạt động. Thành thật xin lỗi các bạn&nbsp;vì sự bất tiện này!</p>\r\n','Thông báo ngừng hoạt động','0','19');
INSERT INTO olala3w_constant VALUES('13','file_logo','/uploads/files/logo.png','Logo front-end','0','4');
INSERT INTO olala3w_constant VALUES('14','SMTP_secure','ssl','Sử dụng xác thực','1','0');
INSERT INTO olala3w_constant VALUES('15','SMTP_host','smtp.gmail.com','Máy chủ (SMTP) Thư gửi đi','1','0');
INSERT INTO olala3w_constant VALUES('16','SMTP_port','465','Cổng gửi mail','1','0');
INSERT INTO olala3w_constant VALUES('17','backup_auto','','Tự động sao lưu','2','0');
INSERT INTO olala3w_constant VALUES('18','backup_filetype','sql.gz','Định dạng lưu file CSDL','2','0');
INSERT INTO olala3w_constant VALUES('19','backup_filecount','30','Số file CSDL lưu lại','2','0');
INSERT INTO olala3w_constant VALUES('20','backup_email','ng.quangphuc@gmail.com','Email nhận thông báo và file','2','0');
INSERT INTO olala3w_constant VALUES('21','SMTP_mailname','NDN','Tên tài khoản email','1','0');
INSERT INTO olala3w_constant VALUES('22','link_facebook','https://www.facebook.com/','Facebook','5','1');
INSERT INTO olala3w_constant VALUES('23','link_googleplus','https://plus.google.com/','Google+','5','2');
INSERT INTO olala3w_constant VALUES('24','link_twitter','https://twitter.com/','Twitter','5','3');
INSERT INTO olala3w_constant VALUES('25','address_contact','38 Nguyễn Chí Thanh, P. Thạch Thang, Q. Hải Châu, Tp. Đà Nẵng','Địa chỉ','0','6');
INSERT INTO olala3w_constant VALUES('73','script_bottom','','Script cuối trang','4','7');
INSERT INTO olala3w_constant VALUES('26','content_registertry','','Email đăng ký học thử','13','17');
INSERT INTO olala3w_constant VALUES('27','author_google','','ID profile Google+','4','1');
INSERT INTO olala3w_constant VALUES('28','google_analytics','','Analytics','4','4');
INSERT INTO olala3w_constant VALUES('29','chat_online','','Script Chat Online','4','5');
INSERT INTO olala3w_constant VALUES('30','english_test','','Kiểm tra tiếng Anh của bạn','13','18');
INSERT INTO olala3w_constant VALUES('31','google_calendar','','Google Calendar (Account)','4','3');
INSERT INTO olala3w_constant VALUES('32','help_address','','Tư vấn - Địa chỉ','13','8');
INSERT INTO olala3w_constant VALUES('33','help_icon','','Tư vấn - Icon','13','9');
INSERT INTO olala3w_constant VALUES('34','link_youtube','https://www.youtube.com/','Youtube','5','4');
INSERT INTO olala3w_constant VALUES('101','regulation','<p>Đang cập nhật...</p>\r\n','Quy định chung','7','2');
INSERT INTO olala3w_constant VALUES('102','tutorial','<p>Đang cập nhật...</p>\r\n','Hướng dẫn sử dụng','7','3');
INSERT INTO olala3w_constant VALUES('75','fb_app_id','','Facebook App ID','4','2');
INSERT INTO olala3w_constant VALUES('77','upload_img_max_w','1600','Kích thước ảnh tối đa','6','1');
INSERT INTO olala3w_constant VALUES('78','upload_max_size','10485760','Dung lượng tối đa','6','2');
INSERT INTO olala3w_constant VALUES('79','upload_checking_mode','mild','Kiểu kiểm tra file tải lên','6','3');
INSERT INTO olala3w_constant VALUES('80','upload_type','1,4,5,6,7,8,9,10,11','Loại files cho phép','6','4');
INSERT INTO olala3w_constant VALUES('81','upload_ext','','Phần mở rộng bị cấm','6','5');
INSERT INTO olala3w_constant VALUES('82','upload_mime','','Loại mime bị cấm','6','6');
INSERT INTO olala3w_constant VALUES('83','upload_img_max_h','550','Kích thước ảnh tối đa','6','1');
INSERT INTO olala3w_constant VALUES('84','upload_auto_resize','1','Tự động resize ảnh','6','1');
INSERT INTO olala3w_constant VALUES('85','article_author','','Property = article:author','4','2');
INSERT INTO olala3w_constant VALUES('103','calendar_warning_time','1','Báo cận giờ','10','1');
INSERT INTO olala3w_constant VALUES('104','calendar_warning_sms','1','Cận giờ báo SMS','10','2');
INSERT INTO olala3w_constant VALUES('107','alias_information','<p><strong>Công ty CP Đầu tư Phát triển Nhà Đà Nẵng</strong><br />\r\n<label><span class=\"uln\">Trụ sở:</span> 38 Nguyễn Chí Thanh</label>, <label>P. Thạch Thang</label>, <label>Q. Hải Châu</label>, <label>Tp. Đà Nẵng</label><br />\r\n<label><span class=\"uln\">Điện thoại:</span> (0511) 3872.213</label> - <label><span class=\"uln\">Hotline:</span> (0511) 2695555</label> - <label><span class=\"uln\">Fax:</span> (0511) 3872.213</label><br />\r\n<label><span class=\"uln\">Email:</span> info@ndn.com.vn</label></p>\r\n','Thông tin công ty','7','1');
INSERT INTO olala3w_constant VALUES('108','copyright','Copyright © 2016 NDN','Meta copyright','0','3');
INSERT INTO olala3w_constant VALUES('109','hosting_domain','<p>Đang cập nhật...</p>\r\n','Hosting & Domain','8','1');

-- --------------------------------------------------------

CREATE TABLE `olala3w_core_privilege` (
  `privilege_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `role_id` int(11) NOT NULL DEFAULT '0',
  `type` varchar(30) NOT NULL,
  `privilege_slug` varchar(50) NOT NULL,
  PRIMARY KEY (`privilege_id`)
) ENGINE=MyISAM AUTO_INCREMENT=5883 DEFAULT CHARSET=utf8;

INSERT INTO olala3w_core_privilege VALUES('5557','61','calendar','calendar_tracking;51');
INSERT INTO olala3w_core_privilege VALUES('5556','61','calendar','calendar_list;51');
INSERT INTO olala3w_core_privilege VALUES('5555','61','calendar','calendar_add;51');
INSERT INTO olala3w_core_privilege VALUES('5554','61','calendar','calendar;delete');
INSERT INTO olala3w_core_privilege VALUES('5262','56','ol','statistic');
INSERT INTO olala3w_core_privilege VALUES('5260','56','statistic','statistic_jobs;53');
INSERT INTO olala3w_core_privilege VALUES('5261','56','statistic','statistic_matches;53');
INSERT INTO olala3w_core_privilege VALUES('5259','56','statistic','statistic_matches');
INSERT INTO olala3w_core_privilege VALUES('5257','56','ol','calendar');
INSERT INTO olala3w_core_privilege VALUES('5258','56','statistic','statistic_jobs');
INSERT INTO olala3w_core_privilege VALUES('5529','58','calendar','calendar_list;53');
INSERT INTO olala3w_core_privilege VALUES('5520','56','calendar','calendar_list;53');
INSERT INTO olala3w_core_privilege VALUES('5519','56','calendar','calendar_add;53');
INSERT INTO olala3w_core_privilege VALUES('5518','56','calendar','calendar;delete');
INSERT INTO olala3w_core_privilege VALUES('4797','1','ol','backup');
INSERT INTO olala3w_core_privilege VALUES('4796','1','ol','config');
INSERT INTO olala3w_core_privilege VALUES('4795','1','ol','core');
INSERT INTO olala3w_core_privilege VALUES('4794','1','ol','general');
INSERT INTO olala3w_core_privilege VALUES('4793','1','ol','statistic');
INSERT INTO olala3w_core_privilege VALUES('4792','1','ol','calendar');
INSERT INTO olala3w_core_privilege VALUES('4791','1','ol','document');
INSERT INTO olala3w_core_privilege VALUES('4790','1','backup','backup_config');
INSERT INTO olala3w_core_privilege VALUES('4789','1','backup','backup_process');
INSERT INTO olala3w_core_privilege VALUES('4788','1','config','plugin_page');
INSERT INTO olala3w_core_privilege VALUES('4787','1','config','config_upload');
INSERT INTO olala3w_core_privilege VALUES('4786','1','config','config_social_network');
INSERT INTO olala3w_core_privilege VALUES('4785','1','config','config_plugins');
INSERT INTO olala3w_core_privilege VALUES('4784','1','config','config_mail');
INSERT INTO olala3w_core_privilege VALUES('4783','1','config','config_datetime');
INSERT INTO olala3w_core_privilege VALUES('4782','1','config','config_general');
INSERT INTO olala3w_core_privilege VALUES('4781','1','core','core_agency;delete');
INSERT INTO olala3w_core_privilege VALUES('4780','1','core','core_agency_edit');
INSERT INTO olala3w_core_privilege VALUES('4779','1','core','core_agency_add');
INSERT INTO olala3w_core_privilege VALUES('4778','1','core','core_agency');
INSERT INTO olala3w_core_privilege VALUES('4777','1','core','core_dashboard');
INSERT INTO olala3w_core_privilege VALUES('4776','1','core','core_role;delete');
INSERT INTO olala3w_core_privilege VALUES('4775','1','core','core_role_edit');
INSERT INTO olala3w_core_privilege VALUES('4774','1','core','core_role_add');
INSERT INTO olala3w_core_privilege VALUES('4773','1','core','core_role');
INSERT INTO olala3w_core_privilege VALUES('4772','1','core','core_user;delete');
INSERT INTO olala3w_core_privilege VALUES('4771','1','core','core_user_edit');
INSERT INTO olala3w_core_privilege VALUES('4770','1','core','core_user_add');
INSERT INTO olala3w_core_privilege VALUES('4769','1','core','core_user');
INSERT INTO olala3w_core_privilege VALUES('5684','1','calendar','calendar_add;0');
INSERT INTO olala3w_core_privilege VALUES('5683','1','calendar','calendar_notify');
INSERT INTO olala3w_core_privilege VALUES('4869','24','calendar','calendar_add');
INSERT INTO olala3w_core_privilege VALUES('4870','24','calendar','calendar_list');
INSERT INTO olala3w_core_privilege VALUES('4871','24','calendar','calendar_tracking');
INSERT INTO olala3w_core_privilege VALUES('4872','24','calendar','calendar_remind');
INSERT INTO olala3w_core_privilege VALUES('4873','24','calendar','calendar;eye');
INSERT INTO olala3w_core_privilege VALUES('4874','24','calendar','calendar;delete');
INSERT INTO olala3w_core_privilege VALUES('4875','24','general','general_level');
INSERT INTO olala3w_core_privilege VALUES('4876','24','general','general_warning');
INSERT INTO olala3w_core_privilege VALUES('4877','24','general','general_matches');
INSERT INTO olala3w_core_privilege VALUES('4878','24','general','general_jobs_name');
INSERT INTO olala3w_core_privilege VALUES('4879','24','general','general_jobs_address');
INSERT INTO olala3w_core_privilege VALUES('4908','27','calendar','calendar;delete');
INSERT INTO olala3w_core_privilege VALUES('4907','27','calendar','calendar;eye');
INSERT INTO olala3w_core_privilege VALUES('4906','27','calendar','calendar_remind');
INSERT INTO olala3w_core_privilege VALUES('4905','27','calendar','calendar_tracking');
INSERT INTO olala3w_core_privilege VALUES('4904','27','calendar','calendar_list');
INSERT INTO olala3w_core_privilege VALUES('4903','27','calendar','calendar_add');
INSERT INTO olala3w_core_privilege VALUES('4886','27','general','general_level');
INSERT INTO olala3w_core_privilege VALUES('4887','27','general','general_level_add');
INSERT INTO olala3w_core_privilege VALUES('4888','27','general','general_level_edit');
INSERT INTO olala3w_core_privilege VALUES('4889','27','general','general_level;delete');
INSERT INTO olala3w_core_privilege VALUES('4890','27','general','general_warning');
INSERT INTO olala3w_core_privilege VALUES('4891','27','general','general_matches');
INSERT INTO olala3w_core_privilege VALUES('4892','27','general','general_matches_add');
INSERT INTO olala3w_core_privilege VALUES('4893','27','general','general_matches_edit');
INSERT INTO olala3w_core_privilege VALUES('4894','27','general','general_matches;delete');
INSERT INTO olala3w_core_privilege VALUES('4895','27','general','general_jobs_name');
INSERT INTO olala3w_core_privilege VALUES('4896','27','general','general_jobs_name_add');
INSERT INTO olala3w_core_privilege VALUES('4897','27','general','general_jobs_name_edit');
INSERT INTO olala3w_core_privilege VALUES('4898','27','general','general_jobs_name;delete');
INSERT INTO olala3w_core_privilege VALUES('4899','27','general','general_jobs_address');
INSERT INTO olala3w_core_privilege VALUES('4900','27','general','general_jobs_address_add');
INSERT INTO olala3w_core_privilege VALUES('4901','27','general','general_jobs_address_edit');
INSERT INTO olala3w_core_privilege VALUES('4902','27','general','general_jobs_address;delete');
INSERT INTO olala3w_core_privilege VALUES('4909','34','calendar','calendar_add');
INSERT INTO olala3w_core_privilege VALUES('4910','34','calendar','calendar_list');
INSERT INTO olala3w_core_privilege VALUES('4911','34','calendar','calendar_tracking');
INSERT INTO olala3w_core_privilege VALUES('4912','34','calendar','calendar_remind');
INSERT INTO olala3w_core_privilege VALUES('4913','34','calendar','calendar;eye');
INSERT INTO olala3w_core_privilege VALUES('4914','34','calendar','calendar;delete');
INSERT INTO olala3w_core_privilege VALUES('5079','35','calendar','calendar;delete');
INSERT INTO olala3w_core_privilege VALUES('5078','35','calendar','calendar;eye');
INSERT INTO olala3w_core_privilege VALUES('5077','35','calendar','calendar_edit');
INSERT INTO olala3w_core_privilege VALUES('5076','35','calendar','calendar_tracking');
INSERT INTO olala3w_core_privilege VALUES('5075','35','calendar','calendar_list');
INSERT INTO olala3w_core_privilege VALUES('5074','35','calendar','calendar_add');
INSERT INTO olala3w_core_privilege VALUES('4921','35','core','-');
INSERT INTO olala3w_core_privilege VALUES('4922','35','ol','document');
INSERT INTO olala3w_core_privilege VALUES('4923','35','ol','calendar');
INSERT INTO olala3w_core_privilege VALUES('4924','35','ol','statistic');
INSERT INTO olala3w_core_privilege VALUES('4925','35','ol','general');
INSERT INTO olala3w_core_privilege VALUES('4926','35','ol','core');
INSERT INTO olala3w_core_privilege VALUES('4927','35','ol','config');
INSERT INTO olala3w_core_privilege VALUES('4928','35','ol','backup');
INSERT INTO olala3w_core_privilege VALUES('5094','35','general','general_jobs_name');
INSERT INTO olala3w_core_privilege VALUES('5093','35','general','general_matches');
INSERT INTO olala3w_core_privilege VALUES('5092','35','general','general_warning');
INSERT INTO olala3w_core_privilege VALUES('5091','35','general','general_level');
INSERT INTO olala3w_core_privilege VALUES('5097','35','config','-');
INSERT INTO olala3w_core_privilege VALUES('4935','44','calendar','calendar_add');
INSERT INTO olala3w_core_privilege VALUES('4936','44','calendar','calendar_list');
INSERT INTO olala3w_core_privilege VALUES('4937','44','calendar','calendar_tracking');
INSERT INTO olala3w_core_privilege VALUES('4938','44','calendar','calendar_remind');
INSERT INTO olala3w_core_privilege VALUES('4939','44','calendar','calendar;eye');
INSERT INTO olala3w_core_privilege VALUES('4940','44','calendar','calendar;delete');
INSERT INTO olala3w_core_privilege VALUES('4941','44','general','general_level');
INSERT INTO olala3w_core_privilege VALUES('4942','44','general','general_warning');
INSERT INTO olala3w_core_privilege VALUES('4943','44','general','general_matches');
INSERT INTO olala3w_core_privilege VALUES('4944','44','general','general_jobs_name');
INSERT INTO olala3w_core_privilege VALUES('4945','44','general','general_jobs_address');
INSERT INTO olala3w_core_privilege VALUES('4947','49','calendar','calendar_add');
INSERT INTO olala3w_core_privilege VALUES('4948','49','calendar','calendar_list');
INSERT INTO olala3w_core_privilege VALUES('4949','49','calendar','calendar_tracking');
INSERT INTO olala3w_core_privilege VALUES('4950','49','calendar','calendar_remind');
INSERT INTO olala3w_core_privilege VALUES('4951','49','calendar','calendar;eye');
INSERT INTO olala3w_core_privilege VALUES('4952','49','calendar','calendar;delete');
INSERT INTO olala3w_core_privilege VALUES('4958','1','document','document_edit');
INSERT INTO olala3w_core_privilege VALUES('4957','1','document','document_list');
INSERT INTO olala3w_core_privilege VALUES('4956','1','document','document_add');
INSERT INTO olala3w_core_privilege VALUES('4959','1','document','document;delete');
INSERT INTO olala3w_core_privilege VALUES('5517','56','calendar','calendar;eye');
INSERT INTO olala3w_core_privilege VALUES('5516','56','calendar','calendar_edit');
INSERT INTO olala3w_core_privilege VALUES('5515','56','calendar','calendar_tracking');
INSERT INTO olala3w_core_privilege VALUES('5514','56','calendar','calendar_list');
INSERT INTO olala3w_core_privilege VALUES('5513','56','calendar','calendar_add');
INSERT INTO olala3w_core_privilege VALUES('5437','1','general','general_level');
INSERT INTO olala3w_core_privilege VALUES('5682','1','calendar','calendar;delete');
INSERT INTO olala3w_core_privilege VALUES('5681','1','calendar','calendar;eye');
INSERT INTO olala3w_core_privilege VALUES('5680','1','calendar','calendar_edit');
INSERT INTO olala3w_core_privilege VALUES('5679','1','calendar','calendar_tracking');
INSERT INTO olala3w_core_privilege VALUES('5730','1','statistic','statistic_matches');
INSERT INTO olala3w_core_privilege VALUES('5729','1','statistic','statistic_jobs_export');
INSERT INTO olala3w_core_privilege VALUES('5728','1','statistic','statistic_jobs');
INSERT INTO olala3w_core_privilege VALUES('5678','1','calendar','calendar_list');
INSERT INTO olala3w_core_privilege VALUES('5693','2','calendar','calendar_notify');
INSERT INTO olala3w_core_privilege VALUES('5692','2','calendar','calendar;delete');
INSERT INTO olala3w_core_privilege VALUES('5691','2','calendar','calendar;eye');
INSERT INTO olala3w_core_privilege VALUES('5690','2','calendar','calendar_edit');
INSERT INTO olala3w_core_privilege VALUES('5689','2','calendar','calendar_tracking');
INSERT INTO olala3w_core_privilege VALUES('5016','2','ol','calendar');
INSERT INTO olala3w_core_privilege VALUES('5017','2','ol','document');
INSERT INTO olala3w_core_privilege VALUES('5018','2','ol','statistic');
INSERT INTO olala3w_core_privilege VALUES('5019','2','ol','general');
INSERT INTO olala3w_core_privilege VALUES('5020','2','ol','core');
INSERT INTO olala3w_core_privilege VALUES('5021','2','ol','config');
INSERT INTO olala3w_core_privilege VALUES('5022','2','ol','backup');
INSERT INTO olala3w_core_privilege VALUES('5023','2','document','document_add');
INSERT INTO olala3w_core_privilege VALUES('5024','2','document','document_list');
INSERT INTO olala3w_core_privilege VALUES('5025','2','document','document_edit');
INSERT INTO olala3w_core_privilege VALUES('5026','2','document','document;delete');
INSERT INTO olala3w_core_privilege VALUES('5736','2','statistic','statistic_matches');
INSERT INTO olala3w_core_privilege VALUES('5735','2','statistic','statistic_jobs_export');
INSERT INTO olala3w_core_privilege VALUES('5734','2','statistic','statistic_jobs');
INSERT INTO olala3w_core_privilege VALUES('5031','2','general','general_level');
INSERT INTO olala3w_core_privilege VALUES('5032','2','general','general_level_add');
INSERT INTO olala3w_core_privilege VALUES('5033','2','general','general_level_edit');
INSERT INTO olala3w_core_privilege VALUES('5034','2','general','general_level;delete');
INSERT INTO olala3w_core_privilege VALUES('5035','2','general','general_warning');
INSERT INTO olala3w_core_privilege VALUES('5036','2','general','general_matches');
INSERT INTO olala3w_core_privilege VALUES('5037','2','general','general_matches_add');
INSERT INTO olala3w_core_privilege VALUES('5038','2','general','general_matches_edit');
INSERT INTO olala3w_core_privilege VALUES('5039','2','general','general_matches;delete');
INSERT INTO olala3w_core_privilege VALUES('5040','2','general','general_jobs_name');
INSERT INTO olala3w_core_privilege VALUES('5041','2','general','general_jobs_name_add');
INSERT INTO olala3w_core_privilege VALUES('5042','2','general','general_jobs_name_edit');
INSERT INTO olala3w_core_privilege VALUES('5043','2','general','general_jobs_name;delete');
INSERT INTO olala3w_core_privilege VALUES('5044','2','general','general_jobs_address');
INSERT INTO olala3w_core_privilege VALUES('5045','2','general','general_jobs_address_add');
INSERT INTO olala3w_core_privilege VALUES('5046','2','general','general_jobs_address_edit');
INSERT INTO olala3w_core_privilege VALUES('5047','2','general','general_jobs_address;delete');
INSERT INTO olala3w_core_privilege VALUES('5048','2','general','general_document_type');
INSERT INTO olala3w_core_privilege VALUES('5049','2','general','general_document_type_add');
INSERT INTO olala3w_core_privilege VALUES('5050','2','general','general_document_type_edit');
INSERT INTO olala3w_core_privilege VALUES('5051','2','general','general_document_type;delete');
INSERT INTO olala3w_core_privilege VALUES('5052','2','core','core_user');
INSERT INTO olala3w_core_privilege VALUES('5053','2','core','core_user_add');
INSERT INTO olala3w_core_privilege VALUES('5054','2','core','core_user_edit');
INSERT INTO olala3w_core_privilege VALUES('5055','2','core','core_user;delete');
INSERT INTO olala3w_core_privilege VALUES('5056','2','core','core_role');
INSERT INTO olala3w_core_privilege VALUES('5057','2','core','core_role_add');
INSERT INTO olala3w_core_privilege VALUES('5058','2','core','core_role_edit');
INSERT INTO olala3w_core_privilege VALUES('5059','2','core','core_role;delete');
INSERT INTO olala3w_core_privilege VALUES('5060','2','core','core_dashboard');
INSERT INTO olala3w_core_privilege VALUES('5061','2','core','core_agency');
INSERT INTO olala3w_core_privilege VALUES('5062','2','core','core_agency_add');
INSERT INTO olala3w_core_privilege VALUES('5063','2','core','core_agency_edit');
INSERT INTO olala3w_core_privilege VALUES('5064','2','core','core_agency;delete');
INSERT INTO olala3w_core_privilege VALUES('5065','2','config','config_general');
INSERT INTO olala3w_core_privilege VALUES('5066','2','config','config_datetime');
INSERT INTO olala3w_core_privilege VALUES('5067','2','config','config_mail');
INSERT INTO olala3w_core_privilege VALUES('5068','2','config','config_plugins');
INSERT INTO olala3w_core_privilege VALUES('5069','2','config','config_social_network');
INSERT INTO olala3w_core_privilege VALUES('5070','2','config','config_upload');
INSERT INTO olala3w_core_privilege VALUES('5071','2','config','plugin_page');
INSERT INTO olala3w_core_privilege VALUES('5072','2','backup','backup_process');
INSERT INTO olala3w_core_privilege VALUES('5073','2','backup','backup_config');
INSERT INTO olala3w_core_privilege VALUES('5080','35','calendar','calendar_notify');
INSERT INTO olala3w_core_privilege VALUES('5081','35','calendar','calendar_list;0');
INSERT INTO olala3w_core_privilege VALUES('5082','35','calendar','calendar_tracking;0');
INSERT INTO olala3w_core_privilege VALUES('5083','35','document','document_add');
INSERT INTO olala3w_core_privilege VALUES('5084','35','document','document_list');
INSERT INTO olala3w_core_privilege VALUES('5085','35','document','document_edit');
INSERT INTO olala3w_core_privilege VALUES('5086','35','document','document;delete');
INSERT INTO olala3w_core_privilege VALUES('5087','35','statistic','statistic_jobs');
INSERT INTO olala3w_core_privilege VALUES('5088','35','statistic','statistic_matches');
INSERT INTO olala3w_core_privilege VALUES('5089','35','statistic','statistic_jobs;0');
INSERT INTO olala3w_core_privilege VALUES('5090','35','statistic','statistic_matches;0');
INSERT INTO olala3w_core_privilege VALUES('5095','35','general','general_jobs_address');
INSERT INTO olala3w_core_privilege VALUES('5096','35','general','general_document_type');
INSERT INTO olala3w_core_privilege VALUES('5098','53','document','document_add');
INSERT INTO olala3w_core_privilege VALUES('5099','53','document','document_list');
INSERT INTO olala3w_core_privilege VALUES('5100','53','document','document_edit');
INSERT INTO olala3w_core_privilege VALUES('5101','53','document','document;delete');
INSERT INTO olala3w_core_privilege VALUES('5184','53','calendar','calendar_notify');
INSERT INTO olala3w_core_privilege VALUES('5183','53','calendar','calendar;delete');
INSERT INTO olala3w_core_privilege VALUES('5182','53','calendar','calendar;eye');
INSERT INTO olala3w_core_privilege VALUES('5181','53','calendar','calendar_edit');
INSERT INTO olala3w_core_privilege VALUES('5180','53','calendar','calendar_tracking');
INSERT INTO olala3w_core_privilege VALUES('5179','53','calendar','calendar_list');
INSERT INTO olala3w_core_privilege VALUES('5178','53','calendar','calendar_add');
INSERT INTO olala3w_core_privilege VALUES('5190','53','statistic','statistic_matches;30');
INSERT INTO olala3w_core_privilege VALUES('5189','53','statistic','statistic_jobs;30');
INSERT INTO olala3w_core_privilege VALUES('5188','53','statistic','statistic_matches');
INSERT INTO olala3w_core_privilege VALUES('5187','53','statistic','statistic_jobs');
INSERT INTO olala3w_core_privilege VALUES('5197','53','general','general_matches_edit');
INSERT INTO olala3w_core_privilege VALUES('5196','53','general','general_matches_add');
INSERT INTO olala3w_core_privilege VALUES('5195','53','general','general_matches');
INSERT INTO olala3w_core_privilege VALUES('5194','53','general','general_warning');
INSERT INTO olala3w_core_privilege VALUES('5193','53','general','general_level_edit');
INSERT INTO olala3w_core_privilege VALUES('5192','53','general','general_level_add');
INSERT INTO olala3w_core_privilege VALUES('5191','53','general','general_level');
INSERT INTO olala3w_core_privilege VALUES('5123','53','core','-');
INSERT INTO olala3w_core_privilege VALUES('5438','1','general','general_level_add');
INSERT INTO olala3w_core_privilege VALUES('5726','65','calendar','calendar_list;57');
INSERT INTO olala3w_core_privilege VALUES('5725','65','calendar','calendar_add;57');
INSERT INTO olala3w_core_privilege VALUES('5130','51','ol','document');
INSERT INTO olala3w_core_privilege VALUES('5131','51','ol','calendar');
INSERT INTO olala3w_core_privilege VALUES('5132','51','document','document_add');
INSERT INTO olala3w_core_privilege VALUES('5133','51','document','document_list');
INSERT INTO olala3w_core_privilege VALUES('5134','51','document','document_edit');
INSERT INTO olala3w_core_privilege VALUES('5135','51','document','document;delete');
INSERT INTO olala3w_core_privilege VALUES('5703','51','calendar','calendar_notify');
INSERT INTO olala3w_core_privilege VALUES('5702','51','calendar','calendar;delete');
INSERT INTO olala3w_core_privilege VALUES('5701','51','calendar','calendar;eye');
INSERT INTO olala3w_core_privilege VALUES('5700','51','calendar','calendar_edit');
INSERT INTO olala3w_core_privilege VALUES('5699','51','calendar','calendar_tracking');
INSERT INTO olala3w_core_privilege VALUES('5742','51','statistic','statistic_matches');
INSERT INTO olala3w_core_privilege VALUES('5741','51','statistic','statistic_jobs_export');
INSERT INTO olala3w_core_privilege VALUES('5149','53','ol','calendar');
INSERT INTO olala3w_core_privilege VALUES('5150','53','ol','document');
INSERT INTO olala3w_core_privilege VALUES('5151','53','ol','statistic');
INSERT INTO olala3w_core_privilege VALUES('5740','51','statistic','statistic_jobs');
INSERT INTO olala3w_core_privilege VALUES('5156','51','ol','general');
INSERT INTO olala3w_core_privilege VALUES('5157','51','general','general_level');
INSERT INTO olala3w_core_privilege VALUES('5158','51','general','general_level_add');
INSERT INTO olala3w_core_privilege VALUES('5159','51','general','general_level_edit');
INSERT INTO olala3w_core_privilege VALUES('5160','51','general','general_level;delete');
INSERT INTO olala3w_core_privilege VALUES('5161','51','general','general_warning');
INSERT INTO olala3w_core_privilege VALUES('5162','51','general','general_matches');
INSERT INTO olala3w_core_privilege VALUES('5163','51','general','general_matches_add');
INSERT INTO olala3w_core_privilege VALUES('5164','51','general','general_matches_edit');
INSERT INTO olala3w_core_privilege VALUES('5165','51','general','general_matches;delete');
INSERT INTO olala3w_core_privilege VALUES('5166','51','general','general_jobs_name');
INSERT INTO olala3w_core_privilege VALUES('5167','51','general','general_jobs_name_add');
INSERT INTO olala3w_core_privilege VALUES('5168','51','general','general_jobs_name_edit');
INSERT INTO olala3w_core_privilege VALUES('5169','51','general','general_jobs_name;delete');
INSERT INTO olala3w_core_privilege VALUES('5170','51','general','general_jobs_address');
INSERT INTO olala3w_core_privilege VALUES('5171','51','general','general_jobs_address_add');
INSERT INTO olala3w_core_privilege VALUES('5172','51','general','general_jobs_address_edit');
INSERT INTO olala3w_core_privilege VALUES('5173','51','general','general_jobs_address;delete');
INSERT INTO olala3w_core_privilege VALUES('5174','51','general','general_document_type');
INSERT INTO olala3w_core_privilege VALUES('5175','51','general','general_document_type_add');
INSERT INTO olala3w_core_privilege VALUES('5176','51','general','general_document_type_edit');
INSERT INTO olala3w_core_privilege VALUES('5177','51','general','general_document_type;delete');
INSERT INTO olala3w_core_privilege VALUES('5185','53','calendar','calendar_list;30');
INSERT INTO olala3w_core_privilege VALUES('5186','53','calendar','calendar_tracking;30');
INSERT INTO olala3w_core_privilege VALUES('5198','53','general','general_matches;delete');
INSERT INTO olala3w_core_privilege VALUES('5199','53','general','general_jobs_name');
INSERT INTO olala3w_core_privilege VALUES('5200','53','general','general_jobs_name_add');
INSERT INTO olala3w_core_privilege VALUES('5201','53','general','general_jobs_name_edit');
INSERT INTO olala3w_core_privilege VALUES('5202','53','general','general_jobs_name;delete');
INSERT INTO olala3w_core_privilege VALUES('5203','53','general','general_jobs_address');
INSERT INTO olala3w_core_privilege VALUES('5204','53','general','general_jobs_address_add');
INSERT INTO olala3w_core_privilege VALUES('5205','53','general','general_jobs_address_edit');
INSERT INTO olala3w_core_privilege VALUES('5206','53','general','general_jobs_address;delete');
INSERT INTO olala3w_core_privilege VALUES('5207','53','general','general_document_type');
INSERT INTO olala3w_core_privilege VALUES('5208','53','general','general_document_type_add');
INSERT INTO olala3w_core_privilege VALUES('5209','53','general','general_document_type_edit');
INSERT INTO olala3w_core_privilege VALUES('5236','55','calendar','calendar_notify');
INSERT INTO olala3w_core_privilege VALUES('5235','55','calendar','calendar;delete');
INSERT INTO olala3w_core_privilege VALUES('5234','55','calendar','calendar;eye');
INSERT INTO olala3w_core_privilege VALUES('5233','55','calendar','calendar_edit');
INSERT INTO olala3w_core_privilege VALUES('5232','55','calendar','calendar_tracking');
INSERT INTO olala3w_core_privilege VALUES('5231','55','calendar','calendar_list');
INSERT INTO olala3w_core_privilege VALUES('5230','55','calendar','calendar_add');
INSERT INTO olala3w_core_privilege VALUES('5219','55','ol','document');
INSERT INTO olala3w_core_privilege VALUES('5220','55','ol','calendar');
INSERT INTO olala3w_core_privilege VALUES('5221','55','ol','statistic');
INSERT INTO olala3w_core_privilege VALUES('5229','55','statistic','statistic_matches;30');
INSERT INTO olala3w_core_privilege VALUES('5228','55','statistic','statistic_jobs;30');
INSERT INTO olala3w_core_privilege VALUES('5227','55','statistic','statistic_matches');
INSERT INTO olala3w_core_privilege VALUES('5226','55','statistic','statistic_jobs');
INSERT INTO olala3w_core_privilege VALUES('5237','55','calendar','calendar_list;56');
INSERT INTO olala3w_core_privilege VALUES('5238','55','calendar','calendar_tracking;56');
INSERT INTO olala3w_core_privilege VALUES('5476','61','ol','calendar');
INSERT INTO olala3w_core_privilege VALUES('5552','61','calendar','calendar_edit');
INSERT INTO olala3w_core_privilege VALUES('5549','61','calendar','calendar_add');
INSERT INTO olala3w_core_privilege VALUES('5465','57','calendar','calendar_tracking;51');
INSERT INTO olala3w_core_privilege VALUES('5467','57','statistic','statistic_matches;51');
INSERT INTO olala3w_core_privilege VALUES('5466','57','statistic','statistic_jobs;51');
INSERT INTO olala3w_core_privilege VALUES('5714','54','calendar','calendar_notify');
INSERT INTO olala3w_core_privilege VALUES('5713','54','calendar','calendar;delete');
INSERT INTO olala3w_core_privilege VALUES('5712','54','calendar','calendar;eye');
INSERT INTO olala3w_core_privilege VALUES('5711','54','calendar','calendar_edit');
INSERT INTO olala3w_core_privilege VALUES('5710','54','calendar','calendar_tracking');
INSERT INTO olala3w_core_privilege VALUES('5709','54','calendar','calendar_list');
INSERT INTO olala3w_core_privilege VALUES('5707','54','ol','calendar');
INSERT INTO olala3w_core_privilege VALUES('5295','54','ol','statistic');
INSERT INTO olala3w_core_privilege VALUES('5754','54','statistic','statistic_matches_export');
INSERT INTO olala3w_core_privilege VALUES('5753','54','statistic','statistic_matches');
INSERT INTO olala3w_core_privilege VALUES('5300','54','general','general_level');
INSERT INTO olala3w_core_privilege VALUES('5301','54','general','general_level_add');
INSERT INTO olala3w_core_privilege VALUES('5302','54','general','general_level_edit');
INSERT INTO olala3w_core_privilege VALUES('5303','54','general','general_level;delete');
INSERT INTO olala3w_core_privilege VALUES('5304','54','general','general_warning');
INSERT INTO olala3w_core_privilege VALUES('5305','54','general','general_matches');
INSERT INTO olala3w_core_privilege VALUES('5306','54','general','general_matches_add');
INSERT INTO olala3w_core_privilege VALUES('5307','54','general','general_matches_edit');
INSERT INTO olala3w_core_privilege VALUES('5308','54','general','general_matches;delete');
INSERT INTO olala3w_core_privilege VALUES('5309','54','general','general_jobs_name');
INSERT INTO olala3w_core_privilege VALUES('5310','54','general','general_jobs_name_add');
INSERT INTO olala3w_core_privilege VALUES('5311','54','general','general_jobs_name_edit');
INSERT INTO olala3w_core_privilege VALUES('5312','54','general','general_jobs_name;delete');
INSERT INTO olala3w_core_privilege VALUES('5313','54','general','general_jobs_address');
INSERT INTO olala3w_core_privilege VALUES('5314','54','general','general_jobs_address_add');
INSERT INTO olala3w_core_privilege VALUES('5315','54','general','general_jobs_address_edit');
INSERT INTO olala3w_core_privilege VALUES('5316','54','general','general_jobs_address;delete');
INSERT INTO olala3w_core_privilege VALUES('5317','54','general','general_document_type');
INSERT INTO olala3w_core_privilege VALUES('5318','54','general','general_document_type_add');
INSERT INTO olala3w_core_privilege VALUES('5319','54','general','general_document_type_edit');
INSERT INTO olala3w_core_privilege VALUES('5320','54','general','general_document_type;delete');
INSERT INTO olala3w_core_privilege VALUES('5321','54','ol','general');
INSERT INTO olala3w_core_privilege VALUES('5464','57','calendar','calendar_list;51');
INSERT INTO olala3w_core_privilege VALUES('5339','58','ol','calendar');
INSERT INTO olala3w_core_privilege VALUES('5340','58','ol','statistic');
INSERT INTO olala3w_core_privilege VALUES('5528','58','calendar','calendar_add;53');
INSERT INTO olala3w_core_privilege VALUES('5527','58','calendar','calendar;delete');
INSERT INTO olala3w_core_privilege VALUES('5526','58','calendar','calendar;eye');
INSERT INTO olala3w_core_privilege VALUES('5525','58','calendar','calendar_edit');
INSERT INTO olala3w_core_privilege VALUES('5524','58','calendar','calendar_tracking');
INSERT INTO olala3w_core_privilege VALUES('5523','58','calendar','calendar_list');
INSERT INTO olala3w_core_privilege VALUES('5522','58','calendar','calendar_add');
INSERT INTO olala3w_core_privilege VALUES('5350','58','statistic','statistic_jobs');
INSERT INTO olala3w_core_privilege VALUES('5351','58','statistic','statistic_matches');
INSERT INTO olala3w_core_privilege VALUES('5352','58','statistic','statistic_jobs;53');
INSERT INTO olala3w_core_privilege VALUES('5353','58','statistic','statistic_matches;53');
INSERT INTO olala3w_core_privilege VALUES('5551','61','calendar','calendar_tracking');
INSERT INTO olala3w_core_privilege VALUES('5550','61','calendar','calendar_list');
INSERT INTO olala3w_core_privilege VALUES('5359','59','ol','calendar');
INSERT INTO olala3w_core_privilege VALUES('5360','59','ol','statistic');
INSERT INTO olala3w_core_privilege VALUES('5857','59','calendar','calendar_list;56');
INSERT INTO olala3w_core_privilege VALUES('5856','59','calendar','calendar_add;56');
INSERT INTO olala3w_core_privilege VALUES('5855','59','calendar','calendar_notify');
INSERT INTO olala3w_core_privilege VALUES('5853','59','calendar','calendar;eye');
INSERT INTO olala3w_core_privilege VALUES('5854','59','calendar','calendar;delete');
INSERT INTO olala3w_core_privilege VALUES('5825','59','statistic','statistic_matches');
INSERT INTO olala3w_core_privilege VALUES('5824','59','statistic','statistic_jobs_export');
INSERT INTO olala3w_core_privilege VALUES('5823','59','statistic','statistic_jobs');
INSERT INTO olala3w_core_privilege VALUES('5374','51','ol','statistic');
INSERT INTO olala3w_core_privilege VALUES('5852','59','calendar','calendar_edit');
INSERT INTO olala3w_core_privilege VALUES('5688','2','calendar','calendar_list');
INSERT INTO olala3w_core_privilege VALUES('5698','51','calendar','calendar_list');
INSERT INTO olala3w_core_privilege VALUES('5439','1','general','general_level_edit');
INSERT INTO olala3w_core_privilege VALUES('5440','1','general','general_level;delete');
INSERT INTO olala3w_core_privilege VALUES('5441','1','general','general_warning');
INSERT INTO olala3w_core_privilege VALUES('5442','1','general','general_matches');
INSERT INTO olala3w_core_privilege VALUES('5443','1','general','general_matches_add');
INSERT INTO olala3w_core_privilege VALUES('5444','1','general','general_matches_edit');
INSERT INTO olala3w_core_privilege VALUES('5445','1','general','general_matches;delete');
INSERT INTO olala3w_core_privilege VALUES('5446','1','general','general_jobs_name');
INSERT INTO olala3w_core_privilege VALUES('5447','1','general','general_jobs_name_add');
INSERT INTO olala3w_core_privilege VALUES('5448','1','general','general_jobs_name_edit');
INSERT INTO olala3w_core_privilege VALUES('5449','1','general','general_jobs_name;delete');
INSERT INTO olala3w_core_privilege VALUES('5450','1','general','general_jobs_address');
INSERT INTO olala3w_core_privilege VALUES('5451','1','general','general_jobs_address_add');
INSERT INTO olala3w_core_privilege VALUES('5452','1','general','general_jobs_address_edit');
INSERT INTO olala3w_core_privilege VALUES('5453','1','general','general_jobs_address;delete');
INSERT INTO olala3w_core_privilege VALUES('5454','1','general','general_document_type');
INSERT INTO olala3w_core_privilege VALUES('5455','1','general','general_document_type_add');
INSERT INTO olala3w_core_privilege VALUES('5456','1','general','general_document_type_edit');
INSERT INTO olala3w_core_privilege VALUES('5457','1','general','general_document_type;delete');
INSERT INTO olala3w_core_privilege VALUES('5458','60','document','document_add');
INSERT INTO olala3w_core_privilege VALUES('5459','60','document','document_list');
INSERT INTO olala3w_core_privilege VALUES('5460','60','document','document_edit');
INSERT INTO olala3w_core_privilege VALUES('5461','60','document','document;delete');
INSERT INTO olala3w_core_privilege VALUES('5462','60','ol','document');
INSERT INTO olala3w_core_privilege VALUES('5850','59','calendar','calendar_list');
INSERT INTO olala3w_core_privilege VALUES('5677','1','calendar','calendar_add');
INSERT INTO olala3w_core_privilege VALUES('5687','2','calendar','calendar_add');
INSERT INTO olala3w_core_privilege VALUES('5697','51','calendar','calendar_add');
INSERT INTO olala3w_core_privilege VALUES('5708','54','calendar','calendar_add');
INSERT INTO olala3w_core_privilege VALUES('5521','56','calendar','calendar_tracking;53');
INSERT INTO olala3w_core_privilege VALUES('5530','58','calendar','calendar_tracking;53');
INSERT INTO olala3w_core_privilege VALUES('5851','59','calendar','calendar_tracking');
INSERT INTO olala3w_core_privilege VALUES('5553','61','calendar','calendar;eye');
INSERT INTO olala3w_core_privilege VALUES('5595','63','calendar','calendar_tracking;30');
INSERT INTO olala3w_core_privilege VALUES('5594','63','calendar','calendar_list;30');
INSERT INTO olala3w_core_privilege VALUES('5593','63','calendar','calendar_add;30');
INSERT INTO olala3w_core_privilege VALUES('5592','63','calendar','calendar_notify');
INSERT INTO olala3w_core_privilege VALUES('5591','63','calendar','calendar;delete');
INSERT INTO olala3w_core_privilege VALUES('5590','63','calendar','calendar;eye');
INSERT INTO olala3w_core_privilege VALUES('5589','63','calendar','calendar_edit');
INSERT INTO olala3w_core_privilege VALUES('5588','63','calendar','calendar_tracking');
INSERT INTO olala3w_core_privilege VALUES('5587','63','calendar','calendar_list');
INSERT INTO olala3w_core_privilege VALUES('5586','63','calendar','calendar_add');
INSERT INTO olala3w_core_privilege VALUES('5596','63','ol','calendar');
INSERT INTO olala3w_core_privilege VALUES('5597','63','ol','statistic');
INSERT INTO olala3w_core_privilege VALUES('5598','64','ol','calendar');
INSERT INTO olala3w_core_privilege VALUES('5635','64','calendar','calendar_tracking;57');
INSERT INTO olala3w_core_privilege VALUES('5634','64','calendar','calendar_list;57');
INSERT INTO olala3w_core_privilege VALUES('5633','64','calendar','calendar_add;57');
INSERT INTO olala3w_core_privilege VALUES('5632','64','calendar','calendar;delete');
INSERT INTO olala3w_core_privilege VALUES('5631','64','calendar','calendar;eye');
INSERT INTO olala3w_core_privilege VALUES('5630','64','calendar','calendar_edit');
INSERT INTO olala3w_core_privilege VALUES('5637','64','statistic','statistic_matches;57');
INSERT INTO olala3w_core_privilege VALUES('5636','64','statistic','statistic_jobs;57');
INSERT INTO olala3w_core_privilege VALUES('5613','64','core','-');
INSERT INTO olala3w_core_privilege VALUES('5614','64','ol','statistic');
INSERT INTO olala3w_core_privilege VALUES('5724','65','calendar','calendar_notify');
INSERT INTO olala3w_core_privilege VALUES('5723','65','calendar','calendar;delete');
INSERT INTO olala3w_core_privilege VALUES('5722','65','calendar','calendar;eye');
INSERT INTO olala3w_core_privilege VALUES('5721','65','calendar','calendar_edit');
INSERT INTO olala3w_core_privilege VALUES('5720','65','calendar','calendar_tracking');
INSERT INTO olala3w_core_privilege VALUES('5719','65','calendar','calendar_list');
INSERT INTO olala3w_core_privilege VALUES('5718','65','calendar','calendar_add');
INSERT INTO olala3w_core_privilege VALUES('5624','65','ol','calendar');
INSERT INTO olala3w_core_privilege VALUES('5759','65','statistic','statistic_matches');
INSERT INTO olala3w_core_privilege VALUES('5758','65','statistic','statistic_jobs_export');
INSERT INTO olala3w_core_privilege VALUES('5757','65','statistic','statistic_jobs');
INSERT INTO olala3w_core_privilege VALUES('5629','65','ol','statistic');
INSERT INTO olala3w_core_privilege VALUES('5638','65','general','general_level');
INSERT INTO olala3w_core_privilege VALUES('5639','65','general','general_warning');
INSERT INTO olala3w_core_privilege VALUES('5640','65','general','general_matches');
INSERT INTO olala3w_core_privilege VALUES('5641','65','general','general_jobs_name');
INSERT INTO olala3w_core_privilege VALUES('5642','65','general','general_jobs_address');
INSERT INTO olala3w_core_privilege VALUES('5643','65','general','general_document_type');
INSERT INTO olala3w_core_privilege VALUES('5644','65','ol','general');
INSERT INTO olala3w_core_privilege VALUES('5664','66','calendar','calendar_add');
INSERT INTO olala3w_core_privilege VALUES('5665','66','calendar','calendar_list');
INSERT INTO olala3w_core_privilege VALUES('5666','66','calendar','calendar_edit');
INSERT INTO olala3w_core_privilege VALUES('5667','66','calendar','calendar;eye');
INSERT INTO olala3w_core_privilege VALUES('5668','66','calendar','calendar;delete');
INSERT INTO olala3w_core_privilege VALUES('5669','66','calendar','calendar_add;53');
INSERT INTO olala3w_core_privilege VALUES('5670','66','calendar','calendar_list;53');
INSERT INTO olala3w_core_privilege VALUES('5671','66','calendar','calendar_tracking;53');
INSERT INTO olala3w_core_privilege VALUES('5672','66','statistic','statistic_jobs');
INSERT INTO olala3w_core_privilege VALUES('5673','66','statistic','statistic_matches');
INSERT INTO olala3w_core_privilege VALUES('5674','66','statistic','statistic_jobs;53');
INSERT INTO olala3w_core_privilege VALUES('5675','66','statistic','statistic_matches;53');
INSERT INTO olala3w_core_privilege VALUES('5685','1','calendar','calendar_list;0');
INSERT INTO olala3w_core_privilege VALUES('5686','1','calendar','calendar_tracking;0');
INSERT INTO olala3w_core_privilege VALUES('5694','2','calendar','calendar_add;0');
INSERT INTO olala3w_core_privilege VALUES('5695','2','calendar','calendar_list;0');
INSERT INTO olala3w_core_privilege VALUES('5696','2','calendar','calendar_tracking;0');
INSERT INTO olala3w_core_privilege VALUES('5704','51','calendar','calendar_add;0');
INSERT INTO olala3w_core_privilege VALUES('5705','51','calendar','calendar_list;0');
INSERT INTO olala3w_core_privilege VALUES('5706','51','calendar','calendar_tracking;0');
INSERT INTO olala3w_core_privilege VALUES('5715','54','calendar','calendar_add;0');
INSERT INTO olala3w_core_privilege VALUES('5716','54','calendar','calendar_list;0');
INSERT INTO olala3w_core_privilege VALUES('5717','54','calendar','calendar_tracking;0');
INSERT INTO olala3w_core_privilege VALUES('5727','65','calendar','calendar_tracking;57');
INSERT INTO olala3w_core_privilege VALUES('5731','1','statistic','statistic_matches_export');
INSERT INTO olala3w_core_privilege VALUES('5732','1','statistic','statistic_jobs;0');
INSERT INTO olala3w_core_privilege VALUES('5733','1','statistic','statistic_matches;0');
INSERT INTO olala3w_core_privilege VALUES('5737','2','statistic','statistic_matches_export');
INSERT INTO olala3w_core_privilege VALUES('5738','2','statistic','statistic_jobs;0');
INSERT INTO olala3w_core_privilege VALUES('5739','2','statistic','statistic_matches;0');
INSERT INTO olala3w_core_privilege VALUES('5743','51','statistic','statistic_matches_export');
INSERT INTO olala3w_core_privilege VALUES('5744','51','statistic','statistic_jobs;30');
INSERT INTO olala3w_core_privilege VALUES('5745','51','statistic','statistic_matches;30');
INSERT INTO olala3w_core_privilege VALUES('5752','54','statistic','statistic_jobs_export');
INSERT INTO olala3w_core_privilege VALUES('5751','54','statistic','statistic_jobs');
INSERT INTO olala3w_core_privilege VALUES('5755','54','statistic','statistic_jobs;0');
INSERT INTO olala3w_core_privilege VALUES('5756','54','statistic','statistic_matches;0');
INSERT INTO olala3w_core_privilege VALUES('5760','65','statistic','statistic_matches_export');
INSERT INTO olala3w_core_privilege VALUES('5761','65','statistic','statistic_jobs;57');
INSERT INTO olala3w_core_privilege VALUES('5762','65','statistic','statistic_matches;57');
INSERT INTO olala3w_core_privilege VALUES('5763','67','document','document_add');
INSERT INTO olala3w_core_privilege VALUES('5764','67','document','document_list');
INSERT INTO olala3w_core_privilege VALUES('5765','67','document','document_edit');
INSERT INTO olala3w_core_privilege VALUES('5766','67','document','document;delete');
INSERT INTO olala3w_core_privilege VALUES('5767','67','calendar','calendar_add');
INSERT INTO olala3w_core_privilege VALUES('5768','67','calendar','calendar_list');
INSERT INTO olala3w_core_privilege VALUES('5769','67','calendar','calendar_tracking');
INSERT INTO olala3w_core_privilege VALUES('5770','67','calendar','calendar_edit');
INSERT INTO olala3w_core_privilege VALUES('5771','67','calendar','calendar;eye');
INSERT INTO olala3w_core_privilege VALUES('5772','67','calendar','calendar;delete');
INSERT INTO olala3w_core_privilege VALUES('5773','67','calendar','calendar_notify');
INSERT INTO olala3w_core_privilege VALUES('5774','67','calendar','calendar_add;53');
INSERT INTO olala3w_core_privilege VALUES('5775','67','calendar','calendar_list;53');
INSERT INTO olala3w_core_privilege VALUES('5776','67','calendar','calendar_tracking;53');
INSERT INTO olala3w_core_privilege VALUES('5777','67','statistic','statistic_jobs');
INSERT INTO olala3w_core_privilege VALUES('5778','67','statistic','statistic_jobs_export');
INSERT INTO olala3w_core_privilege VALUES('5779','67','statistic','statistic_matches');
INSERT INTO olala3w_core_privilege VALUES('5780','67','statistic','statistic_matches_export');
INSERT INTO olala3w_core_privilege VALUES('5781','67','statistic','statistic_jobs;53');
INSERT INTO olala3w_core_privilege VALUES('5782','67','statistic','statistic_matches;53');
INSERT INTO olala3w_core_privilege VALUES('5783','67','general','general_level');
INSERT INTO olala3w_core_privilege VALUES('5784','67','general','general_level_add');
INSERT INTO olala3w_core_privilege VALUES('5785','67','general','general_level_edit');
INSERT INTO olala3w_core_privilege VALUES('5786','67','general','general_level;delete');
INSERT INTO olala3w_core_privilege VALUES('5787','67','general','general_warning');
INSERT INTO olala3w_core_privilege VALUES('5788','67','general','general_matches');
INSERT INTO olala3w_core_privilege VALUES('5789','67','general','general_matches_add');
INSERT INTO olala3w_core_privilege VALUES('5790','67','general','general_matches_edit');
INSERT INTO olala3w_core_privilege VALUES('5791','67','general','general_matches;delete');
INSERT INTO olala3w_core_privilege VALUES('5792','67','general','general_jobs_name');
INSERT INTO olala3w_core_privilege VALUES('5793','67','general','general_jobs_name_add');
INSERT INTO olala3w_core_privilege VALUES('5794','67','general','general_jobs_name_edit');
INSERT INTO olala3w_core_privilege VALUES('5795','67','general','general_jobs_name;delete');
INSERT INTO olala3w_core_privilege VALUES('5796','67','general','general_jobs_address');
INSERT INTO olala3w_core_privilege VALUES('5797','67','general','general_jobs_address_add');
INSERT INTO olala3w_core_privilege VALUES('5798','67','general','general_jobs_address_edit');
INSERT INTO olala3w_core_privilege VALUES('5799','67','general','general_jobs_address;delete');
INSERT INTO olala3w_core_privilege VALUES('5800','67','general','general_document_type');
INSERT INTO olala3w_core_privilege VALUES('5801','67','general','general_document_type_add');
INSERT INTO olala3w_core_privilege VALUES('5802','67','general','general_document_type_edit');
INSERT INTO olala3w_core_privilege VALUES('5803','67','general','general_document_type;delete');
INSERT INTO olala3w_core_privilege VALUES('5804','67','ol','calendar');
INSERT INTO olala3w_core_privilege VALUES('5805','67','ol','statistic');
INSERT INTO olala3w_core_privilege VALUES('5807','65','ol','document');
INSERT INTO olala3w_core_privilege VALUES('5826','59','statistic','statistic_matches_export');
INSERT INTO olala3w_core_privilege VALUES('5849','59','calendar','calendar_add');
INSERT INTO olala3w_core_privilege VALUES('5812','65','document','-');
INSERT INTO olala3w_core_privilege VALUES('5827','59','statistic','statistic_jobs;56');
INSERT INTO olala3w_core_privilege VALUES('5828','59','statistic','statistic_matches;56');
INSERT INTO olala3w_core_privilege VALUES('5829','59','general','general_level');
INSERT INTO olala3w_core_privilege VALUES('5830','59','general','general_level_add');
INSERT INTO olala3w_core_privilege VALUES('5831','59','general','general_level_edit');
INSERT INTO olala3w_core_privilege VALUES('5832','59','general','general_level;delete');
INSERT INTO olala3w_core_privilege VALUES('5833','59','general','general_warning');
INSERT INTO olala3w_core_privilege VALUES('5834','59','general','general_matches');
INSERT INTO olala3w_core_privilege VALUES('5835','59','general','general_matches_add');
INSERT INTO olala3w_core_privilege VALUES('5836','59','general','general_matches_edit');
INSERT INTO olala3w_core_privilege VALUES('5837','59','general','general_matches;delete');
INSERT INTO olala3w_core_privilege VALUES('5838','59','general','general_jobs_name');
INSERT INTO olala3w_core_privilege VALUES('5839','59','general','general_jobs_name_add');
INSERT INTO olala3w_core_privilege VALUES('5840','59','general','general_jobs_name_edit');
INSERT INTO olala3w_core_privilege VALUES('5841','59','general','general_jobs_name;delete');
INSERT INTO olala3w_core_privilege VALUES('5842','59','general','general_jobs_address');
INSERT INTO olala3w_core_privilege VALUES('5843','59','general','general_jobs_address_add');
INSERT INTO olala3w_core_privilege VALUES('5844','59','general','general_jobs_address_edit');
INSERT INTO olala3w_core_privilege VALUES('5845','59','general','general_jobs_address;delete');
INSERT INTO olala3w_core_privilege VALUES('5846','59','general','general_document_type');
INSERT INTO olala3w_core_privilege VALUES('5847','59','general','general_document_type_add');
INSERT INTO olala3w_core_privilege VALUES('5848','59','general','general_document_type_edit');
INSERT INTO olala3w_core_privilege VALUES('5858','59','calendar','calendar_tracking;56');
INSERT INTO olala3w_core_privilege VALUES('5859','61','ol','statistic');
INSERT INTO olala3w_core_privilege VALUES('5861','61','general','general_level');
INSERT INTO olala3w_core_privilege VALUES('5862','61','general','general_level_add');
INSERT INTO olala3w_core_privilege VALUES('5863','61','general','general_level_edit');
INSERT INTO olala3w_core_privilege VALUES('5864','61','general','general_level;delete');
INSERT INTO olala3w_core_privilege VALUES('5865','61','general','general_warning');
INSERT INTO olala3w_core_privilege VALUES('5866','61','general','general_matches');
INSERT INTO olala3w_core_privilege VALUES('5867','61','general','general_matches_add');
INSERT INTO olala3w_core_privilege VALUES('5868','61','general','general_matches_edit');
INSERT INTO olala3w_core_privilege VALUES('5869','61','general','general_matches;delete');
INSERT INTO olala3w_core_privilege VALUES('5870','61','general','general_jobs_name');
INSERT INTO olala3w_core_privilege VALUES('5871','61','general','general_jobs_name_add');
INSERT INTO olala3w_core_privilege VALUES('5872','61','general','general_jobs_name_edit');
INSERT INTO olala3w_core_privilege VALUES('5873','61','general','general_jobs_name;delete');
INSERT INTO olala3w_core_privilege VALUES('5874','61','general','general_jobs_address');
INSERT INTO olala3w_core_privilege VALUES('5875','61','general','general_jobs_address_add');
INSERT INTO olala3w_core_privilege VALUES('5876','61','general','general_jobs_address_edit');
INSERT INTO olala3w_core_privilege VALUES('5877','61','general','general_jobs_address;delete');
INSERT INTO olala3w_core_privilege VALUES('5878','61','general','general_document_type');
INSERT INTO olala3w_core_privilege VALUES('5879','61','general','general_document_type_add');
INSERT INTO olala3w_core_privilege VALUES('5880','61','general','general_document_type_edit');
INSERT INTO olala3w_core_privilege VALUES('5881','61','general','general_document_type;delete');
INSERT INTO olala3w_core_privilege VALUES('5882','67','ol','document');

-- --------------------------------------------------------

CREATE TABLE `olala3w_core_role` (
  `role_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `comment` text NOT NULL,
  `agency` int(11) NOT NULL DEFAULT '0',
  `is_active` int(1) NOT NULL DEFAULT '1',
  `is_show` int(1) NOT NULL DEFAULT '1',
  `modified_time` int(11) NOT NULL DEFAULT '0',
  `user_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`role_id`)
) ENGINE=MyISAM AUTO_INCREMENT=70 DEFAULT CHARSET=utf8;

INSERT INTO olala3w_core_role VALUES('1','Administrator','Nhóm quản trị tối cao , quản tri website , Phân quyền quản lý cho Chi Nhánh - Xí Nghiệp - Đại Lý Cấp I ','0','1','0','1502621499','1');
INSERT INTO olala3w_core_role VALUES('2','Admin','Admin Dưới Quyền Administrator , Admin quyền Quản Lý Cấp Chi Nhánh - phân công  Công tác cho Nhân Viên thuộc quyền quản lý thuộc Chi Nhánh','0','1','0','1474429256','85');
INSERT INTO olala3w_core_role VALUES('51','BQL NDN','Quản lý công việc + Giao việc','30','1','0','1474430484','1');
INSERT INTO olala3w_core_role VALUES('69','Tổ A Trung','','53','1','1','1474609376','1');
INSERT INTO olala3w_core_role VALUES('59','BQL Phòng Công Trình','','56','1','0','1474430407','1');
INSERT INTO olala3w_core_role VALUES('60','Văn thư','Nhập văn thư','30','1','0','1474430408','1');
INSERT INTO olala3w_core_role VALUES('61','BPQL Phòng Tài Chính','','51','1','0','1474453351','1');
INSERT INTO olala3w_core_role VALUES('68','Tổ A Tín','','53','1','0','1474609277','1');
INSERT INTO olala3w_core_role VALUES('65','Tổng Giám Đốc DNSC','','57','1','0','1474430410','85');
INSERT INTO olala3w_core_role VALUES('67','BPQL Phòng Tổng Hợp','Dùng cho trưởng phòng, phó phòng, thư ký phòng Tổng hợp','53','1','0','1474430922','1');

-- --------------------------------------------------------

CREATE TABLE `olala3w_core_user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_name` varchar(16) NOT NULL,
  `password` varchar(50) NOT NULL,
  `full_name` varchar(150) NOT NULL,
  `gender` int(1) NOT NULL DEFAULT '0',
  `birthday` int(11) NOT NULL DEFAULT '0',
  `identity_card` varchar(20) NOT NULL,
  `date_of_issue` int(11) NOT NULL,
  `apply` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `address` varchar(255) NOT NULL,
  `city` varchar(255) NOT NULL,
  `agency` int(11) NOT NULL DEFAULT '0',
  `comment` text NOT NULL,
  `is_show` int(1) NOT NULL DEFAULT '0',
  `sort` int(11) NOT NULL DEFAULT '1',
  `img` varchar(255) NOT NULL DEFAULT 'no',
  `is_active` int(1) NOT NULL DEFAULT '1',
  `vote` bigint(20) NOT NULL DEFAULT '1',
  `btn_notify1` int(1) NOT NULL DEFAULT '1',
  `btn_notify2` int(1) NOT NULL DEFAULT '1',
  `click_vote` bigint(20) NOT NULL DEFAULT '1',
  `created_time` int(11) NOT NULL DEFAULT '0',
  `modified_time` int(11) NOT NULL DEFAULT '0',
  `user_id_edit` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `user_name` (`user_name`)
) ENGINE=MyISAM AUTO_INCREMENT=102 DEFAULT CHARSET=utf8;

INSERT INTO olala3w_core_user VALUES('1','admin','ca4c0178da5c3219c4150c77b16c935d','Administrator','1','1426784400','','0','Quản trị Website.','ng.quangphuc@gmail.com','0905431190','Đà Nẵng','Hà Nội','30','','1','2','u_1465483945_4feb206882b9c99a7ae94b9a960a38f8.jpg','1','5','0','1','1','1408159832','1502621160','1');
INSERT INTO olala3w_core_user VALUES('2','dev','fadf7292269ab231762dbd82694934e4','Tô Thái Huy','1','694198800','','0','Trưởng Phòng','huyto.qng@gmail.com','0974779805','Đà Nẵng','Hà Nội','0','','0','2','u_1460521242_e508a31fee198d1c24f1284cf1a84a72.jpg','1','5','1','0','1','0','1501556587','2');
INSERT INTO olala3w_core_user VALUES('65','phuongbtm','f89a8b7c34f64dec28efe328639e4ae7','Bùi Thị Minh Phương','2','722019600','','1467046800','Phương','minhphuong1811@gmail.com','0935072509','','Đà Nẵng','51','','1','16','u_1472866224_cc96c113e731e7ff7a09c30aa12031e1.jpg','1','3','1','1','1','1461054804','1474437900','65');
INSERT INTO olala3w_core_user VALUES('64','thula','3616a3135172d5d088b17379fc86c1ad','Lê Anh Thư','2','631126800','','0','Thu','anhthu.le920@gmail.com','0905334889','','Đà Nẵng','51','','1','15','u_1472866167_04b0e72359ac16cdccdb19d304b0d8d3.jpg','1','3','1','0','1','1461054691','1474453516','1');
INSERT INTO olala3w_core_user VALUES('63','thuyptt','28fc1ab36134a69b9345ffa5f627d6fe','Phạm Thị Thanh Thủy','2','371494800','','0','','thaomy10101981@gmail.com','0935999977','','Đà Nẵng','51','','1','14','no','1','3','1','1','1','1461054632','1474453532','1');
INSERT INTO olala3w_core_user VALUES('62','oanhmtt','6529d2209a31ffcadefea042c1e98914','Mai Trương Tú Oanh','2','62355600','','0','','tuoanh@ndn.com.vn','0985866606','','Đà Nẵng','51','','1','13','no','1','3','1','1','1','1461054412','1474639320','62');
INSERT INTO olala3w_core_user VALUES('61','hieutm','fc631b2ebfc764b7c7245dd2ebe4cd91','Trình Minh Hiếu','1','679856400','','1460998800','hieutm','hieutm@ndn.com.vn','0905488427','','Đà Nẵng','53','','1','12','no','1','3','1','1','1','1461027815','1468808017','1');
INSERT INTO olala3w_core_user VALUES('60','huentl','824b0a281aba5d0a1f04d7180654fef3','Nguyễn Thị Linh Huệ','2','654714000','','0','','linhhue09@gmail.com','0988357896','','Đà Nẵng','32','','0','11','no','0','3','1','1','1','1460973946','1472866465','1');
INSERT INTO olala3w_core_user VALUES('59','nganttt','d787a38cc9d56bfd6e026838811baf32','Trần Thị Thảo Ngân','2','720118800','','0','','thaongan92dh@gmail.com','01668234207','','Đà Nẵng','32','','0','10','no','0','3','1','1','1','1460973864','1472866463','1');
INSERT INTO olala3w_core_user VALUES('58','minhvx','14ad8341e2e820a902e85dcfc12766cf','Võ Xuân Minh','1','609699600','','1463504400','','minh28.hoian@gmail.com','0914444857','','Đà Nẵng','53','','1','9','no','1','3','1','1','1','1460973768','1468889810','1');
INSERT INTO olala3w_core_user VALUES('56','ducnh','22a1b67e0bf3210cf037214b4ca5971e','Nguyễn Hoàng Đức','1','686854800','','0','','duchnguyen.ndn@gmail.com','0907668345','','Đà Nẵng','32','','0','7','no','0','3','1','1','1','1460973584','1472866460','1');
INSERT INTO olala3w_core_user VALUES('57','oanhntt','7ec13f50a868bf35ee6d2fd1373f3bfd','Nguyễn Thị Thùy Oanh','2','637952400','','0','','thuyoanh2103@gmail.com','0905178865','','Đà Nẵng','53','','1','8','u_1462529095_dd2939be94e74c8c753e7e02b2f5c962.jpg','1','3','0','0','1','1460973676','1474417800','57');
INSERT INTO olala3w_core_user VALUES('54','trangntt','376af0829c597e875172ddb799d17a86','Nguyễn Thị Thùy Trang','2','643309200','201605221','1190826000','','trangnguyen22590@gmail.com','0905270399','','Đà Nẵng','32','','0','5','no','0','3','1','1','1','1460973332','1472866455','1');
INSERT INTO olala3w_core_user VALUES('55','phucnq','2c5b6816794978693d0ef9c4efcbd265','Nguyễn Quang Phúc','1','631126800','201598115','1372870800','phucnq','ng.quangphuc@gmail.com','0905431190','','Đà Nẵng','53','','1','6','u_1474417407_2b91a992f12d6336baec3662120f0695.jpg','1','3','0','0','1','1460973459','1474417407','55');
INSERT INTO olala3w_core_user VALUES('52','tinnv','9bc958a266fad79a63b1de44d0b3365f','Nguyễn Võ Tín','1','469731600','','0','38 Nguyễn Chí Thanh','nguyenvotin@gmail.com','0905279746','','Đà Nẵng','53','','1','4','u_1460541065_0df6f7c232f1bc9a37f2e9c458ef56b2.jpg','1','3','0','0','1','1460541065','1474453623','1');
INSERT INTO olala3w_core_user VALUES('53','tgd','42b39355817fc812a20b9e5bff1dd98f','Nguyễn Quang Trung','1','1476378000','','0','','quangtrung@ndn.com.vn','0913401585','Tầng 2 Lapaz Tower, 38 Nguyễn Chí Thanh, Quận Hải Châu, Tp. Đà Nẵng.','Đà Nẵng','0','','1','3','u_1461739076_4448d152fe208807655611869438022f.jpg','1','3','0','0','1','1460617299','1474609011','1');
INSERT INTO olala3w_core_user VALUES('66','thinhnv','2750fdfb5e73209da7aafdc2073da900','Nguyễn Văn Thịnh','1','660416400','142511503','1135184400','38 Nguyễn Chí Thanh','thinhnguyen1090@gmail.com','0977560269','','Đà Nẵng','35','','1','17','no','0','3','1','1','1','1461813504','1468823861','1');
INSERT INTO olala3w_core_user VALUES('67','khanhnp','4a7689dcf26f208db57272dc6b593ab7','Nguyễn Phước Khánh','1','491331600','','0','khanhnp','khanhnguyendcid@gmail.com','0905522575','','Đà Nẵng','56','','1','18','u_1472875564_8f8e32b658613c73f58fcb9743bda379.jpg','1','3','1','1','1','1461813685','1472875564','67');
INSERT INTO olala3w_core_user VALUES('68','longnd','00ec3afa622b9bfacf1dad964b7a8be8','Nguyễn Đình Long','1','507315600','','0','','longnguyen291@gmail.com','0905310612','','Đà Nẵng','36','','0','19','no','0','3','1','1','1','1461813758','1472866410','1');
INSERT INTO olala3w_core_user VALUES('69','laintt','ef34fd44a06024c41c809166b4bd5aff','Ngô Thị Thúy Lài','2','500922000','0','0','','laingothithuy@gmail.com','0932512616','','Đà Nẵng','56','','1','20','no','1','3','1','1','1','1461813887','1468808502','1');
INSERT INTO olala3w_core_user VALUES('70','minhnt','3935d1d95c2b91befaa8a38970dafc02','Nguyễn Tấn Minh','1','500058000','','0','minhnt','minhnguyentan611@gmail.com','0905673245','','Đà Nẵng','36','','0','21','no','0','3','1','1','1','1461813950','1472866420','70');
INSERT INTO olala3w_core_user VALUES('71','tuanna','8ed971817262e25981e7e30349a96147','Nguyễn Anh Tuấn','1','434307600','','0','admin','anhtuanndn@gmail.com','0935074454','','Đà Nẵng','53','','1','22','no','1','3','1','1','1','1463100574','1468808525','1');
INSERT INTO olala3w_core_user VALUES('72','dungnt','9e5b782fead4d08d32b0cd94cb8af628','Nguyễn Thị Dung','2','688669200','205530368','1479402000','38 Nguyễn Chí Thanh','dungnguyenqn91@gmail.com','0973574268','','Đà Nẵng','51','','1','16','u_1468939797_bc8013fd45ff9e5031fb1fb54cdfb79f.jpg','1','3','1','0','1','1468808867','1474605780','72');
INSERT INTO olala3w_core_user VALUES('82','phuht','b0eead5c555f0135a2c91badb95ca833','Huỳnh Thị Phú','2','708973200','205660645','1228755600','38 Nguyễn Chí Thanh','phuhuynh92@gmail.com','01687805122','','Đà Nẵng','53','','0','25','u_1471060129_a5354b0beb96d1f1162c765fb3b4fb20.jpg','0','3','1','1','1','1468826952','1473745427','82');
INSERT INTO olala3w_core_user VALUES('74','thuynt','a5efff6be64e2b47e5bd4019e5aea2fa','Nguyễn Thị Thúy','2','705258000','','1468774800','38 Nguyễn Chí Thanh','ng.quangphuc@gmail.com','0905431190','','Đà Nẵng','56','','0','18','no','0','3','1','1','1','1468823757','1472866405','1');
INSERT INTO olala3w_core_user VALUES('75','mentt','b1d89e8fc5cd6bf0b9b522c5574825eb','Trương Thị Mến','2','787942800','','1468774800','38 Nguyễn Chí Thanh','truongmen.mp@gmail.com','0938934895','','Đà Nẵng','53','','0','19','no','0','3','1','1','1','1468823823','1472866415','75');
INSERT INTO olala3w_core_user VALUES('76','hunglqp','dafc6f1a50ccb2d0adfcd670dbff1f20','Lê Quang Phước Hưng','1','729363600','','1468774800','38 Nguyễn Chí Thanh','ng.quangphuc@gmail.com','0905431190','','Đà Nẵng','56','','1','20','no','1','3','1','1','1','1468823945','1472876102','1');
INSERT INTO olala3w_core_user VALUES('77','suonghnh','6509f282f18e1d8df56e25e6d4b04745','Huỳnh Nguyễn Hàn Sương','2','772304400','','1468774800','38 Nguyễn Chí Thanh','huynhnguyenhansuong@gmail.com','01266502187','','Đà Nẵng','56','','1','21','u_1472876162_9fbb93473cce07227874e30d1b7510a0.jpg','1','3','1','1','1','1468824010','1472876162','77');
INSERT INTO olala3w_core_user VALUES('78','tamlv','921964a4922db423a4275f230f7f7a5d','Lê Văn Tâm','1','692038800','','1468774800','38 Nguyễn Chí Thanh','letam7012@gmail.com','01669927557','Số 18 Bàu Tràm Trung, P. Khuê Trung, Q. Cẩm Lệ, TP. Đà Nẵng','Đà Nẵng','51','','1','22','u_1472866508_f7283d4a116c344b5b72514d3a4ed6c7.jpg','1','3','1','1','1','1468824074','1472866508','78');
INSERT INTO olala3w_core_user VALUES('79','hoangmx','9c10a4993e5c72001a7e7adb60e4f3f4','Mai Xuân Hoàng','1','507056400','','0','38 Nguyễn Chí Thanh','hoangmx0126@gmail.com','0983845525','','Đà Nẵng','53','','0','23','no','0','3','1','1','1','1468824138','1472866428','79');
INSERT INTO olala3w_core_user VALUES('80','trinhdt','620692c96747322659ecdcc46fc37447','Đoàn Thị Trinh','2','735757200','','1463504400','38 Nguyễn Chí Thanh','trinh05ks4.3@gmail.com','0934080248','Đà Nẵng','Đà Nẵng','53','','1','24','no','1','3','0','0','1','1468824209','1474453845','1');
INSERT INTO olala3w_core_user VALUES('81','typn','23dcaf7b0066f014c9a8da0222202599','Phạm Ngọc Tý','1','535395600','','1468774800','laintt','ng.quangphuc@gmail.com','0905431190','','Đà Nẵng','56','','1','25','u_1472875562_3dd7a9ba3bcfd5326912efc68ceca2c5.jpg','1','3','1','1','1','1468824422','1472875569','81');
INSERT INTO olala3w_core_user VALUES('83','tamth','4953e5771bc5f2218c39e909652b4928','Trịnh Huy Tâm','1','210013200','','0','38 Nguyễn Chí Thanh','tamcnt2009@gmail.com','0905489049','','Đà Nẵng','53','','1','26','no','1','3','1','1','1','1468889761','0','1');
INSERT INTO olala3w_core_user VALUES('84','minhnh','67eb08fdb210ad2f9d0f0d52e6aea6a7','Nguyễn Hữu Minh','1','458931600','191500526','1081702800','','huuminhndn187@gmail.com','0905455606','','Đà Nẵng','53','','1','27','no','1','3','1','1','1','1470033541','1470120066','1');
INSERT INTO olala3w_core_user VALUES('85','dnsc','9f651eb574f264b06594ac6f8a1114ec','Dnsc','1','631126800','','1471366800','','ng.quangphuc@gmail.com','0905431190','102 Nguyễn Thị Minh Khai, Tp. Đà Nẵng','Đà Nẵng','57','','0','28','no','1','3','1','1','1','1471425643','1502160780','85');
INSERT INTO olala3w_core_user VALUES('86','dungca','05fdb08c1884e94374d0dc46828cc781','Châu Anh Dũng','1','334861200','201467510','1364576400','','dung.chauanh@gmail.com','0905045575','Đà Nẵng','Đà Nẵng','58','','1','29','u_1473153031_b7aaf9046ca81662e18991e3744832c3.jpg','1','3','1','1','1','1471429107','1473153175','86');
INSERT INTO olala3w_core_user VALUES('87','phuocdt','37fceaf9d6d663ecd6c47f97b0f8b070','Đào Thị Phước','2','633805200','','0','','phuoc.dao@dnsc.com.vn','0905155166','','Đà Nẵng','63','','1','30','u_1472454860_7e14d98ea95e179f9d762a72bc1d0137.jpg','1','3','1','1','1','1471503656','1472454860','87');
INSERT INTO olala3w_core_user VALUES('88','ngocltb','d6389d90b264aeda9a6f6236f1f5b49e','Lê Trần Bảo Ngọc','2','692557200','201608074','0','','lengoc131291@gmail.com','0935401619','','Đà Nẵng','58','','1','31','u_1471506408_5b56883f775a1cf5df65d83975fe19f1.jpg','1','3','1','1','1','1471505002','1471506408','88');
INSERT INTO olala3w_core_user VALUES('89','hangptt','a021ae5f38ee252d831d211992d77d03','Phạm Thị Thúy Hằng','2','561488400','205377075','0','','hang.pham@dnsc.com.vn','0983104409','','Đà Nẵng','58','','1','32','u_1471506675_7e744b18b47cd45078ad778c82b14b7d.jpg','1','3','1','1','1','1471505143','1471506675','89');
INSERT INTO olala3w_core_user VALUES('90','uyenvtt','f31f6efeaa2fafbd77a96660686f86cb','Võ Thị Thanh Uyên','2','642704400','201789958','0','','vothanhuyen1505@gmail.com','0934710791','','Đà Nẵng','58','','1','33','u_1471506969_e0af1a414d2e7617154d87ac3f2f35bc.jpg','1','3','1','1','1','1471505288','1471506969','90');
INSERT INTO olala3w_core_user VALUES('91','ngocnv','17ce3e7c0d9f1598aa9a8f609b7014ab','Nguyễn Văn Ngọc','1','608144400','205406646','0','','vanngocqn89@gmail.com','0905157641','','Đà Nẵng','58','','1','34','u_1472455762_58e08e99dc5eb1046b6feac14b27caf4.jpg','1','3','1','1','1','1471505404','1472455762','91');
INSERT INTO olala3w_core_user VALUES('92','hantn','ca815fb7ce610c2ec0e3a14e796b0b22','Nguyễn Thị Như Hà','2','655664400','201575039','0','','nguyenthinhuha1990@gmail.com','0906691791','','Đà Nẵng','58','','1','35','u_1471834589_c6ec59186be890f3a43b0f4f1d92eb81.jpg','1','3','1','1','1','1471505584','1471834589','92');
INSERT INTO olala3w_core_user VALUES('93','lienntn','da68b0f0e66ea58e2f3a69764b87c5a0','Nguyễn Thị Ngọc Liên','0','553194000','201555386','1425920400','','Liennguyen020486@gmail.com','0935533535','','Đà Nẵng','58','','1','36','u_1472636231_0aa688c642808c7d5715718adae41b45.jpg','1','3','1','1','1','1471506776','1472636231','93');
INSERT INTO olala3w_core_user VALUES('94','giangdth','d655bc37dc98127dd543597fc59e9058','Đặng Thị Hồng Giang','2','651085200','201614558','0','Nhân viên','giangdth22@gmail.com','0936999154','102 Nguyễn Thị Minh Khai, Đà Nẵng','Đà Nẵng','59','','1','37','u_1472693481_20057ae1744ebe0ec8f4919959957d9e.jpg','1','3','1','1','1','1471831226','1472693481','94');
INSERT INTO olala3w_core_user VALUES('95','thutta','c40b77dbe28b6e14d754552a51050807','Tăng Thị Anh Thư','2','647715600','201575711','0','thutta','tanganhthu071290@gmail.com','0935345792','','Đà Nẵng','59','','1','38','u_1471832643_e702b0036b7e343ff9346adc1c963c72.jpg','1','3','1','1','1','1471831341','1471832728','95');
INSERT INTO olala3w_core_user VALUES('96','phitdtt','d8ec1e4633c04da4d7d22ee6492ec104','Đào Thị Thanh Phit','2','707331600','205683674','0','phitdtt','thanhphit0601@gmail.com','0934129348','','Đà Nẵng','59','','1','39','u_1472453093_7ae8ab2ba016349de96f873e2f8bbb2a.jpg','1','3','1','1','1','1471831436','1472453092','96');
INSERT INTO olala3w_core_user VALUES('97','linhtl','1fcc952fb13fbeb10f87e388fe3ca0b7','Lê Thùy Linh','2','782931600','201678823','1486054800','','thuylinh96096@gmail.com','0905085477','','Đà Nẵng','53','','1','40','u_1472867685_8e8669f45cd5a6eb849a0f0939155a3d.jpg','1','3','1','1','1','1472865634','1474525980','97');
INSERT INTO olala3w_core_user VALUES('98','thinhpq','d636aa2bd0c0694f0679a75dfa6617dc','Phạm Quang Thịnh','1','631126800','201598115','1472835600','','ng.quangphuc@gmail.com','0905431190','','Đà Nẵng','56','<p>Đề nghị đổi lại thông tin&nbsp;</p>\r\n','1','40','no','1','3','1','1','1','1472866302','0','1');
INSERT INTO olala3w_core_user VALUES('99','anhnd','8e65f6392c836b89137de45ebfc49c80','Nguyễn Đông Anh','1','340822800','','0','','donganh20101980@gmail.com','0906612326','','Đà Nẵng','53','','1','37','no','1','3','1','1','1','1474255465','0','1');
INSERT INTO olala3w_core_user VALUES('100','tanmv','4dcb69046500ab4b5f43065c3a519e01','Mai Văn Tân','1','0','200993166','1206982800','','ng.quangphuc@gmail.com','0914325828','','Đà Nẵng','64','','1','38','no','1','3','1','1','1','1474258479','0','1');
INSERT INTO olala3w_core_user VALUES('101','nongt','f1b2e202935df4d20951fdbbfe4a32e2','Trần Nông','1','1474218000','200276241','1184000400','','ng.quangphuc@gmail.com','0913423020','','Đà Nẵng','64','','1','39','no','1','3','1','1','1','1474258599','0','1');

-- --------------------------------------------------------

CREATE TABLE `olala3w_document` (
  `document_id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `type` int(11) NOT NULL DEFAULT '0',
  `symbols` varchar(255) NOT NULL,
  `date_issued` int(11) NOT NULL DEFAULT '0',
  `comment` text NOT NULL,
  `file` varchar(255) NOT NULL DEFAULT '-no-',
  `content` text NOT NULL,
  `created_time` int(11) NOT NULL DEFAULT '0',
  `modified_time` int(11) NOT NULL DEFAULT '0',
  `user_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`document_id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;

INSERT INTO olala3w_document VALUES('1','đưqd','1','1','1502816400','ư1sqw','Document_1501556756_duqd.jpg','<p>đưqdqưdqưd</p>\r\n','1501556756','1501556756','1');
INSERT INTO olala3w_document VALUES('2','dqwfqf','2','dqwdqwd','1502125200','udhuwqijd','Document_1502161526_dqwfqf.png','<p>duhiqdhidh</p>\r\n','1502161525','1502161525','1');
INSERT INTO olala3w_document VALUES('3','Hệ thống pháp luật Việt Nam','3','SD21KH3','1502211600','Không có trích yếu ','Document_1502161661_he-thong-phap-luat-viet-nam.php','<p>jsdhjad</p>\r\n','1502161661','1502161661','1');
INSERT INTO olala3w_document VALUES('4','Nhan đức nguyễn','4','FEHAD','1501606800','kHÔNG CÓ TRÍNH YẾU','Document_1502161823_nhan-duc-nguyen.html','<p>kHÔNG CÓ GIÁ TRỊ NÀO Ở ĐÂY NHÉ CÁC BẠN</p>\r\n','1502161823','1502161823','1');
INSERT INTO olala3w_document VALUES('5','Nhân đức nguyễn ','4','FDE1','1502211600','kHÔNG','Document_1502162777_nhan-duc-nguyen.txt','<p>ƯQDJQWOD</p>\r\n','1502162353','1502162777','1');
INSERT INTO olala3w_document VALUES('6','Nhân đức nguyễn ','1','SFJ12','1502211600','Hảy thực hiện theo nội quy nhé bạn','Document_1502174989_nhan-duc-nguyen.txt','<p>sdjasdasidjid</p>\r\n','1502174989','1502174989','1');
INSERT INTO olala3w_document VALUES('7','Văn bản điều chỉnh','3','KTEM','1502211600','kHÔNG CÓ DẨN TRÍCH','Document_1502175123_van-ban-dieu-chinh.pdf','<p>nHÂN ĐỨC&nbsp;</p>\r\n','1502175123','1502175123','1');
INSERT INTO olala3w_document VALUES('8','Nhân đức Nguyễn 2 ','2','KTM123D','1502298000','kHÔNG CÓ DẨN XUẤT','Document_1502175240_nhan-duc-nguyen-2.txt','<p>DSADJASKLD</p>\r\n','1502175239','1502175239','1');
INSERT INTO olala3w_document VALUES('9','nHÂN ĐỨC nGuYễN','4','htmk','1502211600','Không có trích yếu ','Document_1502175327_nhan-duc-nguyen.html','<p>slkdaldk</p>\r\n','1502175326','1502175326','1');
INSERT INTO olala3w_document VALUES('10','dsaidajsd','2','díaoidja','1502211600','dhusiadhsaduada','Document_1502175374_dsaidajsd.docx','<p>ạdhsadkalsd</p>\r\n','1502175374','1502175374','1');
INSERT INTO olala3w_document VALUES('11','Nhân đức nguyễn','4','KTM123','1502211600','dhusiadhsaduada','Document_1502175511_nhan-duc-nguyen.pdf','<p>ạdhsadkalsd</p>\r\n','1502175511','1502175511','1');

-- --------------------------------------------------------

CREATE TABLE `olala3w_document_type` (
  `document_type_id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `sort` int(11) NOT NULL DEFAULT '1',
  `is_active` int(1) NOT NULL DEFAULT '1',
  `created_time` int(11) NOT NULL DEFAULT '0',
  `modified_time` int(11) NOT NULL DEFAULT '0',
  `user_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`document_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

INSERT INTO olala3w_document_type VALUES('1','Công văn','cong-van','1','1','1465440246','1465440246','2');
INSERT INTO olala3w_document_type VALUES('2','Bảo hiểm','bao-hiem','2','1','1465440253','1465440253','2');
INSERT INTO olala3w_document_type VALUES('3','Hợp đồng kinh tế','hop-dong-kinh-te','3','1','1465440260','1465440260','2');
INSERT INTO olala3w_document_type VALUES('4','Hợp đồng lao động','hop-dong-lao-dong','4','1','1465440267','1465440267','2');

-- --------------------------------------------------------

CREATE TABLE `olala3w_jobs_address` (
  `jobs_address_id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `sort` int(11) NOT NULL DEFAULT '1',
  `is_active` int(11) NOT NULL DEFAULT '1',
  `created_time` int(11) NOT NULL DEFAULT '0',
  `modified_time` int(11) NOT NULL DEFAULT '0',
  `user_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`jobs_address_id`)
) ENGINE=InnoDB AUTO_INCREMENT=235 DEFAULT CHARSET=utf8;

INSERT INTO olala3w_jobs_address VALUES('1','11 Nguyễn Hữu Thọ, Đà Nẵng','11-nguyen-huu-tho-da-nang','1','1','1460025536','1460516487','1');
INSERT INTO olala3w_jobs_address VALUES('2','193 Nguyễn Lương Bằng, Liên Chiểu, Đà Nẵng','193-nguyen-luong-bang-lien-chieu-da-nang','2','1','1460175344','1460516460','1');
INSERT INTO olala3w_jobs_address VALUES('4','111 Đinh Núp, Phường An Khê, Quận Thanh Khê, Tp Đà Nẵng','111-dinh-nup-phuong-an-khe-quan-thanh-khe-tp-da-nang','4','1','1460175880','1460516612','1');
INSERT INTO olala3w_jobs_address VALUES('5','117 Triệu Nữ Vương, Quận Hải Châu, Tp Đà Nẵng','117-trieu-nu-vuong-quan-hai-chau-tp-da-nang','3','1','1460361130','1460516567','1');
INSERT INTO olala3w_jobs_address VALUES('6','23 Hoàng Diệu, Quận Hải Châu, Tp Đà Nẵng','23-hoang-dieu-quan-hai-chau-tp-da-nang','5','1','1460516661','1460516661','1');
INSERT INTO olala3w_jobs_address VALUES('7','P. Chuyên gia','p-chuyen-gia','6','1','1460974650','1461901712','2');
INSERT INTO olala3w_jobs_address VALUES('8','Monarchy','monarchy','7','1','1461028068','1461028068','61');
INSERT INTO olala3w_jobs_address VALUES('9','NDN','ndn','8','1','1461028168','1461028168','61');
INSERT INTO olala3w_jobs_address VALUES('10','10 Lý Thường Kiệt - ĐN','10-ly-thuong-kiet-dn','9','1','1461028382','1461028382','60');
INSERT INTO olala3w_jobs_address VALUES('11','Đà Nẵng','da-nang','10','1','1461028490','1469237390','2');
INSERT INTO olala3w_jobs_address VALUES('12','38 - NCT','38-nct','11','1','1461028671','1461028671','60');
INSERT INTO olala3w_jobs_address VALUES('13','Danang Gofl','danang-gofl','12','1','1461028965','1461028965','61');
INSERT INTO olala3w_jobs_address VALUES('14','K15/10 Hoàng Diệu-ĐN','k15-10-hoang-dieu-dn','13','1','1461029002','1461029002','60');
INSERT INTO olala3w_jobs_address VALUES('15','Toyata Đà Nẵng','toyata-da-nang','14','1','1461035075','1469237483','2');
INSERT INTO olala3w_jobs_address VALUES('16','Văn phòng + Bưu điện','van-phong-buu-dien','15','1','1461115605','1461115605','54');
INSERT INTO olala3w_jobs_address VALUES('17','Văn phòng','van-phong','16','1','1461115697','1461901690','2');
INSERT INTO olala3w_jobs_address VALUES('18','Công trình Monarchy','cong-trinh-monarchy','17','1','1461115934','1461115934','54');
INSERT INTO olala3w_jobs_address VALUES('19','TTHC ĐN','tthc-dn','18','1','1461125068','1461125068','57');
INSERT INTO olala3w_jobs_address VALUES('20','Phòng tổng hợp','phong-tong-hop','19','1','1461125232','1461125232','57');
INSERT INTO olala3w_jobs_address VALUES('21','Phòng chuyên gia','phong-chuyen-gia','20','1','1461138161','1461901660','2');
INSERT INTO olala3w_jobs_address VALUES('22','Đi với anh Trung','di-voi-anh-trung','21','1','1461138501','1461901700','2');
INSERT INTO olala3w_jobs_address VALUES('24','06 Nguyễn Du','06-nguyen-du','23','1','1461742895','1461742895','55');
INSERT INTO olala3w_jobs_address VALUES('25','Hà Nội','ha-noi','24','1','1461743592','1461901651','2');
INSERT INTO olala3w_jobs_address VALUES('26','Lapaz ','lapaz','25','1','1461743724','1461901636','2');
INSERT INTO olala3w_jobs_address VALUES('27','PCG - 38 NCT','pcg-38-nct','26','1','1461744325','1469237455','2');
INSERT INTO olala3w_jobs_address VALUES('28','P. Công trình','p-cong-trinh','27','1','1461815695','1461901623','2');
INSERT INTO olala3w_jobs_address VALUES('29','Trung tâm Hành Chính','trung-tam-hanh-chinh','28','1','1461816006','1461816006','70');
INSERT INTO olala3w_jobs_address VALUES('30','31 Núi Thành','31-nui-thanh','29','1','1461816040','1461816040','69');
INSERT INTO olala3w_jobs_address VALUES('31','Phòng công trình','phong-cong-trinh','30','1','1461817453','1461901609','2');
INSERT INTO olala3w_jobs_address VALUES('32','Sở tài chính','so-tai-chinh','31','1','1461825552','1461825552','65');
INSERT INTO olala3w_jobs_address VALUES('33','210 Điên Biên Phủ','210-dien-bien-phu','32','1','1461890816','1461890816','59');
INSERT INTO olala3w_jobs_address VALUES('34','25 Yên Bái','25-yen-bai','33','1','1461893699','1461893699','60');
INSERT INTO olala3w_jobs_address VALUES('35','Thọ Quang, Sơn Trà','tho-quang-son-tra','22','1','1461897623','1461901798','2');
INSERT INTO olala3w_jobs_address VALUES('36','An Hải Tây, Sơn Trà','an-hai-tay-son-tra','34','1','1461898680','1461901817','67');
INSERT INTO olala3w_jobs_address VALUES('37','đi từng cửa hàng cung cấp','di-tung-cua-hang-cung-cap','35','1','1462237169','1462237169','58');
INSERT INTO olala3w_jobs_address VALUES('38','p tài chính','p-tai-chinh','36','1','1462238906','1462238906','65');
INSERT INTO olala3w_jobs_address VALUES('39','Kho bạc ĐN','kho-bac-dn','37','1','1462238964','1462238964','65');
INSERT INTO olala3w_jobs_address VALUES('40','Phòng tài chính','phong-tai-chinh','38','1','1462239325','1462239325','65');
INSERT INTO olala3w_jobs_address VALUES('41','Sở KHĐT','so-khdt','39','1','1462239995','1462239995','54');
INSERT INTO olala3w_jobs_address VALUES('42','Phòng công trình, 31 Núi thành','phong-cong-trinh-31-nui-thanh','40','1','1462240261','1462240261','69');
INSERT INTO olala3w_jobs_address VALUES('43','Sở kế hoạch đầu tư','so-ke-hoach-dau-tu','41','1','1462240666','1462240666','65');
INSERT INTO olala3w_jobs_address VALUES('44','Chi cục Môi trường','chi-cuc-moi-truong','42','1','1462241199','1462241199','62');
INSERT INTO olala3w_jobs_address VALUES('45','38 - NCT, 6 Nguyễn Du','38-nct-6-nguyen-du','43','1','1462241905','1469237510','2');
INSERT INTO olala3w_jobs_address VALUES('46','Công trình Xử lý nước thải','cong-trinh-xu-ly-nuoc-thai','44','1','1462246497','1462246497','67');
INSERT INTO olala3w_jobs_address VALUES('47','Trần Cao vân','tran-cao-van','45','1','1462249663','1462249663','55');
INSERT INTO olala3w_jobs_address VALUES('48','Đà Nẵng','da-nang','46','0','1462325966','1469237404','2');
INSERT INTO olala3w_jobs_address VALUES('49','27 Yên Bái','27-yen-bai','47','1','1462355308','1462355308','60');
INSERT INTO olala3w_jobs_address VALUES('50','Thừa Thiên Huế','thua-thien-hue','48','1','1462411040','1469237427','2');
INSERT INTO olala3w_jobs_address VALUES('51','TTPTQĐ','ttptqd','49','1','1462497675','1462497675','65');
INSERT INTO olala3w_jobs_address VALUES('52','TT Hành chính','tt-hanh-chinh','50','1','1462521427','1469237440','2');
INSERT INTO olala3w_jobs_address VALUES('53','Trần Quốc Toản','tran-quoc-toan','51','1','1462771495','1462771495','67');
INSERT INTO olala3w_jobs_address VALUES('54','38 - NCT, 10 Lý Thường Kiệt','38-nct-10-ly-thuong-kiet','52','1','1462779582','1462779582','60');
INSERT INTO olala3w_jobs_address VALUES('55','83 tô hiệu đà nẵng + 141 Lê duẩn','83-to-hieu-da-nang-141-le-duan','53','1','1462928601','1462928601','59');
INSERT INTO olala3w_jobs_address VALUES('56','Danang Plaza','danang-plaza','54','1','1462929000','1469237470','2');
INSERT INTO olala3w_jobs_address VALUES('57','Hòa Mỹ','hoa-my','55','1','1462933765','1462933765','54');
INSERT INTO olala3w_jobs_address VALUES('58','p công trình','p-cong-trinh','56','1','1462938279','1462938279','69');
INSERT INTO olala3w_jobs_address VALUES('59','141 hoàng hoa thám','141-hoang-hoa-tham','57','1','1463109163','1463109163','60');
INSERT INTO olala3w_jobs_address VALUES('60','khu E nam cầu cẩm lệ','khu-e-nam-cau-cam-le','58','1','1463109396','1463109396','71');
INSERT INTO olala3w_jobs_address VALUES('61','chung cư khu E- nam cầu cẩm lệ','chung-cu-khu-e-nam-cau-cam-le','59','1','1463109644','1463109644','71');
INSERT INTO olala3w_jobs_address VALUES('62','Quãng trị','quang-tri','60','1','1463185880','1463185880','61');
INSERT INTO olala3w_jobs_address VALUES('63','Quận Cẩm Lệ','quan-cam-le','61','1','1463359430','1463359430','65');
INSERT INTO olala3w_jobs_address VALUES('64','Hòa minh','hoa-minh','62','1','1463364021','1463364021','71');
INSERT INTO olala3w_jobs_address VALUES('65','102 Nguyễn Thị Minh Khai','102-nguyen-thi-minh-khai','63','1','1463368556','1463368556','66');
INSERT INTO olala3w_jobs_address VALUES('66','Văn phòng + Công trình','van-phong-cong-trinh','64','1','1463390127','1463390127','54');
INSERT INTO olala3w_jobs_address VALUES('67','Hội an','hoi-an','65','1','1463466795','1463466795','61');
INSERT INTO olala3w_jobs_address VALUES('68','Cty gạch Bạch Mã','cty-gach-bach-ma','66','1','1463568035','1463568035','57');
INSERT INTO olala3w_jobs_address VALUES('69','80 HÀ Tông Quyền','80-ha-tong-quyen','67','1','1463629842','1463629842','59');
INSERT INTO olala3w_jobs_address VALUES('70','HÀ Tông Quyền','ha-tong-quyen','68','1','1463647833','1463647833','59');
INSERT INTO olala3w_jobs_address VALUES('71','CT AN Trung + 38 NCT','ct-an-trung-38-nct','69','1','1463647960','1463647960','59');
INSERT INTO olala3w_jobs_address VALUES('72','chung cư hòa xuân','chung-cu-hoa-xuan','70','1','1463791663','1463791663','71');
INSERT INTO olala3w_jobs_address VALUES('73','96 Quang trung','96-quang-trung','71','1','1463970079','1463970079','60');
INSERT INTO olala3w_jobs_address VALUES('74',' HÀ Tông Quyền','ha-tong-quyen','72','1','1463986943','1463986943','59');
INSERT INTO olala3w_jobs_address VALUES('75','Công ty Huỳnh Anh Khoa','cong-ty-huynh-anh-khoa','73','1','1463990411','1463990411','57');
INSERT INTO olala3w_jobs_address VALUES('76','quảng ngãi','quang-ngai','74','1','1464777651','1464777651','61');
INSERT INTO olala3w_jobs_address VALUES('77','bà nà ,da nang gofl','ba-na-da-nang-gofl','75','1','1464919484','1464919484','61');
INSERT INTO olala3w_jobs_address VALUES('78','quảng ngãi, tam kì','quang-ngai-tam-ki','76','1','1464919526','1464919526','61');
INSERT INTO olala3w_jobs_address VALUES('79','Ks bamboo','ks-bamboo','77','1','1465003587','1465003587','61');
INSERT INTO olala3w_jobs_address VALUES('80','','','78','1','1465361613','1465361613','61');
INSERT INTO olala3w_jobs_address VALUES('81','miếu bông','mieu-bong','79','1','1465520412','1465520412','61');
INSERT INTO olala3w_jobs_address VALUES('82','hòa khánh','hoa-khanh','80','1','1466148280','1466148280','71');
INSERT INTO olala3w_jobs_address VALUES('83','khu trung nghĩa','khu-trung-nghia','81','1','1466579945','1466579945','71');
INSERT INTO olala3w_jobs_address VALUES('84','chung cư số 6 Nguyễn du','chung-cu-so-6-nguyen-du','82','1','1466652971','1466652971','71');
INSERT INTO olala3w_jobs_address VALUES('85','khu Trung nghĩa và Hòa mỹ','khu-trung-nghia-va-hoa-my','83','1','1467110464','1467110464','71');
INSERT INTO olala3w_jobs_address VALUES('86','Tam ki','tam-ki','84','1','1467186484','1467186484','61');
INSERT INTO olala3w_jobs_address VALUES('87','Đà Nẵng tam kì','da-nang-tam-ki','85','1','1467424756','1467424756','61');
INSERT INTO olala3w_jobs_address VALUES('88','quy nhơn','quy-nhon','86','1','1468199645','1468199645','61');
INSERT INTO olala3w_jobs_address VALUES('89','Kho Công ty CP Đầu tư phát triển Nhà Đà Nẵng','kho-cong-ty-cp-dau-tu-phat-trien-nha-da-nang','87','1','1468810054','1468810054','72');
INSERT INTO olala3w_jobs_address VALUES('90','Trung tâm phát triển quỹ đất','trung-tam-phat-trien-quy-dat','88','1','1468810423','1468810423','62');
INSERT INTO olala3w_jobs_address VALUES('91','UBND quận Liên Chiểu','ubnd-quan-lien-chieu','89','1','1468810808','1468810808','62');
INSERT INTO olala3w_jobs_address VALUES('92','UBND quận Cẩm Lệ, Hải Châu','ubnd-quan-cam-le-hai-chau','90','1','1468815092','1468815092','63');
INSERT INTO olala3w_jobs_address VALUES('93','Phòng TGĐ','phong-tgd','91','1','1468815922','1468815922','72');
INSERT INTO olala3w_jobs_address VALUES('94','Phòng Văn thư công ty CP đầu tư phát triển Nhà Đà Nãng','phong-van-thu-cong-ty-cp-dau-tu-phat-trien-nha-da-nang','92','1','1468816168','1468816168','72');
INSERT INTO olala3w_jobs_address VALUES('95','38 Nguyễn Chí Thanh','38-nguyen-chi-thanh','93','1','1468825688','1468825688','72');
INSERT INTO olala3w_jobs_address VALUES('96','Công trình Monarchy A','cong-trinh-monarchy-a','94','1','1468827870','1468827870','75');
INSERT INTO olala3w_jobs_address VALUES('97','Phòng kho Công ty CP đầu tư phát triển Nhà Đà Nẵng','phong-kho-cong-ty-cp-dau-tu-phat-trien-nha-da-nang','95','1','1468831783','1468831783','72');
INSERT INTO olala3w_jobs_address VALUES('98','Phòng kỹ thuật ĐLĐN','phong-ky-thuat-dldn','96','1','1468832709','1468832709','52');
INSERT INTO olala3w_jobs_address VALUES('99','Phòng kỹ thuật ĐLLC','phong-ky-thuat-dllc','97','1','1468832912','1468832912','52');
INSERT INTO olala3w_jobs_address VALUES('100','Bận việc gia đình','ban-viec-gia-dinh','98','1','1468834272','1468834272','52');
INSERT INTO olala3w_jobs_address VALUES('101','Công ty INCAB','cong-ty-incab','99','1','1468835807','1468835807','52');
INSERT INTO olala3w_jobs_address VALUES('102','Kho Hòa Phát','kho-hoa-phat','100','1','1468838925','1468838925','74');
INSERT INTO olala3w_jobs_address VALUES('103','CC An Trung, Kho Miếu Bông','cc-an-trung-kho-mieu-bong','101','1','1468839526','1468839526','74');
INSERT INTO olala3w_jobs_address VALUES('104','Khu Tây Bắc','khu-tay-bac','102','1','1468889997','1468889997','83');
INSERT INTO olala3w_jobs_address VALUES('105','văn phòng cty PCG - 38 nguyễn Chí Thanh','van-phong-cty-pcg-38-nguyen-chi-thanh','102','1','1468889997','1468889997','80');
INSERT INTO olala3w_jobs_address VALUES('106','Căn hộ Monarchy A','can-ho-monarchy-a','104','1','1468890160','1468890160','80');
INSERT INTO olala3w_jobs_address VALUES('107','Phòng họp','phong-hop','105','1','1468896191','1468896191','57');
INSERT INTO olala3w_jobs_address VALUES('108','chung cư khu E2, khối nhà B2- nam cầu cẩm lệ','chung-cu-khu-e2-khoi-nha-b2-nam-cau-cam-le','106','1','1468911013','1468911013','71');
INSERT INTO olala3w_jobs_address VALUES('109','CTy Cấp Thoát Nước, CTy Đạt Hòa, Cty Việt ngày Mai','cty-cap-thoat-nuoc-cty-dat-hoa-cty-viet-ngay-mai','107','1','1468911666','1468911666','69');
INSERT INTO olala3w_jobs_address VALUES('110','Công trình Monarchy, Miếu Bông','cong-trinh-monarchy-mieu-bong','108','1','1468911873','1468911873','69');
INSERT INTO olala3w_jobs_address VALUES('111','đại lý xe','dai-ly-xe','109','1','1468914337','1468914337','83');
INSERT INTO olala3w_jobs_address VALUES('112','Kho lưu trữ','kho-luu-tru','110','1','1468979239','1468979239','78');
INSERT INTO olala3w_jobs_address VALUES('113','dại lý xe ford','dai-ly-xe-ford','111','1','1469089863','1469089863','83');
INSERT INTO olala3w_jobs_address VALUES('114','Phòng TH','phong-th','112','1','1469156020','1469156020','72');
INSERT INTO olala3w_jobs_address VALUES('115','phòng làm việc Ban QLDA - số 40 đường Ông Ích Đường','phong-lam-viec-ban-qlda-so-40-duong-ong-ich-duong','113','1','1469159641','1469159641','72');
INSERT INTO olala3w_jobs_address VALUES('116','Bể sử lý nước thải','be-su-ly-nuoc-thai','114','1','1469238751','1469238751','55');
INSERT INTO olala3w_jobs_address VALUES('117','Ngân hàng','ngan-hang','115','1','1469246011','1469246011','78');
INSERT INTO olala3w_jobs_address VALUES('118','NDX','ndx','116','1','1469246198','1469246198','78');
INSERT INTO olala3w_jobs_address VALUES('119','Khu An Trung','khu-an-trung','117','1','1469248815','1469248815','76');
INSERT INTO olala3w_jobs_address VALUES('120','điện lực','dien-luc','118','1','1469410549','1469410549','71');
INSERT INTO olala3w_jobs_address VALUES('121','Phòng tổng hợp, công trình','phong-tong-hop-cong-trinh','119','1','1469410822','1469410822','71');
INSERT INTO olala3w_jobs_address VALUES('122','Phòng họp Công ty','phong-hop-cong-ty','120','1','1469435415','1469435415','72');
INSERT INTO olala3w_jobs_address VALUES('123','Khách sạn Minh Toàn Galaxy','khach-san-minh-toan-galaxy','121','1','1469494775','1469494775','72');
INSERT INTO olala3w_jobs_address VALUES('124','Cty Phú Tài','cty-phu-tai','122','1','1469497958','1469497958','69');
INSERT INTO olala3w_jobs_address VALUES('125','Cty Quân Kiệt','cty-quan-kiet','123','1','1469498615','1469498615','69');
INSERT INTO olala3w_jobs_address VALUES('126',' Kho Miếu Bông','kho-mieu-bong','124','1','1469499012','1469499012','69');
INSERT INTO olala3w_jobs_address VALUES('127','347-349 Trần hưng Đạo','347-349-tran-hung-dao','125','1','1469517099','1469517099','62');
INSERT INTO olala3w_jobs_address VALUES('128','Mỏ đất Tây nam Hòa Cầm','mo-dat-tay-nam-hoa-cam','126','1','1469517172','1469517172','62');
INSERT INTO olala3w_jobs_address VALUES('129','Quận Cẩm Lệ + TT Đo đạc bản đồ','quan-cam-le-tt-do-dac-ban-do','127','1','1469517390','1469517390','62');
INSERT INTO olala3w_jobs_address VALUES('130','UB Huyện Hòa Vang+ UBP + chủ hộ','ub-huyen-hoa-vang-ubp-chu-ho','128','1','1469517597','1469517597','62');
INSERT INTO olala3w_jobs_address VALUES('131','Sở Công thương','so-cong-thuong','129','1','1469519948','1469519948','62');
INSERT INTO olala3w_jobs_address VALUES('132',' miếu bông và kho hòa phát','mieu-bong-va-kho-hoa-phat','130','1','1469522703','1469522703','61');
INSERT INTO olala3w_jobs_address VALUES('133','KS Luxury 205 Trần Phú','ks-luxury-205-tran-phu','131','1','1469524353','1469524353','62');
INSERT INTO olala3w_jobs_address VALUES('134','50B(nguyễn du)','50b-nguyen-du','132','1','1469529103','1469529103','83');
INSERT INTO olala3w_jobs_address VALUES('135','Kho Hòa Phát, An Khê','kho-hoa-phat-an-khe','133','1','1469589352','1469589352','69');
INSERT INTO olala3w_jobs_address VALUES('136','Công Ty cp xây lắp phát triển nhà Đà Nẵng','cong-ty-cp-xay-lap-phat-trien-nha-da-nang','134','1','1469603220','1469603220','77');
INSERT INTO olala3w_jobs_address VALUES('137','sàn ndn','san-ndn','135','1','1469606248','1469606248','82');
INSERT INTO olala3w_jobs_address VALUES('138','đại lý xe ford','dai-ly-xe-ford','136','1','1469677877','1469677877','83');
INSERT INTO olala3w_jobs_address VALUES('139','Khách sạn Luxury','khach-san-luxury','137','1','1469700497','1469700497','81');
INSERT INTO olala3w_jobs_address VALUES('140','công trình','cong-trinh','138','1','1469700821','1469700821','83');
INSERT INTO olala3w_jobs_address VALUES('141','Tia Sáng Mới','tia-sang-moi','139','1','1469761190','1469761190','61');
INSERT INTO olala3w_jobs_address VALUES('142','văn phòng - 38 Nguyễn Chí Thanh','van-phong-38-nguyen-chi-thanh','140','1','1469854389','1469854389','80');
INSERT INTO olala3w_jobs_address VALUES('143','khách sạn Trendy','khach-san-trendy','141','1','1470013110','1470013110','82');
INSERT INTO olala3w_jobs_address VALUES('144','BIDV','bidv','142','1','1470016217','1470016217','57');
INSERT INTO olala3w_jobs_address VALUES('145','UBND Q cẩm Lệ','ubnd-q-cam-le','143','1','1470035868','1470035868','57');
INSERT INTO olala3w_jobs_address VALUES('146','Ngoài công ty','ngoai-cong-ty','144','1','1470036829','1470036829','57');
INSERT INTO olala3w_jobs_address VALUES('147','điểm đăng kiểm xe','diem-dang-kiem-xe','145','1','1470042891','1470042891','83');
INSERT INTO olala3w_jobs_address VALUES('148','TSM','tsm','146','1','1470043616','1470043616','61');
INSERT INTO olala3w_jobs_address VALUES('149','Công Ty Quân Kiệt','cong-ty-quan-kiet','147','1','1470102383','1470102383','69');
INSERT INTO olala3w_jobs_address VALUES('150','Cty Phú Tài+ 555 Trường chinh','cty-phu-tai-555-truong-chinh','148','1','1470102516','1470102516','69');
INSERT INTO olala3w_jobs_address VALUES('151','Cty Loan Thi , Cty Phú Tài','cty-loan-thi-cty-phu-tai','149','1','1470103411','1470103411','69');
INSERT INTO olala3w_jobs_address VALUES('152','Kho Hòa Phát+ Kho Khê','kho-hoa-phat-kho-khe','150','1','1470198275','1470198275','77');
INSERT INTO olala3w_jobs_address VALUES('153','Công ty CDC','cong-ty-cdc','151','1','1470198400','1470198400','67');
INSERT INTO olala3w_jobs_address VALUES('154','Cty Cấp nước, Công Ty Điện','cty-cap-nuoc-cong-ty-dien','152','1','1470385491','1470385491','69');
INSERT INTO olala3w_jobs_address VALUES('155','UBND xã Hòa Nhơn','ubnd-xa-hoa-nhon','153','1','1470455529','1470455529','81');
INSERT INTO olala3w_jobs_address VALUES('156','Cty cây xanh','cty-cay-xanh','154','1','1470620245','1470620245','71');
INSERT INTO olala3w_jobs_address VALUES('157','72 Hải Phòng','72-hai-phong','155','1','1470640222','1470640222','55');
INSERT INTO olala3w_jobs_address VALUES('158','KDC Mân Thái 2 Mở Rộng','kdc-man-thai-2-mo-rong','156','1','1470724645','1470724645','84');
INSERT INTO olala3w_jobs_address VALUES('159','azura','azura','157','1','1470888218','1470888218','76');
INSERT INTO olala3w_jobs_address VALUES('160',' Khu an trung ','khu-an-trung','158','1','1470888334','1470888334','76');
INSERT INTO olala3w_jobs_address VALUES('161','chung cư khu E2, khối nhà B1- Nam cầu Cẩm Lệ','chung-cu-khu-e2-khoi-nha-b1-nam-cau-cam-le','159','1','1470889303','1470889303','81');
INSERT INTO olala3w_jobs_address VALUES('162','CT Hòa Cầm','ct-hoa-cam','160','1','1470889580','1470889580','81');
INSERT INTO olala3w_jobs_address VALUES('163','Trạm bê tông NDX','tram-be-tong-ndx','161','1','1470907555','1470907555','78');
INSERT INTO olala3w_jobs_address VALUES('164','16 Võ Văn Kiệt, Quận 1 TP HCM','16-vo-van-kiet-quan-1-tp-hcm','162','1','1470995039','1470995039','72');
INSERT INTO olala3w_jobs_address VALUES('165','Cửa hàng thiết bị vệ sinh','cua-hang-thiet-bi-ve-sinh','163','1','1471051369','1471051369','80');
INSERT INTO olala3w_jobs_address VALUES('166','An Trung, Hòa Cầm, Mân Thái MR','an-trung-hoa-cam-man-thai-mr','164','1','1471054600','1471054600','81');
INSERT INTO olala3w_jobs_address VALUES('167','công trình Hòa Cầm','cong-trinh-hoa-cam','165','1','1471222962','1471222962','84');
INSERT INTO olala3w_jobs_address VALUES('168','công ty cây xanh','cong-ty-cay-xanh','166','1','1471253864','1471253864','71');
INSERT INTO olala3w_jobs_address VALUES('169','Đà Nẵng - KonTum','da-nang-kontum','167','1','1471336386','1471336386','61');
INSERT INTO olala3w_jobs_address VALUES('170','Cty thảo tân, cty vật liệu xây dựng','cty-thao-tan-cty-vat-lieu-xay-dung','168','1','1471396649','1471396649','69');
INSERT INTO olala3w_jobs_address VALUES('171','Cty Vật liệu xây dựng, Cty Thảo Tân','cty-vat-lieu-xay-dung-cty-thao-tan','169','1','1471396747','1471396747','69');
INSERT INTO olala3w_jobs_address VALUES('172','kho miếu bông, An Trung','kho-mieu-bong-an-trung','170','1','1471396907','1471396907','69');
INSERT INTO olala3w_jobs_address VALUES('173','Cty Phương Linh','cty-phuong-linh','171','1','1471396986','1471396986','69');
INSERT INTO olala3w_jobs_address VALUES('174','Cty Minh Thành','cty-minh-thanh','172','1','1471397114','1471397114','69');
INSERT INTO olala3w_jobs_address VALUES('175','kho An Khê','kho-an-khe','173','1','1471397206','1471397206','69');
INSERT INTO olala3w_jobs_address VALUES('176','Đồi đất Hòa Nhơn','doi-dat-hoa-nhon','174','1','1471590096','1471590096','81');
INSERT INTO olala3w_jobs_address VALUES('177','Phòng A.Trung','phong-a-trung','175','1','1471591585','1471591585','80');
INSERT INTO olala3w_jobs_address VALUES('178','Phòng công tình','phong-cong-tinh','176','1','1471832307','1471832307','77');
INSERT INTO olala3w_jobs_address VALUES('179','Phòng Môi giới - Cty CP Chứng khoán Đà Nẵng','phong-moi-gioi-cty-cp-chung-khoan-da-nang','177','1','1471833533','1471833533','93');
INSERT INTO olala3w_jobs_address VALUES('180','P.Môi giới - Cty CP Chứng khoán Đà Nẵng','p-moi-gioi-cty-cp-chung-khoan-da-nang','178','1','1471833739','1471833739','93');
INSERT INTO olala3w_jobs_address VALUES('181','Sở Tài Nguyên','so-tai-nguyen','179','1','1471836143','1471836143','67');
INSERT INTO olala3w_jobs_address VALUES('182','Phòng TV-TC Công ty CP chứng khoán ĐN','phong-tv-tc-cong-ty-cp-chung-khoan-dn','180','1','1471836155','1471836155','95');
INSERT INTO olala3w_jobs_address VALUES('183','DNSC','dnsc','181','1','1471848166','1471848166','87');
INSERT INTO olala3w_jobs_address VALUES('184','Phòng tư vấn tài chính','phong-tu-van-tai-chinh','182','1','1471848888','1471848888','96');
INSERT INTO olala3w_jobs_address VALUES('185','Cafe a Sinh 102 NTMK','cafe-a-sinh-102-ntmk','183','1','1471848992','1471848992','87');
INSERT INTO olala3w_jobs_address VALUES('186','Công ty CP chứng khoán ĐN','cong-ty-cp-chung-khoan-dn','184','1','1471853666','1471853666','78');
INSERT INTO olala3w_jobs_address VALUES('187','Cty Cấp nước','cty-cap-nuoc','185','1','1471922966','1471922966','71');
INSERT INTO olala3w_jobs_address VALUES('188','Kho hòa phát, Kho miếu bông','kho-hoa-phat-kho-mieu-bong','186','1','1471923806','1471923806','69');
INSERT INTO olala3w_jobs_address VALUES('189','KHu B Đà Nẵng Plaza','khu-b-da-nang-plaza','187','1','1471924458','1471924458','69');
INSERT INTO olala3w_jobs_address VALUES('190','CÔNG TRÌNH MÂN THÁI II MR','cong-trinh-man-thai-ii-mr','188','1','1472012468','1472012468','84');
INSERT INTO olala3w_jobs_address VALUES('191','239 - Nguyễn Hữu Thọ','239-nguyen-huu-tho','189','1','1472012575','1472012575','84');
INSERT INTO olala3w_jobs_address VALUES('192','monachy','monachy','190','1','1472021753','1472021753','76');
INSERT INTO olala3w_jobs_address VALUES('193','SKH','skh','191','1','1472086477','1472086477','65');
INSERT INTO olala3w_jobs_address VALUES('194','Hòa Hiệp, Trung Nghĩa','hoa-hiep-trung-nghia','192','1','1472259818','1472259818','81');
INSERT INTO olala3w_jobs_address VALUES('195','Phòng tài chính, Phòng tổng hợp','phong-tai-chinh-phong-tong-hop','193','1','1472264266','1472264266','78');
INSERT INTO olala3w_jobs_address VALUES('196','Cục thuế TP. Đà Nẵng','cuc-thue-tp-da-nang','194','1','1472463686','1472463686','78');
INSERT INTO olala3w_jobs_address VALUES('197','Công ty Xử lý nước thải','cong-ty-xu-ly-nuoc-thai','195','1','1472464774','1472464774','71');
INSERT INTO olala3w_jobs_address VALUES('198','Bể xử lý nước thải Sơn Trà,  Tây Bắc','be-xu-ly-nuoc-thai-son-tra-tay-bac','196','1','1472521052','1472521052','81');
INSERT INTO olala3w_jobs_address VALUES('199','kiểm tra, hạch toán giao dịch mua bán NĐT','kiem-tra-hach-toan-giao-dich-mua-ban-ndt','197','1','1472610469','1472610469','95');
INSERT INTO olala3w_jobs_address VALUES('200','Phòng tài chính, Cục thuế TP ĐN','phong-tai-chinh-cuc-thue-tp-dn','198','1','1472625967','1472625967','78');
INSERT INTO olala3w_jobs_address VALUES('201','Sở tài chính+ Sở kế hoạch','so-tai-chinh-so-ke-hoach','199','1','1472627088','1472627088','65');
INSERT INTO olala3w_jobs_address VALUES('202','Mỏ đất TNHC','mo-dat-tnhc','200','1','1472693063','1472693063','62');
INSERT INTO olala3w_jobs_address VALUES('203','VP 38 NCT','vp-38-nct','201','1','1472693950','1472693950','62');
INSERT INTO olala3w_jobs_address VALUES('204','TBD','tbd','202','1','1472694148','1472694148','62');
INSERT INTO olala3w_jobs_address VALUES('205','BQLDA','bqlda','203','1','1472695960','1472695960','62');
INSERT INTO olala3w_jobs_address VALUES('206','Sở KHĐT & STC & KB','so-khdt-stc-kb','204','1','1472696442','1472696442','62');
INSERT INTO olala3w_jobs_address VALUES('207','PTC','ptc','205','1','1472696776','1472696776','62');
INSERT INTO olala3w_jobs_address VALUES('208','Kho MB + HP + AK','kho-mb-hp-ak','206','1','1472697179','1472697179','62');
INSERT INTO olala3w_jobs_address VALUES('209','MonarchyA','monarchya','207','1','1472697455','1472697455','62');
INSERT INTO olala3w_jobs_address VALUES('210','NDN, NDX','ndn-ndx','208','1','1472867200','1472867200','97');
INSERT INTO olala3w_jobs_address VALUES('211','sdfsdf','sdfsdf','209','1','1473067839','1473067839','65');
INSERT INTO olala3w_jobs_address VALUES('212','VP Công ty ','vp-cong-ty','210','1','1473132381','1473132381','62');
INSERT INTO olala3w_jobs_address VALUES('213','Cty CDC','cty-cdc','211','1','1473207594','1473207594','67');
INSERT INTO olala3w_jobs_address VALUES('214','CT: BXTNT + T Bắc','ct-bxtnt-t-bac','212','1','1473238360','1473238360','81');
INSERT INTO olala3w_jobs_address VALUES('215','ct: GT Hòa Cầm','ct-gt-hoa-cam','213','1','1473238931','1473238931','81');
INSERT INTO olala3w_jobs_address VALUES('216','Kho Miếu Bông + kho Hoà phát + kho An Khê','kho-mieu-bong-kho-hoa-phat-kho-an-khe','214','1','1473239135','1473239135','81');
INSERT INTO olala3w_jobs_address VALUES('217','Bể xử lý nước thải Sơn Trà,  Tây Bắc, an trung','be-xu-ly-nuoc-thai-son-tra-tay-bac-an-trung','215','1','1473638846','1473638846','76');
INSERT INTO olala3w_jobs_address VALUES('218','CC An Trung','cc-an-trung','216','1','1473638942','1473638942','76');
INSERT INTO olala3w_jobs_address VALUES('219','Incosaf','incosaf','217','1','1473640271','1473640271','52');
INSERT INTO olala3w_jobs_address VALUES('220','Cty Thái Bình Dương','cty-thai-binh-duong','218','1','1473640590','1473640590','55');
INSERT INTO olala3w_jobs_address VALUES('221','Sở Giao thông','so-giao-thong','219','1','1473640597','1473640597','52');
INSERT INTO olala3w_jobs_address VALUES('222','KDC Hòa Cầm','kdc-hoa-cam','220','1','1473740835','1473740835','81');
INSERT INTO olala3w_jobs_address VALUES('223','NDX, Trạm bê tông NDX','ndx-tram-be-tong-ndx','221','1','1473748575','1473748575','97');
INSERT INTO olala3w_jobs_address VALUES('224','Công đoàn cơ sở Hải Châu','cong-doan-co-so-hai-chau','222','1','1473824635','1473824635','72');
INSERT INTO olala3w_jobs_address VALUES('225','NDN, Công trình Monarchy','ndn-cong-trinh-monarchy','223','1','1474014298','1474014298','97');
INSERT INTO olala3w_jobs_address VALUES('226','Phòng tài chính & Kho Bạc','phong-tai-chinh-kho-bac','224','1','1474077213','1474077213','65');
INSERT INTO olala3w_jobs_address VALUES('227','Kho Hòa Phát+ Kho Miếu Bông','kho-hoa-phat-kho-mieu-bong','225','1','1474081668','1474081668','98');
INSERT INTO olala3w_jobs_address VALUES('228','Khu E1','khu-e1','226','1','1474252914','1474252914','57');
INSERT INTO olala3w_jobs_address VALUES('229','SXD','sxd','227','1','1474254237','1474254237','52');
INSERT INTO olala3w_jobs_address VALUES('230','Sở XD','so-xd','228','1','1474254644','1474254644','52');
INSERT INTO olala3w_jobs_address VALUES('231','Monarchy B','monarchy-b','229','1','1474255326','1474255326','52');
INSERT INTO olala3w_jobs_address VALUES('232','Công trình Xử lý nước thải + Tây Bắc','cong-trinh-xu-ly-nuoc-thai-tay-bac','230','1','1474600632','1474600632','81');
INSERT INTO olala3w_jobs_address VALUES('233','Công trình Monarchy + Phòng CT','cong-trinh-monarchy-phong-ct','231','1','1474600792','1474600792','81');
INSERT INTO olala3w_jobs_address VALUES('234','<script>alert(1)</script>','alert-1','232','1','1502337137','1502337137','1');

-- --------------------------------------------------------

CREATE TABLE `olala3w_jobs_name` (
  `jobs_name_id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `sort` int(11) NOT NULL DEFAULT '1',
  `is_active` int(1) NOT NULL DEFAULT '1',
  `created_time` int(11) NOT NULL DEFAULT '0',
  `modified_time` int(11) NOT NULL DEFAULT '0',
  `user_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`jobs_name_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2000 DEFAULT CHARSET=utf8;

INSERT INTO olala3w_jobs_name VALUES('1470','Công việc ngày mới','cong-viec-ngay-moi','17','1','1472641811','1502162787','2');
INSERT INTO olala3w_jobs_name VALUES('1471','PHMT Mỏ đất TNHC','phmt-mo-dat-tnhc','2','1','1472692053','1472692053','62');
INSERT INTO olala3w_jobs_name VALUES('1472','Đền bù 4 hộ Dự án 5ha Rừng HN','den-bu-4-ho-du-an-5ha-rung-hn','3','1','1472692301','1472692301','62');
INSERT INTO olala3w_jobs_name VALUES('1473','CT PHMT Mỏ đất TNHC','ct-phmt-mo-dat-tnhc','4','1','1472693063','1472693063','62');
INSERT INTO olala3w_jobs_name VALUES('1474','Giá vốn Monarchy A','gia-von-monarchy-a','5','1','1472693518','1472693518','62');
INSERT INTO olala3w_jobs_name VALUES('1475','HĐ bảo hiểm Móng Tầng hầm Monarchy B','hd-bao-hiem-mong-tang-ham-monarchy-b','6','1','1472693950','1472693950','62');
INSERT INTO olala3w_jobs_name VALUES('1476','Cài chương trình Bravo - TBD ','cai-chuong-trinh-bravo-tbd','7','1','1472694148','1472694148','62');
INSERT INTO olala3w_jobs_name VALUES('1477','Thu hồi tạm ứng HM Cây xanh Khu E (gđ1+2)','thu-hoi-tam-ung-hm-cay-xanh-khu-e-gd1-2','8','1','1472695610','1472695610','62');
INSERT INTO olala3w_jobs_name VALUES('1478','Ứng vốn SN + GTTN Quá Giáng 3.5 tỷ','ung-von-sn-gttn-qua-giang-3-5-ty','9','1','1472695960','1472695960','62');
INSERT INTO olala3w_jobs_name VALUES('1479','Đăng tin mảng TC-NH','dang-tin-mang-tc-nh','10','1','1472696282','1472696282','90');
INSERT INTO olala3w_jobs_name VALUES('1480','Nhận lệnh','nhan-lenh','11','1','1472696307','1472696307','90');
INSERT INTO olala3w_jobs_name VALUES('1481','Theo dõi tin tức, theo dõi TK KH','theo-doi-tin-tuc-theo-doi-tk-kh','12','1','1472696335','1472696335','90');
INSERT INTO olala3w_jobs_name VALUES('1482','Tiếp nhận HSơ Mở/Đóng TK (nếu có)','tiep-nhan-hso-mo-dong-tk-neu-co','13','1','1472696363','1472696363','90');
INSERT INTO olala3w_jobs_name VALUES('1483','Chốt quyền VSD sàn HNX, UPCOM','chot-quyen-vsd-san-hnx-upcom','14','1','1472696386','1472696386','90');
INSERT INTO olala3w_jobs_name VALUES('1484','Kiểm tra, duyệt TTBT trong VSD','kiem-tra-duyet-ttbt-trong-vsd','15','1','1472696411','1472696411','90');
INSERT INTO olala3w_jobs_name VALUES('1485','TT dứt điểm các CT đã PD hoặc chờ PD QTVĐT','tt-dut-diem-cac-ct-da-pd-hoac-cho-pd-qtvdt','16','1','1472696442','1472696442','62');
INSERT INTO olala3w_jobs_name VALUES('1486','KH vốn MT2 và thu hồi nợ 727','kh-von-mt2-va-thu-hoi-no-727','17','1','1472696545','1472696545','62');
INSERT INTO olala3w_jobs_name VALUES('1487','Thu hồi nợ 727 - bù trừ nợ HP5 gđ1 và gđ2','thu-hoi-no-727-bu-tru-no-hp5-gd1-va-gd2','18','1','1472696688','1472696688','62');
INSERT INTO olala3w_jobs_name VALUES('1488','Trích DP chứng khoán trình TGĐ','trich-dp-chung-khoan-trinh-tgd','19','1','1472696776','1472696776','62');
INSERT INTO olala3w_jobs_name VALUES('1489','KT Kho BM + HP +AK','kt-kho-bm-hp-ak','20','1','1472697179','1472697179','62');
INSERT INTO olala3w_jobs_name VALUES('1490','HĐ bảo hiểm Móng + TH Monarchy B','hd-bao-hiem-mong-th-monarchy-b','21','1','1472697231','1472697231','62');
INSERT INTO olala3w_jobs_name VALUES('1491','KT Monảchy A- ĐX Kho VT SD VT dư thừa + ATLĐ, + SC CCDC','kt-monachy-a-dx-kho-vt-sd-vt-du-thua-atld-sc-ccdc','22','1','1472697455','1472697455','62');
INSERT INTO olala3w_jobs_name VALUES('1492','Họp giao ban','hop-giao-ban','23','1','1472863460','1472863460','81');
INSERT INTO olala3w_jobs_name VALUES('1493','Làm việc tại văn phòng','lam-viec-tai-van-phong','24','1','1472863527','1472863527','81');
INSERT INTO olala3w_jobs_name VALUES('1494','Họp','hop','25','1','1472863602','1472863602','81');
INSERT INTO olala3w_jobs_name VALUES('1495','Kê khai thuế GTGT','ke-khai-thue-gtgt','26','1','1472863738','1472863738','77');
INSERT INTO olala3w_jobs_name VALUES('1496','CV văn thư','cv-van-thu','27','1','1472865364','1472865364','72');
INSERT INTO olala3w_jobs_name VALUES('1497','Văn thư','van-thu','28','1','1472865436','1472865436','72');
INSERT INTO olala3w_jobs_name VALUES('1498','Văn thư lưu trữ','van-thu-luu-tru','29','1','1472865459','1472865459','72');
INSERT INTO olala3w_jobs_name VALUES('1499','văn thư nhân sự','van-thu-nhan-su','30','1','1472865493','1472865493','72');
INSERT INTO olala3w_jobs_name VALUES('1500','Dán nhãn sắp xếp hồ sơ','dan-nhan-sap-xep-ho-so','31','1','1472866184','1472866184','78');
INSERT INTO olala3w_jobs_name VALUES('1501','Lập kế hoạch cần làm cho công tác tại trạm Hoà Nhơn tuần sau','lap-ke-hoach-can-lam-cho-cong-tac-tai-tram-hoa-nhon-tuan-sau','32','1','1472866254','1472866254','78');
INSERT INTO olala3w_jobs_name VALUES('1502','Họp công trình','hop-cong-trinh','33','1','1472866602','1472866602','80');
INSERT INTO olala3w_jobs_name VALUES('1503','Kiểm tra hạch toán công nợ tháng 7/2016','kiem-tra-hach-toan-cong-no-thang-7-2016','34','1','1472866629','1472866629','78');
INSERT INTO olala3w_jobs_name VALUES('1504','Lập kế hoạch 13 - nd họp giao ban','lap-ke-hoach-13-nd-hop-giao-ban','35','1','1472866729','1472866729','80');
INSERT INTO olala3w_jobs_name VALUES('1505','Khảo giá, ss báo giá với Hòa Cầm, DinCo. Hỏi ý kiến A.Duy đề xuất giá BTTP','khao-gia-ss-bao-gia-voi-hoa-cam-dinco-hoi-y-kien-a-duy-de-xuat-gia-bttp','36','1','1472867200','1472867200','97');
INSERT INTO olala3w_jobs_name VALUES('1506','Kiểm tra thực tế lô đất + bản vẽ thửa+QĐ thu hồ BC đề xuất','kiem-tra-thuc-te-lo-dat-ban-ve-thua-qd-thu-ho-bc-de-xuat','37','1','1472868176','1472868176','63');
INSERT INTO olala3w_jobs_name VALUES('1507','Tìm sao lục hồ sơ','tim-sao-luc-ho-so','38','1','1472868257','1472868257','63');
INSERT INTO olala3w_jobs_name VALUES('1508','Tìm chứng từ bổ sung trình UB quận Liên Chiểu và UBTP phê duyệt 11 hộ nợ tiền đất E1','tim-chung-tu-bo-sung-trinh-ub-quan-lien-chieu-va-ubtp-phe-duyet-11-ho-no-tien-dat-e1','39','1','1472868332','1472868332','63');
INSERT INTO olala3w_jobs_name VALUES('1509','Công tác tại trạm Hoà Nhơn','cong-tac-tai-tram-hoa-nhon','40','1','1472871353','1472871353','78');
INSERT INTO olala3w_jobs_name VALUES('1510','Nhận chứng từ ngân hàng','nhan-chung-tu-ngan-hang','41','1','1472871397','1472871397','78');
INSERT INTO olala3w_jobs_name VALUES('1511','Nộp hồ sơ thuế TNCN bổ sung','nop-ho-so-thue-tncn-bo-sung','42','1','1472871482','1472871482','78');
INSERT INTO olala3w_jobs_name VALUES('1512','lấy mẫu nẹp','lay-mau-nep','43','1','1472875184','1472875184','76');
INSERT INTO olala3w_jobs_name VALUES('1513','lấy mẫu bồn hoa lan can','lay-mau-bon-hoa-lan-can','44','1','1472875247','1472875247','76');
INSERT INTO olala3w_jobs_name VALUES('1514','xem mẫu cầu thang','xem-mau-cau-thang','45','1','1472875352','1472875352','76');
INSERT INTO olala3w_jobs_name VALUES('1515','So sánh đx giá vật tư XM, cát, gạch...','so-sanh-dx-gia-vat-tu-xm-cat-gach','46','1','1472954022','1472954022','62');
INSERT INTO olala3w_jobs_name VALUES('1516','Sao lục hồ sơ , bàn giao hồ sơ qua trung tâm phát triển QĐ','sao-luc-ho-so-ban-giao-ho-so-qua-trung-tam-phat-trien-qd','47','1','1473036025','1473036025','63');
INSERT INTO olala3w_jobs_name VALUES('1517','Tìm hiểu các BC hiện có, cách thức kiểm tra','tim-hieu-cac-bc-hien-co-cach-thuc-kiem-tra','48','1','1473036041','1473036041','97');
INSERT INTO olala3w_jobs_name VALUES('1518','lắp mẫu bồn hoa','lap-mau-bon-hoa','49','1','1473036098','1473036098','76');
INSERT INTO olala3w_jobs_name VALUES('1519','Cung cấp hồ sơ làm sổ chung cư an Trung ','cung-cap-ho-so-lam-so-chung-cu-an-trung','50','1','1473036141','1473036141','63');
INSERT INTO olala3w_jobs_name VALUES('1520','Làm hồ sơ sổ lô 17L4 BPBP','lam-ho-so-so-lo-17l4-bpbp','51','1','1473036313','1473036313','63');
INSERT INTO olala3w_jobs_name VALUES('1521','Đo kích thước đặt tủ lavabo','do-kich-thuoc-dat-tu-lavabo','52','1','1473036362','1473036362','80');
INSERT INTO olala3w_jobs_name VALUES('1522','theo dõi tiến độ dự án C.Mỹ Hạnh','theo-doi-tien-do-du-an-c-my-hanh','53','1','1473036370','1473036370','82');
INSERT INTO olala3w_jobs_name VALUES('1523','kiểm tra kế hoạch thử áp lực A Hòa','kiem-tra-ke-hoach-thu-ap-luc-a-hoa','54','1','1473036570','1473036570','82');
INSERT INTO olala3w_jobs_name VALUES('1524','Nhập số liệu kích thước - báo cáo A.T','nhap-so-lieu-kich-thuoc-bao-cao-a-t','55','1','1473036611','1473036611','80');
INSERT INTO olala3w_jobs_name VALUES('1525','chấm công nhật thợ  Monarchy','cham-cong-nhat-tho-monarchy','56','1','1473036619','1473036619','82');
INSERT INTO olala3w_jobs_name VALUES('1526','Kiểm tra lại diện tích căn hộ khu B','kiem-tra-lai-dien-tich-can-ho-khu-b','57','1','1473036647','1473036647','80');
INSERT INTO olala3w_jobs_name VALUES('1527','theo dõi việc sửa chữa 5 căn hộ Monarchy','theo-doi-viec-sua-chua-5-can-ho-monarchy','58','1','1473036689','1473036689','82');
INSERT INTO olala3w_jobs_name VALUES('1528','Lập báo cáo thợ thi công An Trung','lap-bao-cao-tho-thi-cong-an-trung','59','1','1473036853','1473036853','80');
INSERT INTO olala3w_jobs_name VALUES('1529','Đo kích thước đặt tủ lavabo - Họp về chống thấm','do-kich-thuoc-dat-tu-lavabo-hop-ve-chong-tham','60','1','1473037057','1473037057','80');
INSERT INTO olala3w_jobs_name VALUES('1530','kiểm tra khối lượng dự toan và giá vật tư hạng mục điện chiếu sáng, chống sét','kiem-tra-khoi-luong-du-toan-va-gia-vat-tu-hang-muc-dien-chieu-sang-chong-set','61','1','1473037122','1473037122','71');
INSERT INTO olala3w_jobs_name VALUES('1531','Báo giá máy điều hòa','bao-gia-may-dieu-hoa','62','1','1473037127','1473037127','76');
INSERT INTO olala3w_jobs_name VALUES('1532','Đề xuất và yêu cầu vật tư','de-xuat-va-yeu-cau-vat-tu','63','1','1473037238','1473037238','76');
INSERT INTO olala3w_jobs_name VALUES('1533','kiểm tra khối lượng dự toan và giá vật tư hạng mục tiếp địa nối đất, báo cháy , điều hòa không khí','kiem-tra-khoi-luong-du-toan-va-gia-vat-tu-hang-muc-tiep-dia-noi-dat-bao-chay-dieu-hoa-khong-khi','64','1','1473037276','1473037276','71');
INSERT INTO olala3w_jobs_name VALUES('1534','kiểm tra khối lượng dự toan và giá vật tư hạng mục cấp thoát nước , pccc','kiem-tra-khoi-luong-du-toan-va-gia-vat-tu-hang-muc-cap-thoat-nuoc-pccc','65','1','1473037350','1473037350','71');
INSERT INTO olala3w_jobs_name VALUES('1535','Kiểm tra đấu nối , lắp đặt đồng hồ chính cho khối nhà','kiem-tra-dau-noi-lap-dat-dong-ho-chinh-cho-khoi-nha','66','1','1473037443','1473037443','71');
INSERT INTO olala3w_jobs_name VALUES('1536','Có giấy phép xin đối nối thoát nước ra ngoài mương TP của công ty xử lý nước thải','co-giay-phep-xin-doi-noi-thoat-nuoc-ra-ngoai-muong-tp-cua-cong-ty-xu-ly-nuoc-thai','67','1','1473037533','1473037533','71');
INSERT INTO olala3w_jobs_name VALUES('1537','Kiểm tra vật tư thiết bị phụ kiện đấu nối , lắp đặt đồng hồ chính cho khối nhà','kiem-tra-vat-tu-thiet-bi-phu-kien-dau-noi-lap-dat-dong-ho-chinh-cho-khoi-nha','68','1','1473037593','1473037593','71');
INSERT INTO olala3w_jobs_name VALUES('1538','Thi công ống cấp và đi dây điện chiếu sáng sân vườn tầng 4( căn 1,2,3,4,5)','thi-cong-ong-cap-va-di-day-dien-chieu-sang-san-vuon-tang-4-can-1-2-3-4-5','69','1','1473037834','1473037834','71');
INSERT INTO olala3w_jobs_name VALUES('1539','Nghỉ lễ','nghi-le','70','1','1473039615','1473039615','80');
INSERT INTO olala3w_jobs_name VALUES('1540','PV phỏng vấn ứng viên ngày 05/09','pv-phong-van-ung-vien-ngay-05-09','71','1','1473043923','1473043923','72');
INSERT INTO olala3w_jobs_name VALUES('1541','đi xe TGD','di-xe-tgd','72','1','1473044436','1473044436','61');
INSERT INTO olala3w_jobs_name VALUES('1542','Lên Dsach khách mời hội thảo','len-dsach-khach-moi-hoi-thao','73','1','1473044897','1473044897','90');
INSERT INTO olala3w_jobs_name VALUES('1543','Hop dong Ông Hà','hop-dong-ong-ha','74','1','1473045122','1473045122','87');
INSERT INTO olala3w_jobs_name VALUES('1544','thanh toán các khoản thu chi ','thanh-toan-cac-khoan-thu-chi','75','1','1473045429','1473045429','96');
INSERT INTO olala3w_jobs_name VALUES('1545','02 HD TV ĐT, Thanh ly HD, Giấy phong toa TK','02-hd-tv-dt-thanh-ly-hd-giay-phong-toa-tk','76','1','1473045436','1473045436','87');
INSERT INTO olala3w_jobs_name VALUES('1546','Chuẩn bị hội thảo ĐTGTTT ','chuan-bi-hoi-thao-dtgttt','77','1','1473045449','1473045449','89');
INSERT INTO olala3w_jobs_name VALUES('1547','Hoàn thành HS báo cáo GDTT nộp UB ','hoan-thanh-hs-bao-cao-gdtt-nop-ub','78','1','1473045500','1473045500','89');
INSERT INTO olala3w_jobs_name VALUES('1548','KPI Bể Xử Lý Nước Thải','kpi-be-xu-ly-nuoc-thai','79','1','1473045992','1473045992','61');
INSERT INTO olala3w_jobs_name VALUES('1549','Kiểm tra hoạt động thang máy Lapaz','kiem-tra-hoat-dong-thang-may-lapaz','80','1','1473046057','1473046057','61');
INSERT INTO olala3w_jobs_name VALUES('1550','Hoàn Thành T3,2,1 lửng WIfi','hoan-thanh-t3-2-1-lung-wifi','81','1','1473046161','1473046161','61');
INSERT INTO olala3w_jobs_name VALUES('1551','Hoàn Thành lắp Đặt WIFI T3,2,1 lững','hoan-thanh-lap-dat-wifi-t3-2-1-lung','82','1','1473046321','1473046321','61');
INSERT INTO olala3w_jobs_name VALUES('1552','Khảo sát lắp đặt','khao-sat-lap-dat','83','1','1473055039','1473055039','76');
INSERT INTO olala3w_jobs_name VALUES('1553','Họp về kích thước lỗ xie-lavabo','hop-ve-kich-thuoc-lo-xie-lavabo','84','1','1473057976','1473057976','80');
INSERT INTO olala3w_jobs_name VALUES('1554','Kê số lượng vách kính phòng tắm đã lắp đặt','ke-so-luong-vach-kinh-phong-tam-da-lap-dat','85','1','1473058038','1473058038','80');
INSERT INTO olala3w_jobs_name VALUES('1555','Sao lục hs hộ Hồ Quang Hùng HP3 bàn giao qua TTPTQĐ ','sao-luc-hs-ho-ho-quang-hung-hp3-ban-giao-qua-ttptqd','86','1','1473059946','1473059946','63');
INSERT INTO olala3w_jobs_name VALUES('1556','THUẾ VAT','thue-vat','87','1','1473060006','1473060006','64');
INSERT INTO olala3w_jobs_name VALUES('1557','KH vốn thanh toán 10% còn lại (đã hoặc chưa PD QTVĐT)','kh-von-thanh-toan-10-con-lai-da-hoac-chua-pd-qtvdt','88','1','1473060016','1473060016','62');
INSERT INTO olala3w_jobs_name VALUES('1558','Kiểm tra hạch toán ngân hàng','kiem-tra-hach-toan-ngan-hang','89','1','1473060070','1473060070','64');
INSERT INTO olala3w_jobs_name VALUES('1559','QUYET TOAN CHI PHI KHAC - 38NCT','quyet-toan-chi-phi-khac-38nct','90','1','1473060272','1473060272','64');
INSERT INTO olala3w_jobs_name VALUES('1560','Lên bảng doanh thu, giá vốn Quý 3','len-bang-doanh-thu-gia-von-quy-3','91','1','1473060604','1473060604','64');
INSERT INTO olala3w_jobs_name VALUES('1561','Hạch toán lương, bảo hiểm từ tháng 1 đến tháng 8 năm 2016','hach-toan-luong-bao-hiem-tu-thang-1-den-thang-8-nam-2016','92','1','1473060759','1473060759','78');
INSERT INTO olala3w_jobs_name VALUES('1562','Báo cáo tình hình quyết toán','bao-cao-tinh-hinh-quyet-toan','93','1','1473060817','1473060817','64');
INSERT INTO olala3w_jobs_name VALUES('1563','- Nộp tờ quyết toán TNCN A Trung','nop-to-quyet-toan-tncn-a-trung','86','1','1473060904','1502162823','78');
INSERT INTO olala3w_jobs_name VALUES('1564','Lập HĐ thời vụ cho CN đến tháng 9/2016','lap-hd-thoi-vu-cho-cn-den-thang-9-2016','95','1','1473061041','1473061041','62');
INSERT INTO olala3w_jobs_name VALUES('1565','Sao lục 7 hs  bàn giao qua TTPTQĐ ','sao-luc-7-hs-ban-giao-qua-ttptqd','96','1','1473061121','1473061121','63');
INSERT INTO olala3w_jobs_name VALUES('1566','Lập bảng lương nhân công các CT đến 9/2016','lap-bang-luong-nhan-cong-cac-ct-den-9-2016','97','1','1473061159','1473061159','62');
INSERT INTO olala3w_jobs_name VALUES('1567','Kiểm tra TK lương, bảo hiểm từ tháng 1 đến tháng 8 năm 2016','kiem-tra-tk-luong-bao-hiem-tu-thang-1-den-thang-8-nam-2016','98','1','1473061247','1473061247','78');
INSERT INTO olala3w_jobs_name VALUES('1568','Kê giá vật tư đang mua trình đề xuất giá.','ke-gia-vat-tu-dang-mua-trinh-de-xuat-gia','99','1','1473061262','1473061262','62');
INSERT INTO olala3w_jobs_name VALUES('1569','Cài chương trình Bravo - DWI','cai-chuong-trinh-bravo-dwi','100','1','1473061316','1473061316','64');
INSERT INTO olala3w_jobs_name VALUES('1570','KT số dư Tổ khoán trên chương trình, đề xuất XL','kt-so-du-to-khoan-tren-chuong-trinh-de-xuat-xl','101','1','1473061388','1473061388','62');
INSERT INTO olala3w_jobs_name VALUES('1571','Kiểm kê kho MB + Kho An Trung, đề xuất','kiem-ke-kho-mb-kho-an-trung-de-xuat','102','1','1473061485','1473061485','62');
INSERT INTO olala3w_jobs_name VALUES('1572','Liên hệ UB có chủ trương cho 2 hộ khu HP2+ 2 hộTLĐ','lien-he-ub-co-chu-truong-cho-2-ho-khu-hp2-2-hotld','103','1','1473061534','1473061534','63');
INSERT INTO olala3w_jobs_name VALUES('1573','KIỂM TRA SỐ LIỆU SÀN NDN','kiem-tra-so-lieu-san-ndn','104','1','1473061537','1473061537','64');
INSERT INTO olala3w_jobs_name VALUES('1574','Làm hs CQ cho lô17L4 Khu BPBP','lam-hs-cq-cho-lo17l4-khu-bpbp','105','1','1473061654','1473061654','63');
INSERT INTO olala3w_jobs_name VALUES('1575','CC hồ sơ làm sổ An Trung A','cc-ho-so-lam-so-an-trung-a','106','1','1473061871','1473061871','63');
INSERT INTO olala3w_jobs_name VALUES('1576','SC Vận thăng lồng','sc-van-thang-long','107','1','1473061910','1473061910','62');
INSERT INTO olala3w_jobs_name VALUES('1577','kiểm tra lắp cửa nhựa tầng 6','kiem-tra-lap-cua-nhua-tang-6','108','1','1473062029','1473062029','82');
INSERT INTO olala3w_jobs_name VALUES('1578','SC vận thăng tời hàng - 2 bộ','sc-van-thang-toi-hang-2-bo','109','1','1473062029','1473062029','62');
INSERT INTO olala3w_jobs_name VALUES('1579','HT HĐ + phí  hoa hồng môi giới tháng 8 ','ht-hd-phi-hoa-hong-moi-gioi-thang-8','110','1','1473062045','1473062045','63');
INSERT INTO olala3w_jobs_name VALUES('1580','tổng hợp KPI NDN tháng 8/2016','tong-hop-kpi-ndn-thang-8-2016','111','1','1473062094','1473062094','82');
INSERT INTO olala3w_jobs_name VALUES('1581','đôn đốc giải ngân 2 hso Thanh Hương','don-doc-giai-ngan-2-hso-thanh-huong','112','1','1473062152','1473062152','82');
INSERT INTO olala3w_jobs_name VALUES('1582','SC khung tiệp + Khung A','sc-khung-tiep-khung-a','113','1','1473062162','1473062162','62');
INSERT INTO olala3w_jobs_name VALUES('1583','Kiểm tra xuất lại sơ đồ đất đi thực tế đo lại ','kiem-tra-xuat-lai-so-do-dat-di-thuc-te-do-lai','114','1','1473062172','1473062172','63');
INSERT INTO olala3w_jobs_name VALUES('1584','kiểm tra công nhật tại CT Monarchy','kiem-tra-cong-nhat-tai-ct-monarchy','115','1','1473062739','1473062739','69');
INSERT INTO olala3w_jobs_name VALUES('1585','BC mất mát Copa giàn giáo, máy móc CT XLNT, đề xuất xử lý','bc-mat-mat-copa-gian-giao-may-moc-ct-xlnt-de-xuat-xu-ly','116','1','1473062788','1473062788','62');
INSERT INTO olala3w_jobs_name VALUES('1586','SC Block B - Danang Plaza','sc-block-b-danang-plaza','117','1','1473062891','1473062891','62');
INSERT INTO olala3w_jobs_name VALUES('1587','Gạt taluy Mỏ đất TNHC','gat-taluy-mo-dat-tnhc','118','1','1473062960','1473062960','62');
INSERT INTO olala3w_jobs_name VALUES('1588','kiểm tra kê khai thuế','kiem-tra-ke-khai-thue','119','1','1473063000','1473063000','69');
INSERT INTO olala3w_jobs_name VALUES('1589','Chống thấm tường ngoài nhà Căn 1704- LaPaz','chong-tham-tuong-ngoai-nha-can-1704-lapaz','120','1','1473063056','1473063056','62');
INSERT INTO olala3w_jobs_name VALUES('1590','Lập danh sách bán căn hộ An Trung A báo cáo AT','lap-danh-sach-ban-can-ho-an-trung-a-bao-cao-at','121','1','1473063737','1473063737','63');
INSERT INTO olala3w_jobs_name VALUES('1591','thanh toán bù trừ công nợ 727 DA Hòa phát 5','thanh-toan-bu-tru-cong-no-727-da-hoa-phat-5','122','1','1473064569','1473064569','64');
INSERT INTO olala3w_jobs_name VALUES('1592','PHOTO CHỨNG TỪ GIÁ VỐN MONARCHY A','photo-chung-tu-gia-von-monarchy-a','123','1','1473064677','1473064677','64');
INSERT INTO olala3w_jobs_name VALUES('1593','Kiểm kê TS CCDC Quý 3/2016 SS sổ sách, đề xuất','kiem-ke-ts-ccdc-quy-3-2016-ss-so-sach-de-xuat','124','1','1473064728','1473064728','62');
INSERT INTO olala3w_jobs_name VALUES('1594','Họp về chống thấm','hop-ve-chong-tham','125','1','1473064828','1473064828','80');
INSERT INTO olala3w_jobs_name VALUES('1595','Kiểm tra CTGS, CT ngân hàng','kiem-tra-ctgs-ct-ngan-hang','126','1','1473064885','1473064885','64');
INSERT INTO olala3w_jobs_name VALUES('1596','Trích khấu hao TSCĐ+ CCDC quý 3 ','trich-khau-hao-tscd-ccdc-quy-3','127','1','1473064924','1473064924','63');
INSERT INTO olala3w_jobs_name VALUES('1597','Trích khấu hao TSCĐ +CCDC quý 3','trich-khau-hao-tscd-ccdc-quy-3','128','1','1473065003','1473065003','63');
INSERT INTO olala3w_jobs_name VALUES('1598','Tìm hs  để bàn giao qua TTPTQĐ','tim-hs-de-ban-giao-qua-ttptqd','129','1','1473065353','1473065353','63');
INSERT INTO olala3w_jobs_name VALUES('1599','Trình UB điều chỉnh lô 278 khu TLĐ ','trinh-ub-dieu-chinh-lo-278-khu-tld','130','1','1473065607','1473065607','63');
INSERT INTO olala3w_jobs_name VALUES('1600','Nhập, đối chiếu công nợ tháng 08/2016','nhap-doi-chieu-cong-no-thang-08-2016','131','1','1473066449','1473066449','69');
INSERT INTO olala3w_jobs_name VALUES('1601','Cùng A Thịnh đề xuất sữa chữa lốc B Lapaz','cung-a-thinh-de-xuat-sua-chua-loc-b-lapaz','132','1','1473066647','1473066647','69');
INSERT INTO olala3w_jobs_name VALUES('1602','sdsdf','sdsdf','133','1','1473067839','1473067839','65');
INSERT INTO olala3w_jobs_name VALUES('1603','kt công nhật CT Monarchy','kt-cong-nhat-ct-monarchy','134','1','1473068092','1473068092','69');
INSERT INTO olala3w_jobs_name VALUES('1604','KT hóa đơn, kê khai thuế','kt-hoa-don-ke-khai-thue','135','1','1473068166','1473068166','69');
INSERT INTO olala3w_jobs_name VALUES('1605','Thanh toán quyết toán HP5 ĐCS','thanh-toan-quyet-toan-hp5-dcs','136','1','1473068520','1473068520','65');
INSERT INTO olala3w_jobs_name VALUES('1606','Nộp hồ sơ quyết toán San nền- Hòa Mỹ MR','nop-ho-so-quyet-toan-san-nen-hoa-my-mr','137','1','1473068622','1473068622','65');
INSERT INTO olala3w_jobs_name VALUES('1607','Thu nợ công ty Quân Kiệt','thu-no-cong-ty-quan-kiet','138','1','1473069848','1473069848','69');
INSERT INTO olala3w_jobs_name VALUES('1608','Cùng A Thịnh đề xuất + sữa chữa lốc B DaNang Plaza','cung-a-thinh-de-xuat-sua-chua-loc-b-danang-plaza','139','1','1473129659','1473129659','62');
INSERT INTO olala3w_jobs_name VALUES('1609','Thống kê DS công nhân cùng chị Lài lập HĐ thời vụ đến tháng 9/2016','thong-ke-ds-cong-nhan-cung-chi-lai-lap-hd-thoi-vu-den-thang-9-2016','140','1','1473132381','1473132381','62');
INSERT INTO olala3w_jobs_name VALUES('1610','Đăng ký MST cho CBNV văn phòng và công nhân','dang-ky-mst-cho-cbnv-van-phong-va-cong-nhan','141','1','1473132435','1473132435','62');
INSERT INTO olala3w_jobs_name VALUES('1611','Cùng chị lài lập bảng lương Công nhân đến tháng 9/2016 nộp Công ty','cung-chi-lai-lap-bang-luong-cong-nhan-den-thang-9-2016-nop-cong-ty','142','1','1473132516','1473132516','62');
INSERT INTO olala3w_jobs_name VALUES('1612','QT toàn dự án chung cư LaPaz','qt-toan-du-an-chung-cu-lapaz','143','1','1473132880','1473132880','62');
INSERT INTO olala3w_jobs_name VALUES('1613','Cùng chị Thư QT toàn dự án LaPaz','cung-chi-thu-qt-toan-du-an-lapaz','144','1','1473132932','1473132932','62');
INSERT INTO olala3w_jobs_name VALUES('1614','Kiểm tra số liệu kế toán Q3- TSM, trình XL số dư tồn tại','kiem-tra-so-lieu-ke-toan-q3-tsm-trinh-xl-so-du-ton-tai','145','1','1473133047','1473133047','62');
INSERT INTO olala3w_jobs_name VALUES('1615','Cùng chị Thư kiểm tra số liệu kế toán TSM, trình đề xuất XL số dư tồn tại','cung-chi-thu-kiem-tra-so-lieu-ke-toan-tsm-trinh-de-xuat-xl-so-du-ton-tai','146','1','1473133146','1473133146','62');
INSERT INTO olala3w_jobs_name VALUES('1616','Dự kiến kết quả KD quý 3/2016','du-kien-ket-qua-kd-quy-3-2016','147','1','1473133325','1473133325','62');
INSERT INTO olala3w_jobs_name VALUES('1617','kiểm tra số liệu kế toán Sàn BĐS, trình Đề xuất XL số dư tồn tại','kiem-tra-so-lieu-ke-toan-san-bds-trinh-de-xuat-xl-so-du-ton-tai','148','1','1473133404','1473133404','62');
INSERT INTO olala3w_jobs_name VALUES('1618','Cùng Chị Thư kiểm tra số liệu kế toqns Sàn, đề xuất XL số dư tồn tại','cung-chi-thu-kiem-tra-so-lieu-ke-toqns-san-de-xuat-xl-so-du-ton-tai','149','1','1473133491','1473133491','62');
INSERT INTO olala3w_jobs_name VALUES('1619','Họp chống thấm','hop-chong-tham','150','1','1473136170','1473136170','76');
INSERT INTO olala3w_jobs_name VALUES('1620','đo dây cáp AT','do-day-cap-at','151','1','1473136213','1473136213','76');
INSERT INTO olala3w_jobs_name VALUES('1621','Làm chương trình đánh giá nội bộ công ty','lam-chuong-trinh-danh-gia-noi-bo-cong-ty','152','1','1473144150','1473144150','77');
INSERT INTO olala3w_jobs_name VALUES('1622','Trình AT ISO + quỹ tiền mặt','trinh-at-iso-quy-tien-mat','153','1','1473144326','1473144326','77');
INSERT INTO olala3w_jobs_name VALUES('1623','Kiểm tra sữa chữa khung vận thăng lồng','kiem-tra-sua-chua-khung-van-thang-long','154','1','1473144381','1473144381','77');
INSERT INTO olala3w_jobs_name VALUES('1624','Xuất chấm công công trình, thu đề xuất ngoài giờ','xuat-cham-cong-cong-trinh-thu-de-xuat-ngoai-gio','155','1','1473144434','1473144434','77');
INSERT INTO olala3w_jobs_name VALUES('1625','Chấm công công trình + đăng ký  MST cho công nhân','cham-cong-cong-trinh-dang-ky-mst-cho-cong-nhan','156','1','1473144551','1473144551','77');
INSERT INTO olala3w_jobs_name VALUES('1626','Đánh file Thư Xác Nhận','danh-file-thu-xac-nhan','157','1','1473150840','1473150840','90');
INSERT INTO olala3w_jobs_name VALUES('1627','Sửa lỗi SV','sua-loi-sv','158','1','1473154211','1473154211','86');
INSERT INTO olala3w_jobs_name VALUES('1628','Thiết kế, chỉnh sửa lại hệ thống mạng tại DNSC','thiet-ke-chinh-sua-lai-he-thong-mang-tai-dnsc','159','1','1473154400','1473154400','86');
INSERT INTO olala3w_jobs_name VALUES('1629','Test Golive với Hose','test-golive-voi-hose','160','1','1473154698','1473154698','86');
INSERT INTO olala3w_jobs_name VALUES('1630','Gắn FW mới','gan-fw-moi','161','1','1473154830','1473154830','86');
INSERT INTO olala3w_jobs_name VALUES('1631','Cấu hình hệ thống','cau-hinh-he-thong','162','1','1473154936','1473154936','86');
INSERT INTO olala3w_jobs_name VALUES('1632','Tính lại kích thước đặt tủ lavabo+xie( với a H.Minh)','tinh-lai-kich-thuoc-dat-tu-lavabo-xie-voi-a-h-minh','163','1','1473155868','1473155868','80');
INSERT INTO olala3w_jobs_name VALUES('1633','Kiểm tra thi công theo kế hoạch tuần của BCh','kiem-tra-thi-cong-theo-ke-hoach-tuan-cua-bch','164','1','1473207447','1473207447','67');
INSERT INTO olala3w_jobs_name VALUES('1634','Kiểm tra lại dự toán phần chênh lệch','kiem-tra-lai-du-toan-phan-chenh-lech','165','1','1473207528','1473207528','67');
INSERT INTO olala3w_jobs_name VALUES('1635','Làm việc với anh Hùng CDC về cọc nhồ Block B','lam-viec-voi-anh-hung-cdc-ve-coc-nho-block-b','166','1','1473207594','1473207594','67');
INSERT INTO olala3w_jobs_name VALUES('1636','Kiểm tra thi công cọc A. Tiến','kiem-tra-thi-cong-coc-a-tien','167','1','1473207709','1473207709','67');
INSERT INTO olala3w_jobs_name VALUES('1637','kiểm tra lại dự toán phần chênh lệch khối lượng','kiem-tra-lai-du-toan-phan-chenh-lech-khoi-luong','168','1','1473207762','1473207762','67');
INSERT INTO olala3w_jobs_name VALUES('1638','Kiểm tra thi công Monarchy A. Thuần, A. Tân, Anh Thủy','kiem-tra-thi-cong-monarchy-a-thuan-a-tan-anh-thuy','169','1','1473207917','1473207917','67');
INSERT INTO olala3w_jobs_name VALUES('1639','Lập bảng tính khấu hao thiết bị NDX','lap-bang-tinh-khau-hao-thiet-bi-ndx','170','1','1473209316','1473209316','97');
INSERT INTO olala3w_jobs_name VALUES('1640','kiểm tra cửa nhựa T4','kiem-tra-cua-nhua-t4','171','1','1473209413','1473209413','82');
INSERT INTO olala3w_jobs_name VALUES('1641','TÁI NGHIỆM THU KHU WC, ban công','tai-nghiem-thu-khu-wc-ban-cong','172','1','1473209447','1473209447','82');
INSERT INTO olala3w_jobs_name VALUES('1642','lap dat camera an trung','lap-dat-camera-an-trung','173','1','1473214276','1473214276','61');
INSERT INTO olala3w_jobs_name VALUES('1643','lap wifi cac tang 4,3,2,1 lung','lap-wifi-cac-tang-4-3-2-1-lung','174','1','1473214328','1473214328','61');
INSERT INTO olala3w_jobs_name VALUES('1644','KT xe nhập cát + đá tại Monarchy A để đề xuất cách KT VT nhập thiếu','kt-xe-nhap-cat-da-tai-monarchy-a-de-de-xuat-cach-kt-vt-nhap-thieu','175','1','1473235375','1473235375','62');
INSERT INTO olala3w_jobs_name VALUES('1645','Làm KH tuần + họp ','lam-kh-tuan-hop','176','1','1473238144','1473238144','81');
INSERT INTO olala3w_jobs_name VALUES('1646','Họp làm việc tại văn phòng + Họp chống thấm','hop-lam-viec-tai-van-phong-hop-chong-tham','177','1','1473238202','1473238202','81');
INSERT INTO olala3w_jobs_name VALUES('1647','Đi CT AT','di-ct-at','178','1','1473238241','1473238241','81');
INSERT INTO olala3w_jobs_name VALUES('1648','Đi bể xlnt. tây bắc','di-be-xlnt-tay-bac','179','1','1473238360','1473238360','81');
INSERT INTO olala3w_jobs_name VALUES('1649','Đi ct gt Hòa Cầm','di-ct-gt-hoa-cam','180','1','1473238931','1473238931','81');
INSERT INTO olala3w_jobs_name VALUES('1650','Kiểm tra tổng kho','kiem-tra-tong-kho','181','1','1473239135','1473239135','81');
INSERT INTO olala3w_jobs_name VALUES('1651','Lập bảng công tháng 08/2016','lap-bang-cong-thang-08-2016','182','1','1473244763','1473244763','72');
INSERT INTO olala3w_jobs_name VALUES('1652','Lập bảng tính lương tháng 08/2016','lap-bang-tinh-luong-thang-08-2016','183','1','1473244808','1473244808','72');
INSERT INTO olala3w_jobs_name VALUES('1653','Lập bảng tính mức đóng BHXH tháng 09/2016','lap-bang-tinh-muc-dong-bhxh-thang-09-2016','184','1','1473244848','1473244848','72');
INSERT INTO olala3w_jobs_name VALUES('1654','Quy trình đọc BCTC','quy-trinh-doc-bctc','185','1','1473296408','1473296408','87');
INSERT INTO olala3w_jobs_name VALUES('1655','Giải quyết hồ sơ nợ đất tái định cư','giai-quyet-ho-so-no-dat-tai-dinh-cu','186','1','1473325200','1473325200','72');
INSERT INTO olala3w_jobs_name VALUES('1656','VV chuyển trả và hướng dẫn bổ sung hồ sơ đề nghị thu hồi đất KDC Hòa Phát 5','vv-chuyen-tra-va-huong-dan-bo-sung-ho-so-de-nghi-thu-hoi-dat-kdc-hoa-phat-5','187','1','1473325335','1473325335','72');
INSERT INTO olala3w_jobs_name VALUES('1657','Kiểm tra công nhật trên CT','kiem-tra-cong-nhat-tren-ct','188','1','1473329223','1473329223','69');
INSERT INTO olala3w_jobs_name VALUES('1658','Kiểm tra công nhật và ATLĐ tại CT','kiem-tra-cong-nhat-va-atld-tai-ct','189','1','1473329318','1473329318','69');
INSERT INTO olala3w_jobs_name VALUES('1659','Kiểm tra lại tất cả số dư của TK để hạch toán','kiem-tra-lai-tat-ca-so-du-cua-tk-de-hach-toan','190','1','1473329558','1473329558','69');
INSERT INTO olala3w_jobs_name VALUES('1660','Đo lại kích thước lỗ xie và lavabo tầng 1, 2,3 tầng 18','do-lai-kich-thuoc-lo-xie-va-lavabo-tang-1-2-3-tang-18','191','1','1473409753','1473409753','80');
INSERT INTO olala3w_jobs_name VALUES('1661','Thống kê số lượng, kích thước tủ lavabo','thong-ke-so-luong-kich-thuoc-tu-lavabo','192','1','1473409834','1473409834','80');
INSERT INTO olala3w_jobs_name VALUES('1662','Kiểm tra lại kích thước WC tầng 1 để lắp tủ lavabo','kiem-tra-lai-kich-thuoc-wc-tang-1-de-lap-tu-lavabo','193','1','1473409927','1473409927','80');
INSERT INTO olala3w_jobs_name VALUES('1663','Tìm mẫu tủ lavabo(nhỏ nhất)','tim-mau-tu-lavabo-nho-nhat','194','1','1473409997','1473409997','80');
INSERT INTO olala3w_jobs_name VALUES('1664','Báo cáo về việc kết luận của Phó chủ tịch UBND TP về xử lý vướng mắc trong quá trình thực hiện cổ phần hóa công ty TNHH MTV Vật liệu xây dựng - Xây lắp và kinh doanh nhà ĐN','bao-cao-ve-viec-ket-luan-cua-pho-chu-tich-ubnd-tp-ve-xu-ly-vuong-mac-trong-qua-trinh-thuc-hien-co-phan-hoa-cong-ty-tnhh-mtv-vat-lieu-xay-dung-xay-lap-va-kinh-doanh-nha-dn','195','1','1473414106','1473414106','72');
INSERT INTO olala3w_jobs_name VALUES('1665','Kiểm tra thử thấm tầng lửng ','kiem-tra-thu-tham-tang-lung','196','1','1473469019','1473469019','84');
INSERT INTO olala3w_jobs_name VALUES('1666','Nộp hồ sơ QT Hòa Thọ MR- Điện chiếu sáng','nop-ho-so-qt-hoa-tho-mr-dien-chieu-sang','197','1','1473470107','1473470107','65');
INSERT INTO olala3w_jobs_name VALUES('1667','Kiểm tra lỗi phần mềm excel NDX','kiem-tra-loi-phan-mem-excel-ndx','198','1','1473474448','1473474448','97');
INSERT INTO olala3w_jobs_name VALUES('1668','LV với hộ Ông Nguyễn Thịnh- đền bù DA Rừng Hòa Nhơn','lv-voi-ho-ong-nguyen-thinh-den-bu-da-rung-hoa-nhon','199','1','1473576153','1473576153','62');
INSERT INTO olala3w_jobs_name VALUES('1669','LV với hộ Đặng Công Thương- đền bù DA Rừng Hòa Nhơn','lv-voi-ho-dang-cong-thuong-den-bu-da-rung-hoa-nhon','200','1','1473576265','1473576265','62');
INSERT INTO olala3w_jobs_name VALUES('1670','Kiểm tra kho','kiem-tra-kho','201','1','1473638846','1473638846','76');
INSERT INTO olala3w_jobs_name VALUES('1671','Mua bồn hoa lan can','mua-bon-hoa-lan-can','202','1','1473639097','1473639097','76');
INSERT INTO olala3w_jobs_name VALUES('1672','HS lắp đặt cẩu tháp','hs-lap-dat-cau-thap','203','1','1473640271','1473640271','52');
INSERT INTO olala3w_jobs_name VALUES('1673','Lấy mẫu ống nhựa','lay-mau-ong-nhua','204','1','1473640287','1473640287','76');
INSERT INTO olala3w_jobs_name VALUES('1674','Họp giao  ban công ty','hop-giao-ban-cong-ty','205','1','1473640360','1473640360','67');
INSERT INTO olala3w_jobs_name VALUES('1675','giàn phơi','gian-phoi','206','1','1473640403','1473640403','76');
INSERT INTO olala3w_jobs_name VALUES('1676','Sang TBD Cài Chương Trình Bravo','sang-tbd-cai-chuong-trinh-bravo','207','1','1473640590','1473640590','55');
INSERT INTO olala3w_jobs_name VALUES('1677','HS xin phép khoang đường Trần Quang Diệu','hs-xin-phep-khoang-duong-tran-quang-dieu','208','1','1473640596','1473640596','52');
INSERT INTO olala3w_jobs_name VALUES('1678','Hạch toán lại chứng từ DWI trên Bravo mới cài','hach-toan-lai-chung-tu-dwi-tren-bravo-moi-cai','209','1','1473640677','1473640677','57');
INSERT INTO olala3w_jobs_name VALUES('1679','Cài Win cho Sàn NDN','cai-win-cho-san-ndn','210','1','1473640696','1473640696','55');
INSERT INTO olala3w_jobs_name VALUES('1680','Kiểm tra bảng dự toán điện nước','kiem-tra-bang-du-toan-dien-nuoc','211','1','1473640811','1473640811','57');
INSERT INTO olala3w_jobs_name VALUES('1681','Báo cáo quỹ Thọ Quang+ Tổng hợp bảng công công trình','bao-cao-quy-tho-quang-tong-hop-bang-cong-cong-trinh','212','1','1473641148','1473641148','77');
INSERT INTO olala3w_jobs_name VALUES('1682','Nhập xuất vật tư hằng ngày các công trình','nhap-xuat-vat-tu-hang-ngay-cac-cong-trinh','213','1','1473641203','1473641203','77');
INSERT INTO olala3w_jobs_name VALUES('1683','Trình AT mẫu đá bếp + báo giá','trinh-at-mau-da-bep-bao-gia','214','1','1473641266','1473641266','57');
INSERT INTO olala3w_jobs_name VALUES('1684','Dự toán M&E','du-toan-m-e','215','1','1473641342','1473641342','52');
INSERT INTO olala3w_jobs_name VALUES('1685','Kiểm tra dự toán phần kết cấu tầng lững của Quang','kiem-tra-du-toan-phan-ket-cau-tang-lung-cua-quang','216','1','1473641444','1473641444','67');
INSERT INTO olala3w_jobs_name VALUES('1686','Kiểm tra thi công cọc 600 Block B','kiem-tra-thi-cong-coc-600-block-b','217','1','1473641578','1473641578','67');
INSERT INTO olala3w_jobs_name VALUES('1687','Kiểm tra lát gạch tầng 6,7,8 Block A','kiem-tra-lat-gach-tang-6-7-8-block-a','218','1','1473641665','1473641665','67');
INSERT INTO olala3w_jobs_name VALUES('1688','LV + KT công việc của Thư+ Phương+ Tâm','lv-kt-cong-viec-cua-thu-phuong-tam','219','1','1473650505','1473650505','62');
INSERT INTO olala3w_jobs_name VALUES('1689','Thi công tủ wifi tầng (tầng 6-18)','thi-cong-tu-wifi-tang-tang-6-18','220','1','1473650832','1473650832','61');
INSERT INTO olala3w_jobs_name VALUES('1690','Lắp đặt tủ tầng 1 +2 +3 +4','lap-dat-tu-tang-1-2-3-4','221','1','1473650858','1473650858','61');
INSERT INTO olala3w_jobs_name VALUES('1691','Cài đặt lại khóa cửa các căn bị lỗi (1802, 1803, 1702, 1703, 503, 505, 706, 705)','cai-dat-lai-khoa-cua-cac-can-bi-loi-1802-1803-1702-1703-503-505-706-705','222','1','1473650892','1473650892','61');
INSERT INTO olala3w_jobs_name VALUES('1692','Mời A Trung nghiệm thu thang máy Lapaz','moi-a-trung-nghiem-thu-thang-may-lapaz','223','1','1473650959','1473650959','61');
INSERT INTO olala3w_jobs_name VALUES('1693','Nghiệm thu lắp đặt tủ wifi tầng Monarchy A','nghiem-thu-lap-dat-tu-wifi-tang-monarchy-a','224','1','1473650998','1473650998','61');
INSERT INTO olala3w_jobs_name VALUES('1694','Trình lịch bảo dưỡng định kỳ TSM và DNSC','trinh-lich-bao-duong-dinh-ky-tsm-va-dnsc','225','1','1473651029','1473651029','61');
INSERT INTO olala3w_jobs_name VALUES('1695','Qua Danaweb kiểm tra tiến độ trang NDN','qua-danaweb-kiem-tra-tien-do-trang-ndn','226','1','1473651050','1473651050','61');
INSERT INTO olala3w_jobs_name VALUES('1696',' họp tổ','hop-to','227','1','1473651126','1473651126','61');
INSERT INTO olala3w_jobs_name VALUES('1697','Trình TGĐ cho lắp đặt intercom cho các căn hộ','trinh-tgd-cho-lap-dat-intercom-cho-cac-can-ho','228','1','1473651151','1473651151','61');
INSERT INTO olala3w_jobs_name VALUES('1698','làm việc với đơn vị thi công tiến độ lắp màn hình Intercome','lam-viec-voi-don-vi-thi-cong-tien-do-lap-man-hinh-intercome','229','1','1473651183','1473651183','61');
INSERT INTO olala3w_jobs_name VALUES('1699','Kiểm tra chạy thử smarthome của BKAV và ASIC','kiem-tra-chay-thu-smarthome-cua-bkav-va-asic','230','1','1473651217','1473651217','61');
INSERT INTO olala3w_jobs_name VALUES('1700','sửa camera thi công Monarchy','sua-camera-thi-cong-monarchy','231','1','1473651235','1473651235','61');
INSERT INTO olala3w_jobs_name VALUES('1701','Sửa camera kho Miếu Bông','sua-camera-kho-mieu-bong','232','1','1473651260','1473651260','61');
INSERT INTO olala3w_jobs_name VALUES('1702','Kiểm tra khối lượng dự toán phần xây trát ','kiem-tra-khoi-luong-du-toan-phan-xay-trat','233','1','1473651285','1473651285','67');
INSERT INTO olala3w_jobs_name VALUES('1703','LV với  Tý + Lài + Thịnh + Sương','lv-voi-ty-lai-thinh-suong','234','1','1473653227','1473653227','62');
INSERT INTO olala3w_jobs_name VALUES('1704','LV với Anh Thư + Phương + Tâm','lv-voi-anh-thu-phuong-tam','235','1','1473653274','1473653274','62');
INSERT INTO olala3w_jobs_name VALUES('1705','LV với Thanh Thủy + Dung','lv-voi-thanh-thuy-dung','236','1','1473653313','1473653313','62');
INSERT INTO olala3w_jobs_name VALUES('1706','Đề xuất và hoàn thiện đăng ký chương trình top 100 Thương hiệu, sản phẩm dịch vụ nổi tiếng tại VN năm 2016','de-xuat-va-hoan-thien-dang-ky-chuong-trinh-top-100-thuong-hieu-san-pham-dich-vu-noi-tieng-tai-vn-nam-2016','237','1','1473654440','1473654440','72');
INSERT INTO olala3w_jobs_name VALUES('1707','Đăng ký khóa học Quản lý đội ngũ nhân viên hiệu quả + hệ thống quản lý chất lượng doanh nghiệp ISO ','dang-ky-khoa-hoc-quan-ly-doi-ngu-nhan-vien-hieu-qua-he-thong-quan-ly-chat-luong-doanh-nghiep-iso','238','1','1473654834','1473654834','72');
INSERT INTO olala3w_jobs_name VALUES('1708','LV với chị Tú Oanh','lv-voi-chi-tu-oanh','239','1','1473662793','1473662793','62');
INSERT INTO olala3w_jobs_name VALUES('1709','LV với Anh Trung','lv-voi-anh-trung','240','1','1473663918','1473663918','97');
INSERT INTO olala3w_jobs_name VALUES('1710','Chuẩn bị cuộc họp','chuan-bi-cuoc-hop','241','1','1473664001','1473664001','97');
INSERT INTO olala3w_jobs_name VALUES('1711','LV với AT','lv-voi-at','242','1','1473672811','1473672811','72');
INSERT INTO olala3w_jobs_name VALUES('1712','Làm KH tuần ','lam-kh-tuan','243','1','1473736945','1473736945','76');
INSERT INTO olala3w_jobs_name VALUES('1713','Báo giá gạch','bao-gia-gach','244','1','1473737038','1473737038','76');
INSERT INTO olala3w_jobs_name VALUES('1714','báo cáo máy điều hòa','bao-cao-may-dieu-hoa','245','1','1473737228','1473737228','76');
INSERT INTO olala3w_jobs_name VALUES('1715','lưu trữ','luu-tru','246','1','1473738393','1473738393','72');
INSERT INTO olala3w_jobs_name VALUES('1716','Họp giao ban ','hop-giao-ban','247','1','1473739883','1473739883','81');
INSERT INTO olala3w_jobs_name VALUES('1717','Đi An Trung','di-an-trung','248','1','1473740061','1473740061','81');
INSERT INTO olala3w_jobs_name VALUES('1718','Đi XLNT','di-xlnt','249','1','1473740341','1473740341','81');
INSERT INTO olala3w_jobs_name VALUES('1719','kiểm tra vật tư','kiem-tra-vat-tu','250','1','1473740821','1473740821','76');
INSERT INTO olala3w_jobs_name VALUES('1720','Đi Hòa Cầm','di-hoa-cam','251','1','1473740835','1473740835','81');
INSERT INTO olala3w_jobs_name VALUES('1721','lấy mẫu gạch','lay-mau-gach','252','1','1473741018','1473741018','76');
INSERT INTO olala3w_jobs_name VALUES('1722','Họp phòng','hop-phong','253','1','1473741276','1473741276','81');
INSERT INTO olala3w_jobs_name VALUES('1723','KT các chỉ tiêu Sàn BĐS NDN','kt-cac-chi-tieu-san-bds-ndn','254','1','1473747282','1473747282','97');
INSERT INTO olala3w_jobs_name VALUES('1724','Trình lại AT KPI NDN tháng 8/2016','trinh-lai-at-kpi-ndn-thang-8-2016','255','1','1473747445','1473747445','97');
INSERT INTO olala3w_jobs_name VALUES('1725','LV với Sàn BĐS NDN về pp Marketing','lv-voi-san-bds-ndn-ve-pp-marketing','256','1','1473747707','1473747707','97');
INSERT INTO olala3w_jobs_name VALUES('1726','Trình AT ký HĐ liên quan đến Sàn','trinh-at-ky-hd-lien-quan-den-san','257','1','1473747868','1473747868','97');
INSERT INTO olala3w_jobs_name VALUES('1727','KT NDX về KH Marketing','kt-ndx-ve-kh-marketing','258','1','1473748096','1473748096','97');
INSERT INTO olala3w_jobs_name VALUES('1728','theo dõi KH thanh lý thiết bị NDX','theo-doi-kh-thanh-ly-thiet-bi-ndx','259','1','1473748575','1473748575','97');
INSERT INTO olala3w_jobs_name VALUES('1729','Kiểm tra vệ sinh WC, ban công tầng 18','kiem-tra-ve-sinh-wc-ban-cong-tang-18','260','1','1473753539','1473753539','67');
INSERT INTO olala3w_jobs_name VALUES('1730','Kiểm tra và đề xuất giàn phoi t1 - 4','kiem-tra-va-de-xuat-gian-phoi-t1-4','261','1','1473755818','1473755818','76');
INSERT INTO olala3w_jobs_name VALUES('1731','Kiểm tra báo giá lá sách tạo áp cầu thang','kiem-tra-bao-gia-la-sach-tao-ap-cau-thang','262','1','1473755880','1473755880','76');
INSERT INTO olala3w_jobs_name VALUES('1732','Họp phòng + tìm nguồn cung cấp vật tư','hop-phong-tim-nguon-cung-cap-vat-tu','263','1','1473755974','1473755974','76');
INSERT INTO olala3w_jobs_name VALUES('1733','Sửa lại bản vẽ làm sổ tầng 2,3','sua-lai-ban-ve-lam-so-tang-2-3','264','1','1473757904','1473757904','67');
INSERT INTO olala3w_jobs_name VALUES('1734','Kiểm tra quét chống thấm tầng 18','kiem-tra-quet-chong-tham-tang-18','265','1','1473757970','1473757970','67');
INSERT INTO olala3w_jobs_name VALUES('1735','Kiểm tra KL DT hoàn thiện do Khánh Kiểm tra','kiem-tra-kl-dt-hoan-thien-do-khanh-kiem-tra','266','1','1473758023','1473758023','67');
INSERT INTO olala3w_jobs_name VALUES('1736','Kiểm tra KL Kết cấu tầng lững','kiem-tra-kl-ket-cau-tang-lung','267','1','1473758079','1473758079','67');
INSERT INTO olala3w_jobs_name VALUES('1737','Kiểm tra KL phần xây trát','kiem-tra-kl-phan-xay-trat','268','1','1473758113','1473758113','67');
INSERT INTO olala3w_jobs_name VALUES('1738','Họp giao ban công trình ','hop-giao-ban-cong-trinh','269','1','1473758198','1473758198','67');
INSERT INTO olala3w_jobs_name VALUES('1739','Kiểm tra KL của, kinh, lam','kiem-tra-kl-cua-kinh-lam','270','1','1473758268','1473758268','67');
INSERT INTO olala3w_jobs_name VALUES('1740','Kiểm tra KL bổ sung phá dỡ','kiem-tra-kl-bo-sung-pha-do','271','1','1473758308','1473758308','67');
INSERT INTO olala3w_jobs_name VALUES('1741','Kiểm tra ngâm nước thử thấm T18','kiem-tra-ngam-nuoc-thu-tham-t18','272','1','1473758346','1473758346','67');
INSERT INTO olala3w_jobs_name VALUES('1742','Kiểm tra quét chống thấm T18','kiem-tra-quet-chong-tham-t18','273','1','1473759244','1473759244','67');
INSERT INTO olala3w_jobs_name VALUES('1743','Họp giao ban tổ ','hop-giao-ban-to','274','1','1473759284','1473759284','67');
INSERT INTO olala3w_jobs_name VALUES('1744','Kiểm tra chống thấm tầng 18,16','kiem-tra-chong-tham-tang-18-16','275','1','1473759998','1473759998','67');
INSERT INTO olala3w_jobs_name VALUES('1745','Kiểm tra KL DT phần hoàn thiện','kiem-tra-kl-dt-phan-hoan-thien','276','1','1473760037','1473760037','67');
INSERT INTO olala3w_jobs_name VALUES('1746','Kiểm tra KL xây trát','kiem-tra-kl-xay-trat','277','1','1473760138','1473760138','67');
INSERT INTO olala3w_jobs_name VALUES('1747','Kiểm tra chống thấm tại công trình','kiem-tra-chong-tham-tai-cong-trinh','278','1','1473760234','1473760234','67');
INSERT INTO olala3w_jobs_name VALUES('1748','Chấm công thợ thi công CT monarchy','cham-cong-tho-thi-cong-ct-monarchy','279','1','1473817596','1473817596','80');
INSERT INTO olala3w_jobs_name VALUES('1749','Làm BC thợ thi công CT Monarchy','lam-bc-tho-thi-cong-ct-monarchy','280','1','1473817644','1473817644','80');
INSERT INTO olala3w_jobs_name VALUES('1750','Làm kết quả KH 1-10 để chấm KPI ','lam-ket-qua-kh-1-10-de-cham-kpi','281','1','1473817727','1473817727','80');
INSERT INTO olala3w_jobs_name VALUES('1751','Trình A.T kích thước khoét đá, tủ lavabo','trinh-a-t-kich-thuoc-khoet-da-tu-lavabo','282','1','1473817801','1473817801','80');
INSERT INTO olala3w_jobs_name VALUES('1752','Lương T8/2016','luong-t8-2016','283','1','1473823681','1473823681','72');
INSERT INTO olala3w_jobs_name VALUES('1753','Khai BHXH','khai-bhxh','284','1','1473823735','1473823735','72');
INSERT INTO olala3w_jobs_name VALUES('1754','TLời đơn xin QH','tloi-don-xin-qh','285','1','1473823920','1473823920','72');
INSERT INTO olala3w_jobs_name VALUES('1755','DS và TB lễ 2/9','ds-va-tb-le-2-9','286','1','1473823958','1473823958','72');
INSERT INTO olala3w_jobs_name VALUES('1756','KS TKB','ks-tkb','287','1','1473823977','1473823977','72');
INSERT INTO olala3w_jobs_name VALUES('1757','TKê BHXH 4 CT','tke-bhxh-4-ct','288','1','1473824022','1473824022','72');
INSERT INTO olala3w_jobs_name VALUES('1758','ĐK DS QLNV, ISO','dk-ds-qlnv-iso','289','1','1473824166','1473824166','72');
INSERT INTO olala3w_jobs_name VALUES('1759','PV PV 05/09','pv-pv-05-09','290','1','1473824205','1473824205','72');
INSERT INTO olala3w_jobs_name VALUES('1760','PV PV 05/09 + T.Oanh','pv-pv-05-09-t-oanh','291','1','1473824255','1473824255','72');
INSERT INTO olala3w_jobs_name VALUES('1761','Tính BHXH T9','tinh-bhxh-t9','292','1','1473824294','1473824294','72');
INSERT INTO olala3w_jobs_name VALUES('1762','Qlý kho + C. Thủy','qly-kho-c-thuy','293','1','1473824370','1473824370','72');
INSERT INTO olala3w_jobs_name VALUES('1763','Đký Top 100 NHiệu','dky-top-100-nhieu','294','1','1473824440','1473824440','72');
INSERT INTO olala3w_jobs_name VALUES('1764','TTiền CĐ Q2+3','ttien-cd-q2-3','295','1','1473824635','1473824635','72');
INSERT INTO olala3w_jobs_name VALUES('1765','Kê TSCĐ + C Thủy','ke-tscd-c-thuy','296','1','1473824749','1473824749','72');
INSERT INTO olala3w_jobs_name VALUES('1766','NThu TMáy + Hiếu','nthu-tmay-hieu','297','1','1473824855','1473824855','72');
INSERT INTO olala3w_jobs_name VALUES('1767','VT + NS','vt-ns','298','1','1473824874','1473824874','72');
INSERT INTO olala3w_jobs_name VALUES('1768','SLục hs NT Liễu','sluc-hs-nt-lieu','299','1','1473824929','1473824929','72');
INSERT INTO olala3w_jobs_name VALUES('1769','Bảng công T8','bang-cong-t8','300','1','1473824983','1473824983','72');
INSERT INTO olala3w_jobs_name VALUES('1770','Xuất công T8','xuat-cong-t8','301','1','1473825011','1473825011','72');
INSERT INTO olala3w_jobs_name VALUES('1771','Nhập CN T8','nhap-cn-t8','302','1','1473827848','1473827848','69');
INSERT INTO olala3w_jobs_name VALUES('1772','Trình Ký CN','trinh-ky-cn','303','1','1473827952','1473827952','69');
INSERT INTO olala3w_jobs_name VALUES('1773','Điều Chỉnh Giảm CN TK','dieu-chinh-giam-cn-tk','304','1','1473828086','1473828086','69');
INSERT INTO olala3w_jobs_name VALUES('1774','Đi kho MB kiểm tra CN','di-kho-mb-kiem-tra-cn','305','1','1473828208','1473828208','69');
INSERT INTO olala3w_jobs_name VALUES('1775','khảo sát giá đx','khao-sat-gia-dx','306','1','1473828628','1473828628','69');
INSERT INTO olala3w_jobs_name VALUES('1776','kê ccdc CT XLNT','ke-ccdc-ct-xlnt','307','1','1473828736','1473828736','69');
INSERT INTO olala3w_jobs_name VALUES('1777','LV với NDX-chế độ','lv-voi-ndx-che-do','308','1','1473834731','1473834731','97');
INSERT INTO olala3w_jobs_name VALUES('1778','BShs trình UB Q. Liên Chiểu và UBTP PD 11 hộ nợ tiền đất E1','bshs-trinh-ub-q-lien-chieu-va-ubtp-pd-11-ho-no-tien-dat-e1','309','1','1473835855','1473835855','63');
INSERT INTO olala3w_jobs_name VALUES('1779','Trang Trí nội thất','trang-tri-noi-that','310','1','1473898449','1473898449','76');
INSERT INTO olala3w_jobs_name VALUES('1780','Liên hệ anh Hùng về hợp đồng đặt tủ Lavabo','lien-he-anh-hung-ve-hop-dong-dat-tu-lavabo','311','1','1473898514','1473898514','80');
INSERT INTO olala3w_jobs_name VALUES('1781','Ktra đơn giá dự toán phần điện','ktra-don-gia-du-toan-phan-dien','312','1','1473900370','1473900370','57');
INSERT INTO olala3w_jobs_name VALUES('1782','Họp với TGĐ','hop-voi-tgd','313','1','1473900444','1473900444','57');
INSERT INTO olala3w_jobs_name VALUES('1783','Ktra đơn giá dự toán phần nước','ktra-don-gia-du-toan-phan-nuoc','314','1','1473900533','1473900533','57');
INSERT INTO olala3w_jobs_name VALUES('1784','Kiểm tra tiến độ Monarchy  A','kiem-tra-tien-do-monarchy-a','315','1','1473900945','1473900945','57');
INSERT INTO olala3w_jobs_name VALUES('1785','Ktra KQ TH các khu của CHạnh + A Tín','ktra-kq-th-cac-khu-cua-chanh-a-tin','316','1','1473901019','1473901019','57');
INSERT INTO olala3w_jobs_name VALUES('1786','Làm QĐPDTK và công nhận ĐVTC HM tạo áp cầu thang','lam-qdpdtk-va-cong-nhan-dvtc-hm-tao-ap-cau-thang','317','1','1473901102','1473901102','57');
INSERT INTO olala3w_jobs_name VALUES('1787','BC+KH công việc tuần','bc-kh-cong-viec-tuan','318','1','1473903972','1473903972','52');
INSERT INTO olala3w_jobs_name VALUES('1788','TMĐT MONARCHY ','tmdt-monarchy','319','1','1473905833','1473905833','64');
INSERT INTO olala3w_jobs_name VALUES('1789','Tìm hiểu làm thẻ APEC','tim-hieu-lam-the-apec','320','1','1473906397','1473906397','65');
INSERT INTO olala3w_jobs_name VALUES('1790','DK KQKD Q3.2016','dk-kqkd-q3-2016','321','1','1473907020','1473907020','64');
INSERT INTO olala3w_jobs_name VALUES('1791','Đo kích thước lắp giàn phơi- ktra CH lắp tủ lavavbo được','do-kich-thuoc-lap-gian-phoi-ktra-ch-lap-tu-lavavbo-duoc','322','1','1473921433','1473921433','80');
INSERT INTO olala3w_jobs_name VALUES('1792','Nghỉ','nghi','323','1','1473922758','1473922758','80');
INSERT INTO olala3w_jobs_name VALUES('1793','Sao lục HS','sao-luc-hs','324','1','1473930963','1473930963','63');
INSERT INTO olala3w_jobs_name VALUES('1794','BSHS 11 hộ E1','bshs-11-ho-e1','325','1','1473931026','1473931026','63');
INSERT INTO olala3w_jobs_name VALUES('1795','Lập DS bán CH M. A','lap-ds-ban-ch-m-a','326','1','1473931060','1473931060','63');
INSERT INTO olala3w_jobs_name VALUES('1796','CT 2 hộ HP2 + TLĐ','ct-2-ho-hp2-tld','327','1','1473931093','1473931093','63');
INSERT INTO olala3w_jobs_name VALUES('1797','HS CQ lô17L4 BPBP','hs-cq-lo17l4-bpbp','328','1','1473931122','1473931122','63');
INSERT INTO olala3w_jobs_name VALUES('1798','CC HS  An Trung A','cc-hs-an-trung-a','329','1','1473931140','1473931140','63');
INSERT INTO olala3w_jobs_name VALUES('1799','ktra Sđồ TTế','ktra-sdo-tte','330','1','1473931196','1473931196','63');
INSERT INTO olala3w_jobs_name VALUES('1800','Trình UB  lô 278 TLĐ ','trinh-ub-lo-278-tld','331','1','1473931290','1473931290','63');
INSERT INTO olala3w_jobs_name VALUES('1801','Tìm HS qua TTQĐ','tim-hs-qua-ttqd','332','1','1473931315','1473931315','63');
INSERT INTO olala3w_jobs_name VALUES('1802','Trích KH TSCĐ+ CCDC Q3/16 ','trich-kh-tscd-ccdc-q3-16','333','1','1473931344','1473931344','63');
INSERT INTO olala3w_jobs_name VALUES('1803','timviecnhanh','timviecnhanh','334','1','1473985406','1473985406','72');
INSERT INTO olala3w_jobs_name VALUES('1804','PC 2 hộ E2','pc-2-ho-e2','335','1','1473985550','1473985550','63');
INSERT INTO olala3w_jobs_name VALUES('1805','Tìm hs 31-BT3 TN','tim-hs-31-bt3-tn','336','1','1473985600','1473985600','63');
INSERT INTO olala3w_jobs_name VALUES('1806','LH chủ 16-C16 HP3','lh-chu-16-c16-hp3','337','1','1473985660','1473985660','63');
INSERT INTO olala3w_jobs_name VALUES('1807','Trình lô 137 NPBP','trinh-lo-137-npbp','338','1','1473985716','1473985716','63');
INSERT INTO olala3w_jobs_name VALUES('1808','HT HĐ + HH MG T8','ht-hd-hh-mg-t8','339','1','1473985751','1473985751','63');
INSERT INTO olala3w_jobs_name VALUES('1809','PC 2 lô HX','pc-2-lo-hx','340','1','1473985792','1473985792','63');
INSERT INTO olala3w_jobs_name VALUES('1810','Hỏi CB p.trách TKê CV còn lại & p.công CV','hoi-cb-p-trach-tke-cv-con-lai-p-cong-cv','341','1','1474014298','1474014298','97');
INSERT INTO olala3w_jobs_name VALUES('1811','BC Qũy AT','bc-quy-at','342','1','1474014628','1474014628','77');
INSERT INTO olala3w_jobs_name VALUES('1812','Công nhân công ','cong-nhan-cong','343','1','1474014705','1474014705','77');
INSERT INTO olala3w_jobs_name VALUES('1813','Thực hiện CV tổ 1 - KS','thuc-hien-cv-to-1-ks','344','1','1474014769','1474014769','97');
INSERT INTO olala3w_jobs_name VALUES('1814','CCông CN TCông t1-mái','ccong-cn-tcong-t1-mai','345','1','1474014772','1474014772','77');
INSERT INTO olala3w_jobs_name VALUES('1815','Làm lương công nhật ','lam-luong-cong-nhat','346','1','1474014841','1474014841','77');
INSERT INTO olala3w_jobs_name VALUES('1816','- Nộp quyết toán TNCN A Trung','nop-quyet-toan-tncn-a-trung','347','1','1474016561','1474016561','78');
INSERT INTO olala3w_jobs_name VALUES('1817','Thư ký- QL TKB','thu-ky-ql-tkb','348','1','1474016639','1474016639','78');
INSERT INTO olala3w_jobs_name VALUES('1818','ĐK MST cho CBNV mới','dk-mst-cho-cbnv-moi','349','1','1474016785','1474016785','78');
INSERT INTO olala3w_jobs_name VALUES('1819','QT toàn DA LaPaz','qt-toan-da-lapaz','350','1','1474016867','1474016867','78');
INSERT INTO olala3w_jobs_name VALUES('1820','QT toàn DA đất nền A/Trung','qt-toan-da-dat-nen-a-trung','351','1','1474018371','1474018371','78');
INSERT INTO olala3w_jobs_name VALUES('1821','Đi CT Monarchy- ĐX cách QLNC','di-ct-monarchy-dx-cach-qlnc','352','1','1474018468','1474018468','78');
INSERT INTO olala3w_jobs_name VALUES('1822','Sàn-XL số dư tồn tại (+ Thư)','san-xl-so-du-ton-tai-thu','353','1','1474018547','1474018547','78');
INSERT INTO olala3w_jobs_name VALUES('1823','ĐC c/nợ Sàn','dc-c-no-san','354','1','1474018600','1474018600','78');
INSERT INTO olala3w_jobs_name VALUES('1824','ĐC c/nợ TSM','dc-c-no-tsm','355','1','1474018627','1474018627','78');
INSERT INTO olala3w_jobs_name VALUES('1825','ĐC c/nợ NDX','dc-c-no-ndx','356','1','1474018650','1474018650','78');
INSERT INTO olala3w_jobs_name VALUES('1826','Đền 4 hộ Rừng HN','den-4-ho-rung-hn','357','1','1474018728','1474018728','62');
INSERT INTO olala3w_jobs_name VALUES('1827','Trình cấp sổ Monarchy A','trinh-cap-so-monarchy-a','358','1','1474018860','1474018860','62');
INSERT INTO olala3w_jobs_name VALUES('1828','Bàn giao HS nợ - TT','ban-giao-hs-no-tt','359','1','1474018970','1474018970','62');
INSERT INTO olala3w_jobs_name VALUES('1829','ĐX đơn giá vật tư','dx-don-gia-vat-tu','360','1','1474019028','1474019028','62');
INSERT INTO olala3w_jobs_name VALUES('1830','Ứng vốn Quá Giáng 3,5tỷ','ung-von-qua-giang-3-5ty','361','1','1474019087','1474019087','62');
INSERT INTO olala3w_jobs_name VALUES('1831','ĐX xử lý SD Tổ khoán','dx-xu-ly-sd-to-khoan','362','1','1474019127','1474019127','62');
INSERT INTO olala3w_jobs_name VALUES('1832','B/hiểm Móng+ TH Monarchy B','b-hiem-mong-th-monarchy-b','363','1','1474019154','1474019154','62');
INSERT INTO olala3w_jobs_name VALUES('1833','Cải tạo Mỏ đất TNHC','cai-tao-mo-dat-tnhc','364','1','1474019228','1474019228','62');
INSERT INTO olala3w_jobs_name VALUES('1834','N/thu Mở đất TNHC','n-thu-mo-dat-tnhc','365','1','1474019646','1474019646','62');
INSERT INTO olala3w_jobs_name VALUES('1835','Dự kiến KQKD quý 3','du-kien-kqkd-quy-3','366','1','1474019681','1474019681','62');
INSERT INTO olala3w_jobs_name VALUES('1836','Bàn giao HS qua TT','ban-giao-hs-qua-tt','367','1','1474070863','1474070863','63');
INSERT INTO olala3w_jobs_name VALUES('1837','Chủ trương 11 hộ nợ E1','chu-truong-11-ho-no-e1','368','1','1474070917','1474070917','63');
INSERT INTO olala3w_jobs_name VALUES('1838','Bố trí Lô 278 TLĐ đường 3,5','bo-tri-lo-278-tld-duong-3-5','369','1','1474070992','1474070992','63');
INSERT INTO olala3w_jobs_name VALUES('1839','PC 2 lô khu Hòa Xuân','pc-2-lo-khu-hoa-xuan','370','1','1474071061','1474071061','63');
INSERT INTO olala3w_jobs_name VALUES('1840','XL 5 hộ thiếu P Phân lô','xl-5-ho-thieu-p-phan-lo','371','1','1474071147','1474071147','63');
INSERT INTO olala3w_jobs_name VALUES('1841','Chủ trương lô 137 nam PBP','chu-truong-lo-137-nam-pbp','372','1','1474071203','1474071203','63');
INSERT INTO olala3w_jobs_name VALUES('1842','Chủ trương 1 hộ T/Bình','chu-truong-1-ho-t-binh','373','1','1474071289','1474071289','63');
INSERT INTO olala3w_jobs_name VALUES('1843','chủ trương 1 hộ H/Thuận','chu-truong-1-ho-h-thuan','374','1','1474071380','1474071380','63');
INSERT INTO olala3w_jobs_name VALUES('1844','KK TS CCDC+ trích KH TS Q3','kk-ts-ccdc-trich-kh-ts-q3','375','1','1474071996','1474071996','63');
INSERT INTO olala3w_jobs_name VALUES('1845','Kiểm tra chi phí - 38NCT','kiem-tra-chi-phi-38nct','376','1','1474072480','1474072480','64');
INSERT INTO olala3w_jobs_name VALUES('1846','Bravo cho TBD + DWI','bravo-cho-tbd-dwi','377','1','1474072647','1474072647','64');
INSERT INTO olala3w_jobs_name VALUES('1847','Nợ 727- MT2 MR + BT HP5, Ý tưởng','no-727-mt2-mr-bt-hp5-y-tuong','378','1','1474072979','1474072979','64');
INSERT INTO olala3w_jobs_name VALUES('1848','TMĐT Monarchy, HĐ XLB','tmdt-monarchy-hd-xlb','379','1','1474073020','1474073020','64');
INSERT INTO olala3w_jobs_name VALUES('1849','Sàn-XL số dư tồn tại (+ Tâm)','san-xl-so-du-ton-tai-tam','380','1','1474076555','1474076555','64');
INSERT INTO olala3w_jobs_name VALUES('1850','Dự kiến KQKD quý 3(+Tâm)','du-kien-kqkd-quy-3-tam','381','1','1474076587','1474076587','64');
INSERT INTO olala3w_jobs_name VALUES('1851','TT vốn ĐCS HP5-gđ2','tt-von-dcs-hp5-gd2','382','1','1474076730','1474076730','65');
INSERT INTO olala3w_jobs_name VALUES('1852','BC giải ngân KHV 2016- STC','bc-giai-ngan-khv-2016-stc','383','1','1474076806','1474076806','65');
INSERT INTO olala3w_jobs_name VALUES('1853','QTVĐT Câp nứoc B/Hòa Cầm','qtvdt-cap-nuoc-b-hoa-cam','384','1','1474076915','1474076915','65');
INSERT INTO olala3w_jobs_name VALUES('1854','K/toán Câp nứoc B/Hòa Cầm','k-toan-cap-nuoc-b-hoa-cam','385','1','1474076985','1474076985','65');
INSERT INTO olala3w_jobs_name VALUES('1855','KHV TT  (10% còn lại)','khv-tt-10-con-lai','386','1','1474077108','1474077108','65');
INSERT INTO olala3w_jobs_name VALUES('1856','ĐC K/bạc Khu E- Dinco','dc-k-bac-khu-e-dinco','387','1','1474077213','1474077213','65');
INSERT INTO olala3w_jobs_name VALUES('1857','Thẩm tra QT SN Hòa Mỹ MR','tham-tra-qt-sn-hoa-my-mr','388','1','1474077295','1474077295','65');
INSERT INTO olala3w_jobs_name VALUES('1858','Thu TU C/xanh Khu E- 280tr','thu-tu-c-xanh-khu-e-280tr','389','1','1474077452','1474077452','65');
INSERT INTO olala3w_jobs_name VALUES('1859','H/ toán & DP c/khoán Q3','h-toan-dp-c-khoan-q3','390','1','1474077631','1474077631','65');
INSERT INTO olala3w_jobs_name VALUES('1860','Chi phí Monarchy A','chi-phi-monarchy-a','391','1','1474077894','1474077894','64');
INSERT INTO olala3w_jobs_name VALUES('1861','TSM - XL số dư tồn tại (+ Tâm)','tsm-xl-so-du-ton-tai-tam','392','1','1474077920','1474077920','64');
INSERT INTO olala3w_jobs_name VALUES('1862','TTQT Hòa Thọ MR- Điện chiếu sáng','ttqt-hoa-tho-mr-dien-chieu-sang','393','1','1474078081','1474078081','65');
INSERT INTO olala3w_jobs_name VALUES('1863','TTQT Hòa Thọ MR- Điện CS','ttqt-hoa-tho-mr-dien-cs','394','1','1474078104','1474078104','65');
INSERT INTO olala3w_jobs_name VALUES('1864',' DS BHXH và DS NLĐ của 4 CTy','ds-bhxh-va-ds-nld-cua-4-cty','395','1','1474078529','1474078529','72');
INSERT INTO olala3w_jobs_name VALUES('1865','KK BHXH điện tử','kk-bhxh-dien-tu','396','1','1474078548','1474078548','72');
INSERT INTO olala3w_jobs_name VALUES('1866','Nhận 65% tiền CĐ cty- ở LĐLĐ','nhan-65-tien-cd-cty-o-ldld','397','1','1474078606','1474078606','72');
INSERT INTO olala3w_jobs_name VALUES('1867','Tìm HS Lô 16-C16 HP3','tim-hs-lo-16-c16-hp3','398','1','1474078737','1474078737','72');
INSERT INTO olala3w_jobs_name VALUES('1868','Tìm HS Lô 31-BT3 T/Nghĩa','tim-hs-lo-31-bt3-t-nghia','399','1','1474078784','1474078784','72');
INSERT INTO olala3w_jobs_name VALUES('1869','B/sung HS + chuyển 2 hộ E2','b-sung-hs-chuyen-2-ho-e2','400','1','1474078833','1474078833','72');
INSERT INTO olala3w_jobs_name VALUES('1870','chủ trương  2 hộ HP3','chu-truong-2-ho-hp3','401','1','1474078872','1474078872','72');
INSERT INTO olala3w_jobs_name VALUES('1871','Thuế TNCN 2015 A.Trung duyệt','thue-tncn-2015-a-trung-duyet','402','1','1474079032','1474079032','78');
INSERT INTO olala3w_jobs_name VALUES('1872','TSM - XL số dư tồn tại (+ Thư)','tsm-xl-so-du-ton-tai-thu','403','1','1474079060','1474079060','64');
INSERT INTO olala3w_jobs_name VALUES('1873','KT HT lương 2016','kt-ht-luong-2016','404','1','1474079235','1474079235','78');
INSERT INTO olala3w_jobs_name VALUES('1874','HT số C/lệch lương + BH2016','ht-so-c-lech-luong-bh2016','405','1','1474079330','1474079330','78');
INSERT INTO olala3w_jobs_name VALUES('1875','Lên bảng DT - GV Q3/2016','len-bang-dt-gv-q3-2016','406','1','1474079502','1474079502','62');
INSERT INTO olala3w_jobs_name VALUES('1876','KK An Trung','kk-an-trung','407','1','1474080060','1474080060','77');
INSERT INTO olala3w_jobs_name VALUES('1877','KK M/Bông','kk-m-bong','408','1','1474080103','1474080103','77');
INSERT INTO olala3w_jobs_name VALUES('1878','Đ/chiếu SDV x/lắp T8','d-chieu-sdv-x-lap-t8','409','1','1474080157','1474080157','77');
INSERT INTO olala3w_jobs_name VALUES('1879','ISO- STCL, KH ĐG NB','iso-stcl-kh-dg-nb','410','1','1474080207','1474080207','77');
INSERT INTO olala3w_jobs_name VALUES('1880','TD chấm công Monarchy','td-cham-cong-monarchy','411','1','1474080251','1474080251','77');
INSERT INTO olala3w_jobs_name VALUES('1881','SC Danang Plaza- B','sc-danang-plaza-b','412','1','1474080337','1474080337','77');
INSERT INTO olala3w_jobs_name VALUES('1882','T/hợp Lương CN đến T9','t-hop-luong-cn-den-t9','413','1','1474080370','1474080370','77');
INSERT INTO olala3w_jobs_name VALUES('1883','HĐ thời vụ CN đến T9 ','hd-thoi-vu-cn-den-t9','414','1','1474080401','1474080401','77');
INSERT INTO olala3w_jobs_name VALUES('1884','Lập c/phí CT đến T8','lap-c-phi-ct-den-t8','415','1','1474080429','1474080429','77');
INSERT INTO olala3w_jobs_name VALUES('1885','MST CBNV+ công nhân','mst-cbnv-cong-nhan','416','1','1474080482','1474080482','77');
INSERT INTO olala3w_jobs_name VALUES('1886','Trình AT ISO + quỹ TM','trinh-at-iso-quy-tm','417','1','1474080509','1474080509','77');
INSERT INTO olala3w_jobs_name VALUES('1887','C/Công CT, thu ĐX ngoài giờ','c-cong-ct-thu-dx-ngoai-gio','418','1','1474080544','1474080544','77');
INSERT INTO olala3w_jobs_name VALUES('1888','KT S/c khung vận thăng lồng','kt-s-c-khung-van-thang-long','419','1','1474080570','1474080570','77');
INSERT INTO olala3w_jobs_name VALUES('1889','C/công CT + DK  MST cho CN','c-cong-ct-dk-mst-cho-cn','420','1','1474080613','1474080613','77');
INSERT INTO olala3w_jobs_name VALUES('1890','BC quỹ T/Quang + TH BC CT','bc-quy-t-quang-th-bc-ct','421','1','1474080662','1474080662','77');
INSERT INTO olala3w_jobs_name VALUES('1891','NX vật tư hằng ngày các CT','nx-vat-tu-hang-ngay-cac-ct','422','1','1474080695','1474080695','77');
INSERT INTO olala3w_jobs_name VALUES('1892','Nhập xuất VT công trình','nhap-xuat-vt-cong-trinh','423','1','1474080729','1474080729','77');
INSERT INTO olala3w_jobs_name VALUES('1893','Lập bảng lương CN T9 nộp CTy (+Lài)','lap-bang-luong-cn-t9-nop-cty-lai','424','1','1474080790','1474080790','77');
INSERT INTO olala3w_jobs_name VALUES('1894','TK DS CN, HĐ thời vụ đến T9/2016 (+Lài)','tk-ds-cn-hd-thoi-vu-den-t9-2016-lai','425','1','1474080837','1474080837','77');
INSERT INTO olala3w_jobs_name VALUES('1895','TK DS CN, HĐ TV đến T9/2016 (+Lài)','tk-ds-cn-hd-tv-den-t9-2016-lai','426','1','1474080889','1474080889','77');
INSERT INTO olala3w_jobs_name VALUES('1896','Lập b/lương CN T9 nộp CTy (+Lài)','lap-b-luong-cn-t9-nop-cty-lai','427','1','1474080908','1474080908','77');
INSERT INTO olala3w_jobs_name VALUES('1897','C/từ c/phí CT đến T8','c-tu-c-phi-ct-den-t8','428','1','1474080985','1474080985','69');
INSERT INTO olala3w_jobs_name VALUES('1898','KK An Trung đề xuất','kk-an-trung-de-xuat','429','1','1474081176','1474081176','69');
INSERT INTO olala3w_jobs_name VALUES('1899','KK M/Bông đề xuất','kk-m-bong-de-xuat','430','1','1474081204','1474081204','69');
INSERT INTO olala3w_jobs_name VALUES('1900','Đ/chiếu SL Kho NT/Sơn Trà','d-chieu-sl-kho-nt-son-tra','431','1','1474081237','1474081237','69');
INSERT INTO olala3w_jobs_name VALUES('1901','Đ/chiếu SL Kho A/Trung','d-chieu-sl-kho-a-trung','432','1','1474081263','1474081263','69');
INSERT INTO olala3w_jobs_name VALUES('1902','Thu nợ Quân Kiệt','thu-no-quan-kiet','433','1','1474081280','1474081280','69');
INSERT INTO olala3w_jobs_name VALUES('1903','Bảng lương CN đến T9','bang-luong-cn-den-t9','434','1','1474081298','1474081298','69');
INSERT INTO olala3w_jobs_name VALUES('1904','BC mất mát Copa, MM CT XLNT, ĐXuất','bc-mat-mat-copa-mm-ct-xlnt-dxuat','435','1','1474081341','1474081341','69');
INSERT INTO olala3w_jobs_name VALUES('1905','BC mất mát Copa, MM, ĐXuất','bc-mat-mat-copa-mm-dxuat','436','1','1474081362','1474081362','69');
INSERT INTO olala3w_jobs_name VALUES('1906','Nhập, ĐC công nợ T8/2016','nhap-dc-cong-no-t8-2016','437','1','1474081391','1474081391','69');
INSERT INTO olala3w_jobs_name VALUES('1907','KT công nhật trên CT','kt-cong-nhat-tren-ct','438','1','1474081410','1474081410','69');
INSERT INTO olala3w_jobs_name VALUES('1908','KT số dư TK để HT','kt-so-du-tk-de-ht','439','1','1474081438','1474081438','69');
INSERT INTO olala3w_jobs_name VALUES('1909','N/Công TK, bảng cam kết Tk','n-cong-tk-bang-cam-ket-tk','440','1','1474081457','1474081457','69');
INSERT INTO olala3w_jobs_name VALUES('1910','SC Kho M/Bông, H/Phát','sc-kho-m-bong-h-phat','441','1','1474081668','1474081668','98');
INSERT INTO olala3w_jobs_name VALUES('1911','Chống thấm 1704-LaPaz','chong-tham-1704-lapaz','442','1','1474081688','1474081688','98');
INSERT INTO olala3w_jobs_name VALUES('1912','SC vận thăng hàng','sc-van-thang-hang','443','1','1474081715','1474081715','98');
INSERT INTO olala3w_jobs_name VALUES('1913','VC CCDC NT/S/trà - M/Bông','vc-ccdc-nt-s-tra-m-bong','444','1','1474081772','1474081772','98');
INSERT INTO olala3w_jobs_name VALUES('1914','Liên hệ A.Hoàng về tạm ứng tiền Smarthome','lien-he-a-hoang-ve-tam-ung-tien-smarthome','445','1','1474082187','1474082187','80');
INSERT INTO olala3w_jobs_name VALUES('1915','KT và Kê CCDC NLXT','kt-va-ke-ccdc-nlxt','446','1','1474082434','1474082434','69');
INSERT INTO olala3w_jobs_name VALUES('1916','lập chi phí ','lap-chi-phi','447','1','1474082535','1474082535','69');
INSERT INTO olala3w_jobs_name VALUES('1917','Xuất kho','xuat-kho','448','1','1474082588','1474082588','69');
INSERT INTO olala3w_jobs_name VALUES('1918','Hỏi AT về lịch LV tuần','hoi-at-ve-lich-lv-tuan','449','1','1474245728','1474245728','97');
INSERT INTO olala3w_jobs_name VALUES('1919','Kiểm tra lại HĐ tủ lavabo+kê những căn hộ lắp đặt đc','kiem-tra-lai-hd-tu-lavabo-ke-nhung-can-ho-lap-dat-dc','450','1','1474251882','1474251882','80');
INSERT INTO olala3w_jobs_name VALUES('1920','Tập hợp, KTra chỉ tiêu Sàn','tap-hop-ktra-chi-tieu-san','451','1','1474252062','1474252062','97');
INSERT INTO olala3w_jobs_name VALUES('1921','BC CV tuần cho AT','bc-cv-tuan-cho-at','452','1','1474252469','1474252469','97');
INSERT INTO olala3w_jobs_name VALUES('1922','Kích thước bếp Monarchy A','kich-thuoc-bep-monarchy-a','453','1','1474252650','1474252650','57');
INSERT INTO olala3w_jobs_name VALUES('1923',' Làm thủ tục thay đổi tên DN DWI','lam-thu-tuc-thay-doi-ten-dn-dwi','454','1','1474252701','1474252701','57');
INSERT INTO olala3w_jobs_name VALUES('1924','GS tiến độ Monarchy','gs-tien-do-monarchy','455','1','1474252741','1474252741','57');
INSERT INTO olala3w_jobs_name VALUES('1925','Làm HSNL với A Trung','lam-hsnl-voi-a-trung','456','1','1474252814','1474252814','57');
INSERT INTO olala3w_jobs_name VALUES('1926','Kiểm tra KL cây xanh E1','kiem-tra-kl-cay-xanh-e1','457','1','1474252914','1474252914','57');
INSERT INTO olala3w_jobs_name VALUES('1927','GS tiến độ Monarhcy ','gs-tien-do-monarhcy','458','1','1474252985','1474252985','57');
INSERT INTO olala3w_jobs_name VALUES('1928','BCKQ + KH A Tin','bckq-kh-a-tin','459','1','1474253089','1474253089','57');
INSERT INTO olala3w_jobs_name VALUES('1929','Nộp HS xin LĐ cẩu tháp','nop-hs-xin-ld-cau-thap','460','1','1474254237','1474254237','52');
INSERT INTO olala3w_jobs_name VALUES('1930','Xin GP thi công cụm van','xin-gp-thi-cong-cum-van','461','1','1474254443','1474254443','52');
INSERT INTO olala3w_jobs_name VALUES('1931','HS đấu nối thoát nước','hs-dau-noi-thoat-nuoc','462','1','1474254644','1474254644','52');
INSERT INTO olala3w_jobs_name VALUES('1932','Hồ sơ ĐTM','ho-so-dtm','463','1','1474254730','1474254730','52');
INSERT INTO olala3w_jobs_name VALUES('1933','Làm HS BS thẩm tra Khối B với AT','lam-hs-bs-tham-tra-khoi-b-voi-at','464','1','1474254860','1474254860','52');
INSERT INTO olala3w_jobs_name VALUES('1934','Th/tra HS d/toán TACT Ndu','th-tra-hs-d-toan-tact-ndu','465','1','1474255162','1474255162','52');
INSERT INTO olala3w_jobs_name VALUES('1935','- Ktra thu hồi đường dây HT tại Monarchy ','ktra-thu-hoi-duong-day-ht-tai-monarchy','466','1','1474255231','1474255231','52');
INSERT INTO olala3w_jobs_name VALUES('1936',' Điều chỉnh TBA Monarchy A','dieu-chinh-tba-monarchy-a','467','1','1474255281','1474255281','52');
INSERT INTO olala3w_jobs_name VALUES('1937',' Di dời xong cụm van tại Monarhcy B','di-doi-xong-cum-van-tai-monarhcy-b','468','1','1474255326','1474255326','52');
INSERT INTO olala3w_jobs_name VALUES('1938','Họp STNMT (mỏ đất)','hop-stnmt-mo-dat','469','1','1474255332','1474255332','62');
INSERT INTO olala3w_jobs_name VALUES('1939','K/tra HS M&E Khối B để thẩm tra','k-tra-hs-m-e-khoi-b-de-tham-tra','470','1','1474255381','1474255381','52');
INSERT INTO olala3w_jobs_name VALUES('1940','Mời TGĐ đi ĐN Plaza ','moi-tgd-di-dn-plaza','471','1','1474255496','1474255496','52');
INSERT INTO olala3w_jobs_name VALUES('1941','HS ĐTM','hs-dtm','472','1','1474255541','1474255541','52');
INSERT INTO olala3w_jobs_name VALUES('1942','BC KQ TUẦN','bc-kq-tuan','473','1','1474255575','1474255575','99');
INSERT INTO olala3w_jobs_name VALUES('1943','Xong GP lắp cẩu tháp Monarhcy B','xong-gp-lap-cau-thap-monarhcy-b','474','1','1474255586','1474255586','52');
INSERT INTO olala3w_jobs_name VALUES('1944',' Họp tổ và làm báo cáo','hop-to-va-lam-bao-cao','475','1','1474255613','1474255613','52');
INSERT INTO olala3w_jobs_name VALUES('1945','chạy dự toan khu D phan giao thông','chay-du-toan-khu-d-phan-giao-thong','476','1','1474266670','1474266670','99');
INSERT INTO olala3w_jobs_name VALUES('1946',' Lắp đặt tủ intercom + dấu nối sảnh tầng 1','lap-dat-tu-intercom-dau-noi-sanh-tang-1','477','1','1474267971','1474267971','61');
INSERT INTO olala3w_jobs_name VALUES('1947','Ktra HS hoàn công HM intercom DN Plaza và lapaz','ktra-hs-hoan-cong-hm-intercom-dn-plaza-va-lapaz','478','1','1474268004','1474268004','61');
INSERT INTO olala3w_jobs_name VALUES('1948','Báo cáo tiến độ 3 trang web NDN, NDX, DNSC','bao-cao-tien-do-3-trang-web-ndn-ndx-dnsc','479','1','1474268055','1474268055','61');
INSERT INTO olala3w_jobs_name VALUES('1949',' Kiểm tra chạy thử smarthome monarchy A','kiem-tra-chay-thu-smarthome-monarchy-a','480','1','1474268092','1474268092','61');
INSERT INTO olala3w_jobs_name VALUES('1950','Họp tổ và làm báo cáo','hop-to-va-lam-bao-cao','481','1','1474268121','1474268121','61');
INSERT INTO olala3w_jobs_name VALUES('1951','kiểm tra Nghiệm thu thang máy lapaz + DN Plaza + Monarchy A','kiem-tra-nghiem-thu-thang-may-lapaz-dn-plaza-monarchy-a','482','1','1474268205','1474268205','61');
INSERT INTO olala3w_jobs_name VALUES('1952','- Triển khai thi công di dời và tháo gỡ đường cáp ngầm tuyến đường An Trung 2.','trien-khai-thi-cong-di-doi-va-thao-go-duong-cap-ngam-tuyen-duong-an-trung-2','483','1','1474273670','1474273670','71');
INSERT INTO olala3w_jobs_name VALUES('1953',' - Làm hồ sơ nghiệm thu cây xanh khu E1','lam-ho-so-nghiem-thu-cay-xanh-khu-e1','484','1','1474273919','1474273919','71');
INSERT INTO olala3w_jobs_name VALUES('1954','- Điều chỉnh và trình bản vẻ WC căn số 1 và 8 ra sân vườn ','dieu-chinh-va-trinh-ban-ve-wc-can-so-1-va-8-ra-san-vuon','485','1','1474274251','1474274251','71');
INSERT INTO olala3w_jobs_name VALUES('1955',' Điều chỉnh và trình bản vẻ WC căn số 1 và 8 ra sân vườn ','dieu-chinh-va-trinh-ban-ve-wc-can-so-1-va-8-ra-san-vuon','486','1','1474274394','1474274394','71');
INSERT INTO olala3w_jobs_name VALUES('1956','ĐX CV số 6193','dx-cv-so-6193','487','1','1474274478','1474274478','72');
INSERT INTO olala3w_jobs_name VALUES('1957','- Kiểm tra vật tư và đề xuất đối nối dứt điểm nước ống d110 đường THĐ và TrQD.','kiem-tra-vat-tu-va-de-xuat-doi-noi-dut-diem-nuoc-ong-d110-duong-thd-va-trqd','488','1','1474276420','1474276420','71');
INSERT INTO olala3w_jobs_name VALUES('1958',' Làm HSNT lắp đặt cụm đồng hồ chính và di dời ống HDPE d110','lam-hsnt-lap-dat-cum-dong-ho-chinh-va-di-doi-ong-hdpe-d110','489','1','1474276521','1474276521','71');
INSERT INTO olala3w_jobs_name VALUES('1959','Ktra HĐ tủ lavabo +trình A.T','ktra-hd-tu-lavabo-trinh-a-t','490','1','1474276564','1474276564','80');
INSERT INTO olala3w_jobs_name VALUES('1960','Kiểm tra khối lượng cây xanh E1 với Hương Cty cây xanh','kiem-tra-khoi-luong-cay-xanh-e1-voi-huong-cty-cay-xanh','491','1','1474276606','1474276606','71');
INSERT INTO olala3w_jobs_name VALUES('1961','- Kiểm tra và bổ sung  hồ sơ nghiệm thu cây xanh các khu HTKT cũ','kiem-tra-va-bo-sung-ho-so-nghiem-thu-cay-xanh-cac-khu-htkt-cu','492','1','1474276654','1474276654','71');
INSERT INTO olala3w_jobs_name VALUES('1962',' Xong hồ sơ NT cây xanh Hoà cầm','xong-ho-so-nt-cay-xanh-hoa-cam','493','1','1474276750','1474276750','71');
INSERT INTO olala3w_jobs_name VALUES('1963','LV với AT cùng chị Giang','lv-voi-at-cung-chi-giang','494','1','1474417513','1474417513','97');
INSERT INTO olala3w_jobs_name VALUES('1964','Cùng AT họp với TSM','cung-at-hop-voi-tsm','495','1','1474417704','1474417704','97');
INSERT INTO olala3w_jobs_name VALUES('1965','Trình AT chỉ tiêu sàn T8/16','trinh-at-chi-tieu-san-t8-16','496','1','1474417867','1474417867','97');
INSERT INTO olala3w_jobs_name VALUES('1966','KT ATLĐ','kt-atld','497','1','1474426804','1474426804','69');
INSERT INTO olala3w_jobs_name VALUES('1967','ĐCSDV NDX T7','dcsdv-ndx-t7','498','1','1474426907','1474426907','69');
INSERT INTO olala3w_jobs_name VALUES('1968','kê VT CT XLNT','ke-vt-ct-xlnt','499','1','1474427017','1474427017','69');
INSERT INTO olala3w_jobs_name VALUES('1969','kiểm tra các CT Nhập Trong Tuần qua','kiem-tra-cac-ct-nhap-trong-tuan-qua','500','1','1474427074','1474427074','69');
INSERT INTO olala3w_jobs_name VALUES('1970','lấy báo giá và dx Miệng gió','lay-bao-gia-va-dx-mieng-gio','501','1','1474431789','1474431789','76');
INSERT INTO olala3w_jobs_name VALUES('1971','BG và ĐX vật tư','bg-va-dx-vat-tu','502','1','1474431943','1474431943','76');
INSERT INTO olala3w_jobs_name VALUES('1972','Trình AT ĐX và SS giávật tư','trinh-at-dx-va-ss-giavat-tu','503','1','1474432007','1474432007','76');
INSERT INTO olala3w_jobs_name VALUES('1973','Lấy BG vật tư nước','lay-bg-vat-tu-nuoc','504','1','1474432102','1474432102','76');
INSERT INTO olala3w_jobs_name VALUES('1974','nhập số đo tủ bếp','nhap-so-do-tu-bep','505','1','1474432160','1474432160','76');
INSERT INTO olala3w_jobs_name VALUES('1975','lấy số đo tủ bếp','lay-so-do-tu-bep','506','1','1474432264','1474432264','76');
INSERT INTO olala3w_jobs_name VALUES('1976','Kê ds và khối lượng cv nhân công thi công ','ke-ds-va-khoi-luong-cv-nhan-cong-thi-cong','507','1','1474438312','1474438312','80');
INSERT INTO olala3w_jobs_name VALUES('1977','B/sung HS kiểm toán 2015','b-sung-hs-kiem-toan-2015','508','1','1474447764','1474447764','78');
INSERT INTO olala3w_jobs_name VALUES('1978','ktra cửa cuốn lắp đặt tại tầng 1','ktra-cua-cuon-lap-dat-tai-tang-1','509','1','1474507779','1474507779','80');
INSERT INTO olala3w_jobs_name VALUES('1979','Liên hệ về hợp đồng tủ lavabo','lien-he-ve-hop-dong-tu-lavabo','510','1','1474507838','1474507838','80');
INSERT INTO olala3w_jobs_name VALUES('1980','Ký HSNT lắp đặt đồng hồ, di dời ống d110 và lắp đặt trụ cứu hỏa truyến đường THĐ , AN TRUNG 2','ky-hsnt-lap-dat-dong-ho-di-doi-ong-d110-va-lap-dat-tru-cuu-hoa-truyen-duong-thd-an-trung-2','511','1','1474518731','1474518731','71');
INSERT INTO olala3w_jobs_name VALUES('1981','Ký HSNT lắp đặt đồng hồ, di dời ống d110 và lắp đặt trụ cứu hỏa truyến đường THĐ , AN TRUNG 2 với TVGS','ky-hsnt-lap-dat-dong-ho-di-doi-ong-d110-va-lap-dat-tru-cuu-hoa-truyen-duong-thd-an-trung-2-voi-tvgs','512','1','1474518771','1474518771','71');
INSERT INTO olala3w_jobs_name VALUES('1982','Ktra lắp đặt cửa cuốn ','ktra-lap-dat-cua-cuon','513','1','1474524412','1474524412','80');
INSERT INTO olala3w_jobs_name VALUES('1983','Liên hệ BKAV về tạm ứng + hợp đồng tbi smarthome','lien-he-bkav-ve-tam-ung-hop-dong-tbi-smarthome','514','1','1474524458','1474524458','80');
INSERT INTO olala3w_jobs_name VALUES('1984','TT T/UNG HÒA THỌ MR- GT,ĐB','tt-t-ung-hoa-tho-mr-gt-db','515','1','1474525089','1474525089','65');
INSERT INTO olala3w_jobs_name VALUES('1985','Kiểm tra xử lý sự cố cấp thoát nước căn 408 và 108 khối nhà B1 chung cư Hòa Xuân','kiem-tra-xu-ly-su-co-cap-thoat-nuoc-can-408-va-108-khoi-nha-b1-chung-cu-hoa-xuan','516','1','1474525323','1474525323','71');
INSERT INTO olala3w_jobs_name VALUES('1986','Kiểm tra xử lý sự cố cấp thoát nước căn 408 và 108 khối nhà B1 chung cư Hòa Xuân và báo cáo','kiem-tra-xu-ly-su-co-cap-thoat-nuoc-can-408-va-108-khoi-nha-b1-chung-cu-hoa-xuan-va-bao-cao','517','1','1474525346','1474525346','71');
INSERT INTO olala3w_jobs_name VALUES('1987','Cùng A.Mau đo kthuoc cửa xingfa','cung-a-mau-do-kthuoc-cua-xingfa','518','1','1474599713','1474599713','80');
INSERT INTO olala3w_jobs_name VALUES('1988','Làm việc với a.Mau về cửa xingfa','lam-viec-voi-a-mau-ve-cua-xingfa','519','1','1474599871','1474599871','80');
INSERT INTO olala3w_jobs_name VALUES('1989','Lên KH hoàn chỉnh căn shop house ','len-kh-hoan-chinh-can-shop-house','520','1','1474599996','1474599996','80');
INSERT INTO olala3w_jobs_name VALUES('1990','Hop GB AT','hop-gb-at','521','1','1474600489','1474600489','81');
INSERT INTO olala3w_jobs_name VALUES('1991','Đi AT','di-at','522','1','1474600576','1474600576','81');
INSERT INTO olala3w_jobs_name VALUES('1992','Đi XLNT, TB','di-xlnt-tb','523','1','1474600632','1474600632','81');
INSERT INTO olala3w_jobs_name VALUES('1993','GSTC T1-mái AT','gstc-t1-mai-at','524','1','1474600690','1474600690','81');
INSERT INTO olala3w_jobs_name VALUES('1994','Họp GB AT+ Phòng','hop-gb-at-phong','525','1','1474600791','1474600791','81');
INSERT INTO olala3w_jobs_name VALUES('1995','KTSC khung vận thăng KMB','ktsc-khung-van-thang-kmb','526','1','1474600983','1474600983','77');
INSERT INTO olala3w_jobs_name VALUES('1996','PV Pvấn 24/09','pv-pvan-24-09','527','1','1474603579','1474603579','72');
INSERT INTO olala3w_jobs_name VALUES('1997','CV số 3061 UBND','cv-so-3061-ubnd','528','1','1474621051','1474621051','72');
INSERT INTO olala3w_jobs_name VALUES('1998','Lao công nhé','lao-cong-nhe','529','1','1501555792','1501555792','1');
INSERT INTO olala3w_jobs_name VALUES('1999','<script>alert(1)</script>','alert-1','530','1','1502337137','1502337137','1');

-- --------------------------------------------------------

CREATE TABLE `olala3w_level` (
  `level_id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `class` varchar(20) NOT NULL DEFAULT '-no-',
  `color` varchar(7) NOT NULL DEFAULT '#094089',
  `sort` int(11) NOT NULL DEFAULT '1',
  `is_active` int(11) NOT NULL DEFAULT '1',
  `created_time` int(11) NOT NULL DEFAULT '0',
  `modified_time` int(11) NOT NULL DEFAULT '0',
  `user_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`level_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

INSERT INTO olala3w_level VALUES('1','Cao','red','#b04d45','1','1','1459848602','1501556614','1');
INSERT INTO olala3w_level VALUES('2','Khá','orange','#fcb322','2','1','1459850896','1501556624','1');
INSERT INTO olala3w_level VALUES('3','Trung bình','blue','#0092dd','3','1','1459848737','1459850955','2');

-- --------------------------------------------------------

CREATE TABLE `olala3w_log` (
  `log_id` double NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL DEFAULT '0',
  `date` date NOT NULL,
  `count` int(11) NOT NULL DEFAULT '0',
  `session` varchar(255) NOT NULL,
  `modified_time` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`log_id`)
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8;

INSERT INTO olala3w_log VALUES('1','2','2017-02-08','1','0c829fc4c52abae912bb1ef7bc2c5a4c','1486540644');
INSERT INTO olala3w_log VALUES('2','2','2017-02-14','2','52616885ea75d6a2c91f2ea5ea9bc671','1487037550');
INSERT INTO olala3w_log VALUES('3','2','2017-02-16','1','d20a42233e2b539d066e86ee7ba6d253','1487229731');
INSERT INTO olala3w_log VALUES('4','2','2017-02-21','1','bab94bc860b3a757e2c643bb093000c4','1487616708');
INSERT INTO olala3w_log VALUES('5','2','2017-02-22','1','491b4afca44519f9b813ae7058621ba4','1487757807');
INSERT INTO olala3w_log VALUES('6','2','2017-03-09','1','7feeea1d96ff7831e2920f40cb077648','1489050790');
INSERT INTO olala3w_log VALUES('7','2','2017-03-15','1','1801ad1312dab00d8539bb63447d7702','1489570157');
INSERT INTO olala3w_log VALUES('8','2','2017-05-03','1','7e2060033b6a2bb7cd8a1ed72d1ae863','1493797427');
INSERT INTO olala3w_log VALUES('9','2','2017-05-20','1','f2fd805d042d2fba8fb7f37446b5ffdb','1495225736');
INSERT INTO olala3w_log VALUES('10','2','2017-05-23','1','b7304e99a2278535cc00b7f17c0a2226','1495525302');
INSERT INTO olala3w_log VALUES('11','2','2017-05-25','1','653dc3e4fa6db5d6f6190a71e4bdd676','1495707000');
INSERT INTO olala3w_log VALUES('12','1','2017-05-25','1','f9c847a22828cd6014f39edcf160579c','1495722787');
INSERT INTO olala3w_log VALUES('13','2','2017-06-28','1','433a9c41a798fcbe97c4980eb67331e2','1498644717');
INSERT INTO olala3w_log VALUES('14','2','2017-08-01','1','629279fdae80c559671415b020526c80','1501554582');
INSERT INTO olala3w_log VALUES('15','1','2017-08-01','4','ba8533f77abbf679e411a1237948e644','1501555402');
INSERT INTO olala3w_log VALUES('19','2','2017-08-02','1','06960e3d489d54019eac6ef462f3971e','1501640079');
INSERT INTO olala3w_log VALUES('20','1','2017-08-02','2','0f20f3732c05d6793830a86bef1e718c','1501640181');
INSERT INTO olala3w_log VALUES('21','85','2017-08-02','1','06960e3d489d54019eac6ef462f3971e','1501640240');
INSERT INTO olala3w_log VALUES('22','1','2017-08-03','2','f3ecd05f8587024cdb98442d1c8a7031','1501693322');
INSERT INTO olala3w_log VALUES('23','1','2017-08-04','2','e5a0bfd1aea609f29e52fffa9e729668','1501779866');
INSERT INTO olala3w_log VALUES('24','1','2017-08-05','1','2e3e82cc719d76ebe83f2bed2f5889b5','1501936578');
INSERT INTO olala3w_log VALUES('25','1','2017-08-06','2','2a95d2a5527a6a2492dd6d842b763814','1501952635');
INSERT INTO olala3w_log VALUES('26','1','2017-08-07','6','0dd641d6597c18282402550be059ad35','1502038838');
INSERT INTO olala3w_log VALUES('27','1','2017-08-08','4','3e82268e69c98b2de263c6c39aee6218','1502156638');
INSERT INTO olala3w_log VALUES('28','85','2017-08-08','1','f98e34114def084f2695fe09d8151f4f','1502160169');
INSERT INTO olala3w_log VALUES('29','1','2017-08-09','2','af395899a3c45dbff68b349adffebe7a','1502244122');
INSERT INTO olala3w_log VALUES('30','1','2017-08-10','46','b5863eccec0c381cf3cbf399894f5be9','1502298207');
INSERT INTO olala3w_log VALUES('31','2','2017-08-10','1','ca1458c038ca4d0babf0ea9645ead42d','1502337539');
INSERT INTO olala3w_log VALUES('32','1','2017-08-11','44','0c526cc1efa94f2a7fbef151a4acaac3','1502384556');
INSERT INTO olala3w_log VALUES('33','1','2017-08-12','30','7425662311dca37231786d07aed77e79','1502500578');
INSERT INTO olala3w_log VALUES('34','1','2017-08-13','32','c0e3f41ae95f47674d761a7945bb24cd','1502557658');

-- --------------------------------------------------------

CREATE TABLE `olala3w_matches` (
  `matches_id` int(11) NOT NULL AUTO_INCREMENT,
  `number` int(11) NOT NULL,
  `sort` int(11) NOT NULL DEFAULT '1',
  `is_active` int(1) NOT NULL DEFAULT '1',
  `created_time` int(11) NOT NULL DEFAULT '0',
  `modified_time` int(11) NOT NULL DEFAULT '0',
  `user_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`matches_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


-- --------------------------------------------------------

CREATE TABLE `olala3w_notify` (
  `notify_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `calendar` int(11) NOT NULL DEFAULT '0',
  `type` int(11) NOT NULL DEFAULT '0',
  `content` varchar(255) NOT NULL,
  `created_time` int(11) NOT NULL DEFAULT '0',
  `user_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`notify_id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;

INSERT INTO olala3w_notify VALUES('1','1','8','','1501555792','1');
INSERT INTO olala3w_notify VALUES('2','2','8','','1502160250','85');
INSERT INTO olala3w_notify VALUES('3','3','8','','1502160251','85');
INSERT INTO olala3w_notify VALUES('4','2','4','','1502160305','85');
INSERT INTO olala3w_notify VALUES('5','4','8','','1502160446','85');
INSERT INTO olala3w_notify VALUES('6','5','8','','1502160556','85');
INSERT INTO olala3w_notify VALUES('7','6','8','','1502160618','85');
INSERT INTO olala3w_notify VALUES('8','6','5','','1502160659','85');
INSERT INTO olala3w_notify VALUES('9','6','9','','1502160719','85');
INSERT INTO olala3w_notify VALUES('10','7','1','','1502337138','1');
INSERT INTO olala3w_notify VALUES('11','7','3','','1502337159','1');
INSERT INTO olala3w_notify VALUES('12','4','3','','1502337182','1');

-- --------------------------------------------------------

CREATE TABLE `olala3w_notify_logs` (
  `notify_logs_id` double NOT NULL AUTO_INCREMENT,
  `notify_user` bigint(20) NOT NULL DEFAULT '0',
  `ip` varchar(255) NOT NULL,
  `session` varchar(255) NOT NULL,
  `agent` varchar(255) NOT NULL,
  `modified_time` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`notify_logs_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

INSERT INTO olala3w_notify_logs VALUES('1','8','127.0.0.1','f98e34114def084f2695fe09d8151f4f','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.90 Safari/537.36','1502160900');
INSERT INTO olala3w_notify_logs VALUES('2','16','127.0.0.1','f98e34114def084f2695fe09d8151f4f','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.90 Safari/537.36','1502160900');
INSERT INTO olala3w_notify_logs VALUES('3','25','127.0.0.1','f98e34114def084f2695fe09d8151f4f','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.90 Safari/537.36','1502160900');
INSERT INTO olala3w_notify_logs VALUES('4','32','127.0.0.1','f98e34114def084f2695fe09d8151f4f','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.90 Safari/537.36','1502160900');
INSERT INTO olala3w_notify_logs VALUES('5','40','127.0.0.1','f98e34114def084f2695fe09d8151f4f','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.90 Safari/537.36','1502160900');
INSERT INTO olala3w_notify_logs VALUES('6','48','127.0.0.1','f98e34114def084f2695fe09d8151f4f','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.90 Safari/537.36','1502160900');
INSERT INTO olala3w_notify_logs VALUES('7','57','127.0.0.1','f98e34114def084f2695fe09d8151f4f','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.90 Safari/537.36','1502160900');

-- --------------------------------------------------------

CREATE TABLE `olala3w_notify_user` (
  `notify_user_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `notify` int(20) NOT NULL DEFAULT '0',
  `user_id` int(11) NOT NULL DEFAULT '0',
  `status` int(1) NOT NULL DEFAULT '0',
  `modified_time` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`notify_user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=96 DEFAULT CHARSET=utf8;

INSERT INTO olala3w_notify_user VALUES('1','1','1','1','1502504940');
INSERT INTO olala3w_notify_user VALUES('2','1','2','1','1501629360');
INSERT INTO olala3w_notify_user VALUES('3','1','53','1','1501555792');
INSERT INTO olala3w_notify_user VALUES('4','1','80','1','1501555792');
INSERT INTO olala3w_notify_user VALUES('5','1','52','1','1501555792');
INSERT INTO olala3w_notify_user VALUES('6','1','97','0','1501555792');
INSERT INTO olala3w_notify_user VALUES('7','1','72','0','1501555792');
INSERT INTO olala3w_notify_user VALUES('8','2','1','1','1502504940');
INSERT INTO olala3w_notify_user VALUES('9','2','2','0','1502160250');
INSERT INTO olala3w_notify_user VALUES('10','2','53','1','1502160250');
INSERT INTO olala3w_notify_user VALUES('11','2','80','1','1502160250');
INSERT INTO olala3w_notify_user VALUES('12','2','52','1','1502160250');
INSERT INTO olala3w_notify_user VALUES('13','2','97','0','1502160250');
INSERT INTO olala3w_notify_user VALUES('14','2','72','0','1502160250');
INSERT INTO olala3w_notify_user VALUES('15','2','85','1','1502160780');
INSERT INTO olala3w_notify_user VALUES('16','3','1','1','1502504940');
INSERT INTO olala3w_notify_user VALUES('17','3','2','0','1502160251');
INSERT INTO olala3w_notify_user VALUES('18','3','53','1','1502160251');
INSERT INTO olala3w_notify_user VALUES('19','3','80','1','1502160251');
INSERT INTO olala3w_notify_user VALUES('20','3','52','1','1502160251');
INSERT INTO olala3w_notify_user VALUES('21','3','97','0','1502160251');
INSERT INTO olala3w_notify_user VALUES('22','3','72','0','1502160251');
INSERT INTO olala3w_notify_user VALUES('23','3','85','1','1502160780');
INSERT INTO olala3w_notify_user VALUES('24','4','85','1','1502160780');
INSERT INTO olala3w_notify_user VALUES('25','4','1','1','1502504940');
INSERT INTO olala3w_notify_user VALUES('26','4','2','0','1502160305');
INSERT INTO olala3w_notify_user VALUES('27','4','53','1','1502160305');
INSERT INTO olala3w_notify_user VALUES('28','4','80','1','1502160305');
INSERT INTO olala3w_notify_user VALUES('29','4','52','1','1502160305');
INSERT INTO olala3w_notify_user VALUES('30','4','97','0','1502160305');
INSERT INTO olala3w_notify_user VALUES('31','4','72','0','1502160305');
INSERT INTO olala3w_notify_user VALUES('32','5','1','1','1502504940');
INSERT INTO olala3w_notify_user VALUES('33','5','2','0','1502160446');
INSERT INTO olala3w_notify_user VALUES('34','5','53','1','1502160446');
INSERT INTO olala3w_notify_user VALUES('35','5','80','1','1502160446');
INSERT INTO olala3w_notify_user VALUES('36','5','52','1','1502160446');
INSERT INTO olala3w_notify_user VALUES('37','5','97','0','1502160446');
INSERT INTO olala3w_notify_user VALUES('38','5','72','0','1502160446');
INSERT INTO olala3w_notify_user VALUES('39','5','85','1','1502160780');
INSERT INTO olala3w_notify_user VALUES('40','6','1','1','1502504940');
INSERT INTO olala3w_notify_user VALUES('41','6','2','0','1502160556');
INSERT INTO olala3w_notify_user VALUES('42','6','53','1','1502160556');
INSERT INTO olala3w_notify_user VALUES('43','6','80','1','1502160556');
INSERT INTO olala3w_notify_user VALUES('44','6','52','1','1502160556');
INSERT INTO olala3w_notify_user VALUES('45','6','97','0','1502160556');
INSERT INTO olala3w_notify_user VALUES('46','6','72','0','1502160556');
INSERT INTO olala3w_notify_user VALUES('47','6','85','1','1502160780');
INSERT INTO olala3w_notify_user VALUES('48','7','1','1','1502504940');
INSERT INTO olala3w_notify_user VALUES('49','7','2','0','1502160618');
INSERT INTO olala3w_notify_user VALUES('50','7','53','1','1502160618');
INSERT INTO olala3w_notify_user VALUES('51','7','80','1','1502160618');
INSERT INTO olala3w_notify_user VALUES('52','7','52','1','1502160618');
INSERT INTO olala3w_notify_user VALUES('53','7','97','0','1502160618');
INSERT INTO olala3w_notify_user VALUES('54','7','72','0','1502160618');
INSERT INTO olala3w_notify_user VALUES('55','7','85','1','1502160780');
INSERT INTO olala3w_notify_user VALUES('56','8','85','1','1502160780');
INSERT INTO olala3w_notify_user VALUES('57','8','1','1','1502504940');
INSERT INTO olala3w_notify_user VALUES('58','8','2','0','1502160659');
INSERT INTO olala3w_notify_user VALUES('59','8','53','1','1502160659');
INSERT INTO olala3w_notify_user VALUES('60','8','80','1','1502160659');
INSERT INTO olala3w_notify_user VALUES('61','8','52','1','1502160659');
INSERT INTO olala3w_notify_user VALUES('62','8','97','0','1502160659');
INSERT INTO olala3w_notify_user VALUES('63','8','72','0','1502160659');
INSERT INTO olala3w_notify_user VALUES('64','9','1','1','1502504940');
INSERT INTO olala3w_notify_user VALUES('65','9','2','1','1502337660');
INSERT INTO olala3w_notify_user VALUES('66','9','53','1','1502160719');
INSERT INTO olala3w_notify_user VALUES('67','9','80','1','1502160719');
INSERT INTO olala3w_notify_user VALUES('68','9','52','1','1502160719');
INSERT INTO olala3w_notify_user VALUES('69','9','97','0','1502160719');
INSERT INTO olala3w_notify_user VALUES('70','9','72','0','1502160719');
INSERT INTO olala3w_notify_user VALUES('71','9','85','1','1502160780');
INSERT INTO olala3w_notify_user VALUES('72','10','1','1','1502504940');
INSERT INTO olala3w_notify_user VALUES('73','10','65','0','1502337138');
INSERT INTO olala3w_notify_user VALUES('74','10','2','1','1502337540');
INSERT INTO olala3w_notify_user VALUES('75','10','53','1','1502337138');
INSERT INTO olala3w_notify_user VALUES('76','10','80','1','1502337138');
INSERT INTO olala3w_notify_user VALUES('77','10','52','1','1502337138');
INSERT INTO olala3w_notify_user VALUES('78','10','97','0','1502337138');
INSERT INTO olala3w_notify_user VALUES('79','10','72','0','1502337138');
INSERT INTO olala3w_notify_user VALUES('80','11','65','0','1502337159');
INSERT INTO olala3w_notify_user VALUES('81','11','1','1','1502504940');
INSERT INTO olala3w_notify_user VALUES('82','11','2','1','1502337540');
INSERT INTO olala3w_notify_user VALUES('83','11','53','1','1502337159');
INSERT INTO olala3w_notify_user VALUES('84','11','80','1','1502337159');
INSERT INTO olala3w_notify_user VALUES('85','11','52','1','1502337159');
INSERT INTO olala3w_notify_user VALUES('86','11','97','0','1502337159');
INSERT INTO olala3w_notify_user VALUES('87','11','72','0','1502337159');
INSERT INTO olala3w_notify_user VALUES('88','12','85','0','1502337182');
INSERT INTO olala3w_notify_user VALUES('89','12','1','1','1502504940');
INSERT INTO olala3w_notify_user VALUES('90','12','2','1','1502337540');
INSERT INTO olala3w_notify_user VALUES('91','12','53','1','1502337182');
INSERT INTO olala3w_notify_user VALUES('92','12','80','1','1502337182');
INSERT INTO olala3w_notify_user VALUES('93','12','52','1','1502337182');
INSERT INTO olala3w_notify_user VALUES('94','12','97','0','1502337182');
INSERT INTO olala3w_notify_user VALUES('95','12','72','0','1502337182');

-- --------------------------------------------------------

CREATE TABLE `olala3w_online` (
  `online_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `ip` varchar(255) NOT NULL,
  `created_time` int(11) NOT NULL,
  `site` varchar(255) NOT NULL,
  `agent` varchar(255) NOT NULL,
  `user_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`online_id`)
) ENGINE=MyISAM AUTO_INCREMENT=8228 DEFAULT CHARSET=utf8;

INSERT INTO olala3w_online VALUES('8216','127.0.0.1','1502632668','ol=backup&op=backup_process','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.90 Safari/537.36','0');
INSERT INTO olala3w_online VALUES('8217','127.0.0.1','1502632756','ol=backup&op=backup_process','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.90 Safari/537.36','0');
INSERT INTO olala3w_online VALUES('8218','127.0.0.1','1502632786','ol=backup&op=backup_process','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.90 Safari/537.36','0');
INSERT INTO olala3w_online VALUES('8219','127.0.0.1','1502632816','ol=backup&op=backup_process','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.90 Safari/537.36','0');
INSERT INTO olala3w_online VALUES('8220','127.0.0.1','1502632881','ol=backup&op=backup_process','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.90 Safari/537.36','0');
INSERT INTO olala3w_online VALUES('8221','127.0.0.1','1502632929','ol=backup&op=backup_process','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.90 Safari/537.36','0');
INSERT INTO olala3w_online VALUES('8225','127.0.0.1','1502633117','url=uploads/files/logo.png','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.90 Safari/537.36','0');
INSERT INTO olala3w_online VALUES('8226','127.0.0.1','1502633121','ol=backup&op=backup_process','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.90 Safari/537.36','0');
INSERT INTO olala3w_online VALUES('8227','127.0.0.1','1502633121','url=uploads/files/logo.png','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.90 Safari/537.36','0');
INSERT INTO olala3w_online VALUES('8223','127.0.0.1','1502633027','ol=backup&op=backup_process','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.90 Safari/537.36','0');
INSERT INTO olala3w_online VALUES('8224','127.0.0.1','1502633117','','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.90 Safari/537.36','0');
INSERT INTO olala3w_online VALUES('8202','127.0.0.1','1502631366','ol=document&op=document_list','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.90 Safari/537.36','0');
INSERT INTO olala3w_online VALUES('8203','127.0.0.1','1502631430','ol=document&op=document_add','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.90 Safari/537.36','0');
INSERT INTO olala3w_online VALUES('8204','127.0.0.1','1502631646','ol=backup&op=backup_process','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.90 Safari/537.36','0');
INSERT INTO olala3w_online VALUES('8205','127.0.0.1','1502631701','ol=document&op=document_add','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.90 Safari/537.36','0');
INSERT INTO olala3w_online VALUES('8206','127.0.0.1','1502631714','ol=document&op=document_list','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.90 Safari/537.36','0');
INSERT INTO olala3w_online VALUES('8207','127.0.0.1','1502631758','ol=core&op=core_role','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.90 Safari/537.36','0');
INSERT INTO olala3w_online VALUES('8208','127.0.0.1','1502631760','ol=backup&op=backup_process','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.90 Safari/537.36','0');
INSERT INTO olala3w_online VALUES('8209','127.0.0.1','1502632021','ol=backup&op=backup_process','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.90 Safari/537.36','0');
INSERT INTO olala3w_online VALUES('8210','127.0.0.1','1502632049','ol=backup&op=backup_process','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.90 Safari/537.36','0');
INSERT INTO olala3w_online VALUES('8211','127.0.0.1','1502632306','ol=backup&op=backup_process','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.90 Safari/537.36','0');
INSERT INTO olala3w_online VALUES('8212','127.0.0.1','1502632358','ol=core&op=core_role','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.90 Safari/537.36','0');
INSERT INTO olala3w_online VALUES('8213','127.0.0.1','1502632442','','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.90 Safari/537.36','0');
INSERT INTO olala3w_online VALUES('8214','127.0.0.1','1502632445','ol=backup&op=backup_process','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.90 Safari/537.36','0');
INSERT INTO olala3w_online VALUES('8215','127.0.0.1','1502632654','ol=backup&op=backup_process','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.90 Safari/537.36','0');
INSERT INTO olala3w_online VALUES('8222','127.0.0.1','1502632959','ol=core&op=core_role','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.90 Safari/537.36','0');

-- --------------------------------------------------------

CREATE TABLE `olala3w_online_daily` (
  `online_daily_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `count` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`online_daily_id`)
) ENGINE=MyISAM AUTO_INCREMENT=675 DEFAULT CHARSET=utf8;

INSERT INTO olala3w_online_daily VALUES('1','2014-08-18','3');
INSERT INTO olala3w_online_daily VALUES('2','2014-08-17','1');
INSERT INTO olala3w_online_daily VALUES('3','2014-08-14','102');
INSERT INTO olala3w_online_daily VALUES('4','2014-08-06','100');
INSERT INTO olala3w_online_daily VALUES('5','2014-08-16','3');
INSERT INTO olala3w_online_daily VALUES('6','2014-08-13','10');
INSERT INTO olala3w_online_daily VALUES('7','2014-08-11','40');
INSERT INTO olala3w_online_daily VALUES('8','2014-08-09','90');
INSERT INTO olala3w_online_daily VALUES('9','2014-08-15','82');
INSERT INTO olala3w_online_daily VALUES('10','2014-08-12','207');
INSERT INTO olala3w_online_daily VALUES('11','2014-08-10','10');
INSERT INTO olala3w_online_daily VALUES('12','2014-08-08','7');
INSERT INTO olala3w_online_daily VALUES('13','2014-08-07','13');
INSERT INTO olala3w_online_daily VALUES('14','2014-08-19','13');
INSERT INTO olala3w_online_daily VALUES('15','2014-08-20','9');
INSERT INTO olala3w_online_daily VALUES('16','2014-08-21','135');
INSERT INTO olala3w_online_daily VALUES('17','2014-08-22','5');
INSERT INTO olala3w_online_daily VALUES('18','2014-09-27','7');
INSERT INTO olala3w_online_daily VALUES('19','2014-09-28','16');
INSERT INTO olala3w_online_daily VALUES('20','2014-09-29','5');
INSERT INTO olala3w_online_daily VALUES('21','2014-09-30','14');
INSERT INTO olala3w_online_daily VALUES('22','2014-10-01','16');
INSERT INTO olala3w_online_daily VALUES('23','2014-10-02','12');
INSERT INTO olala3w_online_daily VALUES('24','2014-10-03','7');
INSERT INTO olala3w_online_daily VALUES('25','2014-10-04','1');
INSERT INTO olala3w_online_daily VALUES('26','2014-10-05','2');
INSERT INTO olala3w_online_daily VALUES('27','2014-10-07','4');
INSERT INTO olala3w_online_daily VALUES('28','2014-10-08','11');
INSERT INTO olala3w_online_daily VALUES('29','2014-10-14','1');
INSERT INTO olala3w_online_daily VALUES('30','2014-10-20','1');
INSERT INTO olala3w_online_daily VALUES('31','2014-10-26','4');
INSERT INTO olala3w_online_daily VALUES('32','2014-10-27','9');
INSERT INTO olala3w_online_daily VALUES('33','2014-10-28','11');
INSERT INTO olala3w_online_daily VALUES('34','2014-10-29','13');
INSERT INTO olala3w_online_daily VALUES('35','2014-10-30','10');
INSERT INTO olala3w_online_daily VALUES('36','2014-10-31','14');
INSERT INTO olala3w_online_daily VALUES('37','2014-11-01','8');
INSERT INTO olala3w_online_daily VALUES('38','2014-11-02','12');
INSERT INTO olala3w_online_daily VALUES('39','2014-11-03','2');
INSERT INTO olala3w_online_daily VALUES('40','2014-11-05','4');
INSERT INTO olala3w_online_daily VALUES('41','2014-11-06','2');
INSERT INTO olala3w_online_daily VALUES('42','2014-11-07','4');
INSERT INTO olala3w_online_daily VALUES('43','2014-11-08','1');
INSERT INTO olala3w_online_daily VALUES('44','2014-11-09','1');
INSERT INTO olala3w_online_daily VALUES('45','2014-11-10','11');
INSERT INTO olala3w_online_daily VALUES('46','2014-11-11','8');
INSERT INTO olala3w_online_daily VALUES('47','2014-11-12','3');
INSERT INTO olala3w_online_daily VALUES('48','2014-11-13','5');
INSERT INTO olala3w_online_daily VALUES('49','2014-11-14','6');
INSERT INTO olala3w_online_daily VALUES('50','2014-11-15','1');
INSERT INTO olala3w_online_daily VALUES('51','2014-11-16','1');
INSERT INTO olala3w_online_daily VALUES('52','2014-11-17','4');
INSERT INTO olala3w_online_daily VALUES('53','2014-11-18','1');
INSERT INTO olala3w_online_daily VALUES('54','2014-11-19','4');
INSERT INTO olala3w_online_daily VALUES('55','2014-11-20','1');
INSERT INTO olala3w_online_daily VALUES('56','2014-11-21','4');
INSERT INTO olala3w_online_daily VALUES('57','2014-11-22','1');
INSERT INTO olala3w_online_daily VALUES('58','2014-11-23','16');
INSERT INTO olala3w_online_daily VALUES('59','2014-11-24','1');
INSERT INTO olala3w_online_daily VALUES('60','2014-11-25','5');
INSERT INTO olala3w_online_daily VALUES('61','2014-11-27','15');
INSERT INTO olala3w_online_daily VALUES('62','2014-11-28','18');
INSERT INTO olala3w_online_daily VALUES('63','2014-11-29','10');
INSERT INTO olala3w_online_daily VALUES('64','2014-11-30','10');
INSERT INTO olala3w_online_daily VALUES('65','2014-12-01','6');
INSERT INTO olala3w_online_daily VALUES('66','2014-12-02','13');
INSERT INTO olala3w_online_daily VALUES('67','2014-12-03','9');
INSERT INTO olala3w_online_daily VALUES('68','2014-12-04','9');
INSERT INTO olala3w_online_daily VALUES('69','2014-12-05','7');
INSERT INTO olala3w_online_daily VALUES('70','2014-12-06','1');
INSERT INTO olala3w_online_daily VALUES('71','2014-12-08','5');
INSERT INTO olala3w_online_daily VALUES('72','2014-12-09','2');
INSERT INTO olala3w_online_daily VALUES('73','2014-12-10','5');
INSERT INTO olala3w_online_daily VALUES('74','2014-12-11','13');
INSERT INTO olala3w_online_daily VALUES('75','2014-12-12','4');
INSERT INTO olala3w_online_daily VALUES('76','2014-12-16','2');
INSERT INTO olala3w_online_daily VALUES('77','2014-12-20','11');
INSERT INTO olala3w_online_daily VALUES('78','2014-12-21','6');
INSERT INTO olala3w_online_daily VALUES('79','2014-12-22','5');
INSERT INTO olala3w_online_daily VALUES('80','2014-12-23','3');
INSERT INTO olala3w_online_daily VALUES('81','2014-12-24','1');
INSERT INTO olala3w_online_daily VALUES('82','2014-12-26','2');
INSERT INTO olala3w_online_daily VALUES('83','2014-12-27','10');
INSERT INTO olala3w_online_daily VALUES('84','0000-00-00','1');
INSERT INTO olala3w_online_daily VALUES('85','2014-12-28','15');
INSERT INTO olala3w_online_daily VALUES('86','2014-12-29','11');
INSERT INTO olala3w_online_daily VALUES('87','2014-12-30','1');
INSERT INTO olala3w_online_daily VALUES('88','2015-01-02','11');
INSERT INTO olala3w_online_daily VALUES('89','2015-01-03','4');
INSERT INTO olala3w_online_daily VALUES('90','2015-01-04','2');
INSERT INTO olala3w_online_daily VALUES('91','2015-01-05','9');
INSERT INTO olala3w_online_daily VALUES('92','2015-01-06','7');
INSERT INTO olala3w_online_daily VALUES('93','2015-01-07','1');
INSERT INTO olala3w_online_daily VALUES('94','2015-01-08','7');
INSERT INTO olala3w_online_daily VALUES('95','2015-01-09','13');
INSERT INTO olala3w_online_daily VALUES('96','2015-01-10','2');
INSERT INTO olala3w_online_daily VALUES('97','2015-01-12','1');
INSERT INTO olala3w_online_daily VALUES('98','2015-01-19','2');
INSERT INTO olala3w_online_daily VALUES('99','2015-01-20','12');
INSERT INTO olala3w_online_daily VALUES('100','2015-01-21','8');
INSERT INTO olala3w_online_daily VALUES('101','2015-01-22','43');
INSERT INTO olala3w_online_daily VALUES('102','2015-01-23','36');
INSERT INTO olala3w_online_daily VALUES('103','2015-01-24','34');
INSERT INTO olala3w_online_daily VALUES('104','2015-01-24','34');
INSERT INTO olala3w_online_daily VALUES('105','2015-01-25','46');
INSERT INTO olala3w_online_daily VALUES('106','2015-01-26','51');
INSERT INTO olala3w_online_daily VALUES('107','2015-01-27','53');
INSERT INTO olala3w_online_daily VALUES('108','2015-01-28','46');
INSERT INTO olala3w_online_daily VALUES('109','2015-01-29','471');
INSERT INTO olala3w_online_daily VALUES('110','2015-01-30','191');
INSERT INTO olala3w_online_daily VALUES('111','2015-01-31','106');
INSERT INTO olala3w_online_daily VALUES('112','2015-02-01','61');
INSERT INTO olala3w_online_daily VALUES('113','2015-02-02','37');
INSERT INTO olala3w_online_daily VALUES('114','2015-02-03','53');
INSERT INTO olala3w_online_daily VALUES('115','2015-02-04','66');
INSERT INTO olala3w_online_daily VALUES('116','2015-02-05','63');
INSERT INTO olala3w_online_daily VALUES('117','2015-02-06','86');
INSERT INTO olala3w_online_daily VALUES('118','2015-02-07','63');
INSERT INTO olala3w_online_daily VALUES('119','2015-02-08','68');
INSERT INTO olala3w_online_daily VALUES('120','2015-02-09','64');
INSERT INTO olala3w_online_daily VALUES('121','2015-02-10','46');
INSERT INTO olala3w_online_daily VALUES('122','2015-02-11','53');
INSERT INTO olala3w_online_daily VALUES('123','2015-02-12','28');
INSERT INTO olala3w_online_daily VALUES('124','2015-02-13','155');
INSERT INTO olala3w_online_daily VALUES('125','2015-02-14','43');
INSERT INTO olala3w_online_daily VALUES('126','2015-02-15','27');
INSERT INTO olala3w_online_daily VALUES('127','2015-02-16','22');
INSERT INTO olala3w_online_daily VALUES('128','2015-02-17','20');
INSERT INTO olala3w_online_daily VALUES('129','2015-02-18','19');
INSERT INTO olala3w_online_daily VALUES('130','2015-02-19','16');
INSERT INTO olala3w_online_daily VALUES('131','2015-02-20','18');
INSERT INTO olala3w_online_daily VALUES('132','2015-02-21','33');
INSERT INTO olala3w_online_daily VALUES('133','2015-02-22','31');
INSERT INTO olala3w_online_daily VALUES('134','2015-02-23','34');
INSERT INTO olala3w_online_daily VALUES('135','2015-02-24','22');
INSERT INTO olala3w_online_daily VALUES('136','2015-02-25','26');
INSERT INTO olala3w_online_daily VALUES('137','2015-02-26','34');
INSERT INTO olala3w_online_daily VALUES('138','2015-02-27','19');
INSERT INTO olala3w_online_daily VALUES('139','2015-02-28','5');
INSERT INTO olala3w_online_daily VALUES('140','2015-03-01','12');
INSERT INTO olala3w_online_daily VALUES('141','2015-03-02','24');
INSERT INTO olala3w_online_daily VALUES('142','2015-03-03','48');
INSERT INTO olala3w_online_daily VALUES('143','2015-03-04','49');
INSERT INTO olala3w_online_daily VALUES('144','2015-03-05','43');
INSERT INTO olala3w_online_daily VALUES('145','2015-03-06','33');
INSERT INTO olala3w_online_daily VALUES('146','2015-03-07','52');
INSERT INTO olala3w_online_daily VALUES('147','2015-03-08','26');
INSERT INTO olala3w_online_daily VALUES('148','2015-03-09','46');
INSERT INTO olala3w_online_daily VALUES('149','2015-03-10','37');
INSERT INTO olala3w_online_daily VALUES('150','2015-03-11','47');
INSERT INTO olala3w_online_daily VALUES('151','2015-03-12','33');
INSERT INTO olala3w_online_daily VALUES('152','2015-03-13','28');
INSERT INTO olala3w_online_daily VALUES('153','2015-03-14','2');
INSERT INTO olala3w_online_daily VALUES('154','2015-03-16','5');
INSERT INTO olala3w_online_daily VALUES('155','2015-03-17','18');
INSERT INTO olala3w_online_daily VALUES('156','2015-03-18','11');
INSERT INTO olala3w_online_daily VALUES('157','2015-03-19','21');
INSERT INTO olala3w_online_daily VALUES('158','2015-03-20','18');
INSERT INTO olala3w_online_daily VALUES('159','2015-03-21','3');
INSERT INTO olala3w_online_daily VALUES('160','2015-05-06','5');
INSERT INTO olala3w_online_daily VALUES('161','2015-05-07','4');
INSERT INTO olala3w_online_daily VALUES('162','2015-05-08','3');
INSERT INTO olala3w_online_daily VALUES('163','2015-05-09','2');
INSERT INTO olala3w_online_daily VALUES('164','2015-05-10','8');
INSERT INTO olala3w_online_daily VALUES('165','2015-05-11','3');
INSERT INTO olala3w_online_daily VALUES('166','2015-05-12','4');
INSERT INTO olala3w_online_daily VALUES('167','2015-05-15','1');
INSERT INTO olala3w_online_daily VALUES('168','2015-05-16','2');
INSERT INTO olala3w_online_daily VALUES('169','2015-05-17','2');
INSERT INTO olala3w_online_daily VALUES('170','2015-05-18','1');
INSERT INTO olala3w_online_daily VALUES('171','2015-05-19','3');
INSERT INTO olala3w_online_daily VALUES('172','2015-05-23','1');
INSERT INTO olala3w_online_daily VALUES('173','2015-05-24','1');
INSERT INTO olala3w_online_daily VALUES('174','2015-05-25','2');
INSERT INTO olala3w_online_daily VALUES('175','2015-05-26','2');
INSERT INTO olala3w_online_daily VALUES('176','2015-05-27','4');
INSERT INTO olala3w_online_daily VALUES('177','2015-05-28','4');
INSERT INTO olala3w_online_daily VALUES('178','2015-05-29','3');
INSERT INTO olala3w_online_daily VALUES('179','2015-05-31','3');
INSERT INTO olala3w_online_daily VALUES('180','2015-06-01','1');
INSERT INTO olala3w_online_daily VALUES('181','2015-06-02','2');
INSERT INTO olala3w_online_daily VALUES('182','2015-06-03','3');
INSERT INTO olala3w_online_daily VALUES('183','2015-06-04','3');
INSERT INTO olala3w_online_daily VALUES('184','2015-06-05','1');
INSERT INTO olala3w_online_daily VALUES('185','2015-06-06','1');
INSERT INTO olala3w_online_daily VALUES('186','2015-06-08','1');
INSERT INTO olala3w_online_daily VALUES('187','2015-06-09','2');
INSERT INTO olala3w_online_daily VALUES('188','2015-06-10','1');
INSERT INTO olala3w_online_daily VALUES('189','2015-06-11','2');
INSERT INTO olala3w_online_daily VALUES('190','2015-06-12','3');
INSERT INTO olala3w_online_daily VALUES('191','2015-06-13','2');
INSERT INTO olala3w_online_daily VALUES('192','2015-06-14','1');
INSERT INTO olala3w_online_daily VALUES('193','2015-06-15','4');
INSERT INTO olala3w_online_daily VALUES('194','2015-06-16','1');
INSERT INTO olala3w_online_daily VALUES('195','2015-06-17','1');
INSERT INTO olala3w_online_daily VALUES('196','2015-06-18','1');
INSERT INTO olala3w_online_daily VALUES('197','2015-06-21','1');
INSERT INTO olala3w_online_daily VALUES('198','2015-06-22','3');
INSERT INTO olala3w_online_daily VALUES('199','2015-06-23','1');
INSERT INTO olala3w_online_daily VALUES('200','2015-06-24','8');
INSERT INTO olala3w_online_daily VALUES('201','2015-06-28','1');
INSERT INTO olala3w_online_daily VALUES('202','2015-06-29','3');
INSERT INTO olala3w_online_daily VALUES('203','2015-06-30','4');
INSERT INTO olala3w_online_daily VALUES('204','2015-07-01','4');
INSERT INTO olala3w_online_daily VALUES('205','2015-07-02','3');
INSERT INTO olala3w_online_daily VALUES('206','2015-07-03','3');
INSERT INTO olala3w_online_daily VALUES('207','2015-07-06','1');
INSERT INTO olala3w_online_daily VALUES('208','2015-07-07','1');
INSERT INTO olala3w_online_daily VALUES('209','2015-07-12','4');
INSERT INTO olala3w_online_daily VALUES('210','2015-07-13','6');
INSERT INTO olala3w_online_daily VALUES('211','2015-07-14','29');
INSERT INTO olala3w_online_daily VALUES('212','2015-07-15','190');
INSERT INTO olala3w_online_daily VALUES('213','2015-07-16','361');
INSERT INTO olala3w_online_daily VALUES('214','2015-07-17','354');
INSERT INTO olala3w_online_daily VALUES('215','2015-07-18','238');
INSERT INTO olala3w_online_daily VALUES('216','2015-07-19','343');
INSERT INTO olala3w_online_daily VALUES('217','2015-07-20','802');
INSERT INTO olala3w_online_daily VALUES('218','2015-07-21','1926');
INSERT INTO olala3w_online_daily VALUES('219','2015-07-22','1349');
INSERT INTO olala3w_online_daily VALUES('220','2015-07-23','1648');
INSERT INTO olala3w_online_daily VALUES('221','2015-07-24','2370');
INSERT INTO olala3w_online_daily VALUES('222','2015-07-25','4986');
INSERT INTO olala3w_online_daily VALUES('223','2015-07-26','2251');
INSERT INTO olala3w_online_daily VALUES('224','2015-07-27','3882');
INSERT INTO olala3w_online_daily VALUES('225','2015-07-28','3496');
INSERT INTO olala3w_online_daily VALUES('226','2015-07-29','3603');
INSERT INTO olala3w_online_daily VALUES('227','2015-07-30','2778');
INSERT INTO olala3w_online_daily VALUES('228','2015-07-31','5');
INSERT INTO olala3w_online_daily VALUES('229','2015-08-01','2');
INSERT INTO olala3w_online_daily VALUES('230','2015-08-02','3');
INSERT INTO olala3w_online_daily VALUES('231','2015-08-03','2');
INSERT INTO olala3w_online_daily VALUES('232','2015-08-05','5');
INSERT INTO olala3w_online_daily VALUES('233','2015-08-06','1');
INSERT INTO olala3w_online_daily VALUES('234','2015-08-07','5');
INSERT INTO olala3w_online_daily VALUES('235','2015-08-08','8');
INSERT INTO olala3w_online_daily VALUES('236','2015-08-09','7');
INSERT INTO olala3w_online_daily VALUES('237','2015-08-10','6');
INSERT INTO olala3w_online_daily VALUES('238','2015-08-11','1');
INSERT INTO olala3w_online_daily VALUES('239','2015-08-12','2');
INSERT INTO olala3w_online_daily VALUES('240','2015-08-13','3');
INSERT INTO olala3w_online_daily VALUES('241','2015-08-14','1');
INSERT INTO olala3w_online_daily VALUES('242','2015-08-16','2');
INSERT INTO olala3w_online_daily VALUES('243','2015-08-17','2');
INSERT INTO olala3w_online_daily VALUES('244','2015-08-18','1');
INSERT INTO olala3w_online_daily VALUES('245','2015-08-27','9');
INSERT INTO olala3w_online_daily VALUES('246','2015-08-28','9');
INSERT INTO olala3w_online_daily VALUES('247','2015-08-29','5');
INSERT INTO olala3w_online_daily VALUES('248','2015-08-30','3');
INSERT INTO olala3w_online_daily VALUES('249','2015-08-31','8');
INSERT INTO olala3w_online_daily VALUES('250','2015-09-03','9');
INSERT INTO olala3w_online_daily VALUES('251','2015-09-04','10');
INSERT INTO olala3w_online_daily VALUES('252','2015-09-05','7');
INSERT INTO olala3w_online_daily VALUES('253','2015-09-06','4');
INSERT INTO olala3w_online_daily VALUES('254','2015-09-07','6');
INSERT INTO olala3w_online_daily VALUES('255','2015-09-08','31');
INSERT INTO olala3w_online_daily VALUES('256','2015-09-09','34');
INSERT INTO olala3w_online_daily VALUES('257','2015-09-10','48');
INSERT INTO olala3w_online_daily VALUES('258','2015-09-11','47');
INSERT INTO olala3w_online_daily VALUES('259','2015-09-12','35');
INSERT INTO olala3w_online_daily VALUES('260','2015-09-13','25');
INSERT INTO olala3w_online_daily VALUES('261','2015-09-14','35');
INSERT INTO olala3w_online_daily VALUES('262','2015-09-15','34');
INSERT INTO olala3w_online_daily VALUES('263','2015-09-16','40');
INSERT INTO olala3w_online_daily VALUES('264','2015-09-17','44');
INSERT INTO olala3w_online_daily VALUES('265','2015-09-18','48');
INSERT INTO olala3w_online_daily VALUES('266','2015-09-19','37');
INSERT INTO olala3w_online_daily VALUES('267','2015-09-20','30');
INSERT INTO olala3w_online_daily VALUES('268','2015-09-21','53');
INSERT INTO olala3w_online_daily VALUES('269','2015-09-22','41');
INSERT INTO olala3w_online_daily VALUES('270','2015-09-23','54');
INSERT INTO olala3w_online_daily VALUES('271','2015-09-24','59');
INSERT INTO olala3w_online_daily VALUES('272','2015-09-25','51');
INSERT INTO olala3w_online_daily VALUES('273','2015-09-26','218');
INSERT INTO olala3w_online_daily VALUES('274','2015-09-27','104');
INSERT INTO olala3w_online_daily VALUES('275','2015-09-28','183');
INSERT INTO olala3w_online_daily VALUES('276','2015-09-29','221');
INSERT INTO olala3w_online_daily VALUES('277','2015-09-30','171');
INSERT INTO olala3w_online_daily VALUES('278','2015-10-01','30');
INSERT INTO olala3w_online_daily VALUES('279','2015-10-02','166');
INSERT INTO olala3w_online_daily VALUES('280','2015-10-03','135');
INSERT INTO olala3w_online_daily VALUES('281','2015-10-04','123');
INSERT INTO olala3w_online_daily VALUES('282','2015-10-05','122');
INSERT INTO olala3w_online_daily VALUES('283','2015-10-06','131');
INSERT INTO olala3w_online_daily VALUES('284','2015-10-07','38');
INSERT INTO olala3w_online_daily VALUES('285','2015-10-08','109');
INSERT INTO olala3w_online_daily VALUES('286','2015-10-09','143');
INSERT INTO olala3w_online_daily VALUES('287','2015-10-10','157');
INSERT INTO olala3w_online_daily VALUES('288','2015-10-11','138');
INSERT INTO olala3w_online_daily VALUES('289','2015-10-12','194');
INSERT INTO olala3w_online_daily VALUES('290','2015-10-13','133');
INSERT INTO olala3w_online_daily VALUES('291','2015-10-14','167');
INSERT INTO olala3w_online_daily VALUES('292','2015-10-15','161');
INSERT INTO olala3w_online_daily VALUES('293','2015-10-16','171');
INSERT INTO olala3w_online_daily VALUES('294','2015-10-17','129');
INSERT INTO olala3w_online_daily VALUES('295','2015-10-18','145');
INSERT INTO olala3w_online_daily VALUES('296','2015-10-19','179');
INSERT INTO olala3w_online_daily VALUES('297','2015-10-20','145');
INSERT INTO olala3w_online_daily VALUES('298','2015-10-21','158');
INSERT INTO olala3w_online_daily VALUES('299','2015-10-22','166');
INSERT INTO olala3w_online_daily VALUES('300','2015-10-23','172');
INSERT INTO olala3w_online_daily VALUES('301','2015-10-24','181');
INSERT INTO olala3w_online_daily VALUES('302','2015-10-25','211');
INSERT INTO olala3w_online_daily VALUES('303','2015-10-26','173');
INSERT INTO olala3w_online_daily VALUES('304','2015-10-27','160');
INSERT INTO olala3w_online_daily VALUES('305','2015-10-28','153');
INSERT INTO olala3w_online_daily VALUES('306','2015-10-29','93');
INSERT INTO olala3w_online_daily VALUES('307','2015-10-30','42');
INSERT INTO olala3w_online_daily VALUES('308','2015-10-31','41');
INSERT INTO olala3w_online_daily VALUES('309','2015-11-01','28');
INSERT INTO olala3w_online_daily VALUES('310','2015-11-02','41');
INSERT INTO olala3w_online_daily VALUES('311','2015-11-03','44');
INSERT INTO olala3w_online_daily VALUES('312','2015-11-04','35');
INSERT INTO olala3w_online_daily VALUES('313','2015-11-05','32');
INSERT INTO olala3w_online_daily VALUES('314','2015-11-06','52');
INSERT INTO olala3w_online_daily VALUES('315','2015-11-07','34');
INSERT INTO olala3w_online_daily VALUES('316','2015-11-08','34');
INSERT INTO olala3w_online_daily VALUES('317','2015-11-09','40');
INSERT INTO olala3w_online_daily VALUES('318','2015-11-10','27');
INSERT INTO olala3w_online_daily VALUES('319','2015-11-11','36');
INSERT INTO olala3w_online_daily VALUES('320','2015-11-12','48');
INSERT INTO olala3w_online_daily VALUES('321','2015-11-13','38');
INSERT INTO olala3w_online_daily VALUES('322','2015-11-14','48');
INSERT INTO olala3w_online_daily VALUES('323','2015-11-15','34');
INSERT INTO olala3w_online_daily VALUES('324','2015-11-16','47');
INSERT INTO olala3w_online_daily VALUES('325','2015-11-17','37');
INSERT INTO olala3w_online_daily VALUES('326','2015-11-18','37');
INSERT INTO olala3w_online_daily VALUES('327','2015-11-19','44');
INSERT INTO olala3w_online_daily VALUES('328','2015-11-20','36');
INSERT INTO olala3w_online_daily VALUES('329','2015-11-21','42');
INSERT INTO olala3w_online_daily VALUES('330','2015-11-22','31');
INSERT INTO olala3w_online_daily VALUES('331','2015-11-23','30');
INSERT INTO olala3w_online_daily VALUES('332','2015-11-24','34');
INSERT INTO olala3w_online_daily VALUES('333','2015-11-25','32');
INSERT INTO olala3w_online_daily VALUES('334','2015-11-26','36');
INSERT INTO olala3w_online_daily VALUES('335','2015-11-27','30');
INSERT INTO olala3w_online_daily VALUES('336','2015-11-28','29');
INSERT INTO olala3w_online_daily VALUES('337','2015-11-29','24');
INSERT INTO olala3w_online_daily VALUES('338','2015-11-30','39');
INSERT INTO olala3w_online_daily VALUES('339','2015-12-01','34');
INSERT INTO olala3w_online_daily VALUES('340','2015-12-02','34');
INSERT INTO olala3w_online_daily VALUES('341','2015-12-03','34');
INSERT INTO olala3w_online_daily VALUES('342','2015-12-04','37');
INSERT INTO olala3w_online_daily VALUES('343','2015-12-05','30');
INSERT INTO olala3w_online_daily VALUES('344','2015-12-06','31');
INSERT INTO olala3w_online_daily VALUES('345','2015-12-07','30');
INSERT INTO olala3w_online_daily VALUES('346','2015-12-08','37');
INSERT INTO olala3w_online_daily VALUES('347','2015-12-09','23');
INSERT INTO olala3w_online_daily VALUES('348','2015-12-10','26');
INSERT INTO olala3w_online_daily VALUES('349','2015-12-11','29');
INSERT INTO olala3w_online_daily VALUES('350','2015-12-12','38');
INSERT INTO olala3w_online_daily VALUES('351','2015-12-13','34');
INSERT INTO olala3w_online_daily VALUES('352','2015-12-14','27');
INSERT INTO olala3w_online_daily VALUES('353','2015-12-15','34');
INSERT INTO olala3w_online_daily VALUES('354','2015-12-16','42');
INSERT INTO olala3w_online_daily VALUES('355','2015-12-17','39');
INSERT INTO olala3w_online_daily VALUES('356','2015-12-18','43');
INSERT INTO olala3w_online_daily VALUES('357','2015-12-19','34');
INSERT INTO olala3w_online_daily VALUES('358','2015-12-20','40');
INSERT INTO olala3w_online_daily VALUES('359','2015-12-21','35');
INSERT INTO olala3w_online_daily VALUES('360','2015-12-22','31');
INSERT INTO olala3w_online_daily VALUES('361','2015-12-23','36');
INSERT INTO olala3w_online_daily VALUES('362','2015-12-24','48');
INSERT INTO olala3w_online_daily VALUES('363','2015-12-25','32');
INSERT INTO olala3w_online_daily VALUES('364','2015-12-26','33');
INSERT INTO olala3w_online_daily VALUES('365','2015-12-27','26');
INSERT INTO olala3w_online_daily VALUES('366','2015-12-28','57');
INSERT INTO olala3w_online_daily VALUES('367','2015-12-29','38');
INSERT INTO olala3w_online_daily VALUES('368','2015-12-30','43');
INSERT INTO olala3w_online_daily VALUES('369','2015-12-31','41');
INSERT INTO olala3w_online_daily VALUES('370','2016-01-01','41');
INSERT INTO olala3w_online_daily VALUES('371','2016-01-02','39');
INSERT INTO olala3w_online_daily VALUES('372','2016-01-03','28');
INSERT INTO olala3w_online_daily VALUES('373','2016-01-04','44');
INSERT INTO olala3w_online_daily VALUES('374','2016-01-05','43');
INSERT INTO olala3w_online_daily VALUES('375','2016-01-06','43');
INSERT INTO olala3w_online_daily VALUES('376','2016-01-07','68');
INSERT INTO olala3w_online_daily VALUES('377','2016-01-08','74');
INSERT INTO olala3w_online_daily VALUES('378','2016-01-09','74');
INSERT INTO olala3w_online_daily VALUES('379','2016-01-10','81');
INSERT INTO olala3w_online_daily VALUES('380','2016-01-11','75');
INSERT INTO olala3w_online_daily VALUES('381','2016-01-12','66');
INSERT INTO olala3w_online_daily VALUES('382','2016-01-13','61');
INSERT INTO olala3w_online_daily VALUES('383','2016-01-14','58');
INSERT INTO olala3w_online_daily VALUES('384','2016-01-15','62');
INSERT INTO olala3w_online_daily VALUES('385','2016-01-16','68');
INSERT INTO olala3w_online_daily VALUES('386','2016-01-17','68');
INSERT INTO olala3w_online_daily VALUES('387','2016-01-18','63');
INSERT INTO olala3w_online_daily VALUES('388','2016-01-19','71');
INSERT INTO olala3w_online_daily VALUES('389','2016-01-20','67');
INSERT INTO olala3w_online_daily VALUES('390','2016-01-21','52');
INSERT INTO olala3w_online_daily VALUES('391','2016-01-22','56');
INSERT INTO olala3w_online_daily VALUES('392','2016-01-23','60');
INSERT INTO olala3w_online_daily VALUES('393','2016-01-24','52');
INSERT INTO olala3w_online_daily VALUES('394','2016-01-25','60');
INSERT INTO olala3w_online_daily VALUES('395','2016-01-26','63');
INSERT INTO olala3w_online_daily VALUES('396','2016-01-27','54');
INSERT INTO olala3w_online_daily VALUES('397','2016-01-28','54');
INSERT INTO olala3w_online_daily VALUES('398','2016-01-29','62');
INSERT INTO olala3w_online_daily VALUES('399','2016-01-30','59');
INSERT INTO olala3w_online_daily VALUES('400','2016-01-31','57');
INSERT INTO olala3w_online_daily VALUES('401','2016-02-01','60');
INSERT INTO olala3w_online_daily VALUES('402','2016-02-02','59');
INSERT INTO olala3w_online_daily VALUES('403','2016-02-03','42');
INSERT INTO olala3w_online_daily VALUES('404','2016-02-04','32');
INSERT INTO olala3w_online_daily VALUES('405','2016-02-05','47');
INSERT INTO olala3w_online_daily VALUES('406','2016-02-06','60');
INSERT INTO olala3w_online_daily VALUES('407','2016-02-07','37');
INSERT INTO olala3w_online_daily VALUES('408','2016-02-08','34');
INSERT INTO olala3w_online_daily VALUES('409','2016-02-09','58');
INSERT INTO olala3w_online_daily VALUES('410','2016-02-10','41');
INSERT INTO olala3w_online_daily VALUES('411','2016-02-11','43');
INSERT INTO olala3w_online_daily VALUES('412','2016-02-12','49');
INSERT INTO olala3w_online_daily VALUES('413','2016-02-13','42');
INSERT INTO olala3w_online_daily VALUES('414','2016-02-14','38');
INSERT INTO olala3w_online_daily VALUES('415','2016-02-15','48');
INSERT INTO olala3w_online_daily VALUES('416','2016-02-16','54');
INSERT INTO olala3w_online_daily VALUES('417','2016-02-17','55');
INSERT INTO olala3w_online_daily VALUES('418','2016-02-18','56');
INSERT INTO olala3w_online_daily VALUES('419','2016-02-19','54');
INSERT INTO olala3w_online_daily VALUES('420','2016-02-20','44');
INSERT INTO olala3w_online_daily VALUES('421','2016-02-21','49');
INSERT INTO olala3w_online_daily VALUES('422','2016-02-22','47');
INSERT INTO olala3w_online_daily VALUES('423','2016-02-23','50');
INSERT INTO olala3w_online_daily VALUES('424','2016-02-24','49');
INSERT INTO olala3w_online_daily VALUES('425','2016-02-25','44');
INSERT INTO olala3w_online_daily VALUES('426','2016-02-26','31');
INSERT INTO olala3w_online_daily VALUES('427','2016-02-27','34');
INSERT INTO olala3w_online_daily VALUES('428','2016-02-28','44');
INSERT INTO olala3w_online_daily VALUES('429','2016-02-29','43');
INSERT INTO olala3w_online_daily VALUES('430','2016-03-01','23');
INSERT INTO olala3w_online_daily VALUES('431','2016-03-02','45');
INSERT INTO olala3w_online_daily VALUES('432','2016-03-03','54');
INSERT INTO olala3w_online_daily VALUES('433','2016-03-04','59');
INSERT INTO olala3w_online_daily VALUES('434','2016-03-05','54');
INSERT INTO olala3w_online_daily VALUES('435','2016-03-06','70');
INSERT INTO olala3w_online_daily VALUES('436','2016-03-07','54');
INSERT INTO olala3w_online_daily VALUES('437','2016-03-08','41');
INSERT INTO olala3w_online_daily VALUES('438','2016-03-09','54');
INSERT INTO olala3w_online_daily VALUES('439','2016-03-10','48');
INSERT INTO olala3w_online_daily VALUES('440','2016-03-11','42');
INSERT INTO olala3w_online_daily VALUES('441','2016-03-12','40');
INSERT INTO olala3w_online_daily VALUES('442','2016-03-13','51');
INSERT INTO olala3w_online_daily VALUES('443','2016-03-14','50');
INSERT INTO olala3w_online_daily VALUES('444','2016-03-15','45');
INSERT INTO olala3w_online_daily VALUES('445','2016-03-16','56');
INSERT INTO olala3w_online_daily VALUES('446','2016-03-17','47');
INSERT INTO olala3w_online_daily VALUES('447','2016-03-18','35');
INSERT INTO olala3w_online_daily VALUES('448','2016-03-19','39');
INSERT INTO olala3w_online_daily VALUES('449','2016-03-20','55');
INSERT INTO olala3w_online_daily VALUES('450','2016-03-21','56');
INSERT INTO olala3w_online_daily VALUES('451','2016-03-22','60');
INSERT INTO olala3w_online_daily VALUES('452','2016-03-23','59');
INSERT INTO olala3w_online_daily VALUES('453','2016-03-24','48');
INSERT INTO olala3w_online_daily VALUES('454','2016-03-25','41');
INSERT INTO olala3w_online_daily VALUES('455','2016-03-26','51');
INSERT INTO olala3w_online_daily VALUES('456','2016-03-27','51');
INSERT INTO olala3w_online_daily VALUES('457','2016-03-28','22');
INSERT INTO olala3w_online_daily VALUES('458','2016-03-30','3');
INSERT INTO olala3w_online_daily VALUES('459','2016-03-31','8');
INSERT INTO olala3w_online_daily VALUES('460','2016-04-01','6');
INSERT INTO olala3w_online_daily VALUES('461','2016-04-02','5');
INSERT INTO olala3w_online_daily VALUES('462','2016-04-02','5');
INSERT INTO olala3w_online_daily VALUES('463','2016-04-04','6');
INSERT INTO olala3w_online_daily VALUES('464','2016-04-05','5');
INSERT INTO olala3w_online_daily VALUES('465','2016-04-06','3');
INSERT INTO olala3w_online_daily VALUES('466','2016-04-07','5');
INSERT INTO olala3w_online_daily VALUES('467','2016-04-07','5');
INSERT INTO olala3w_online_daily VALUES('468','2016-04-08','4');
INSERT INTO olala3w_online_daily VALUES('469','2016-04-09','6');
INSERT INTO olala3w_online_daily VALUES('470','2016-04-09','6');
INSERT INTO olala3w_online_daily VALUES('471','2016-04-11','7');
INSERT INTO olala3w_online_daily VALUES('472','2016-04-12','6');
INSERT INTO olala3w_online_daily VALUES('473','2016-04-13','18');
INSERT INTO olala3w_online_daily VALUES('474','2016-04-14','19');
INSERT INTO olala3w_online_daily VALUES('475','2016-04-15','1');
INSERT INTO olala3w_online_daily VALUES('476','2016-04-16','3');
INSERT INTO olala3w_online_daily VALUES('477','2016-04-17','2');
INSERT INTO olala3w_online_daily VALUES('478','2016-04-18','11');
INSERT INTO olala3w_online_daily VALUES('479','2016-04-19','16');
INSERT INTO olala3w_online_daily VALUES('480','2016-04-20','21');
INSERT INTO olala3w_online_daily VALUES('481','2016-04-21','16');
INSERT INTO olala3w_online_daily VALUES('482','2016-04-22','5');
INSERT INTO olala3w_online_daily VALUES('483','2016-04-23','5');
INSERT INTO olala3w_online_daily VALUES('484','2016-04-24','1');
INSERT INTO olala3w_online_daily VALUES('485','2016-04-25','15');
INSERT INTO olala3w_online_daily VALUES('486','2016-04-26','8');
INSERT INTO olala3w_online_daily VALUES('487','2016-04-27','23');
INSERT INTO olala3w_online_daily VALUES('488','2016-04-28','37');
INSERT INTO olala3w_online_daily VALUES('489','2016-04-29','23');
INSERT INTO olala3w_online_daily VALUES('490','2016-04-30','4');
INSERT INTO olala3w_online_daily VALUES('491','2016-05-01','1');
INSERT INTO olala3w_online_daily VALUES('492','2016-05-02','1');
INSERT INTO olala3w_online_daily VALUES('493','2016-05-03','45');
INSERT INTO olala3w_online_daily VALUES('494','2016-05-04','22');
INSERT INTO olala3w_online_daily VALUES('495','2016-05-05','20');
INSERT INTO olala3w_online_daily VALUES('496','2016-05-06','28');
INSERT INTO olala3w_online_daily VALUES('497','2016-05-07','6');
INSERT INTO olala3w_online_daily VALUES('498','2016-05-09','33');
INSERT INTO olala3w_online_daily VALUES('499','2016-05-10','23');
INSERT INTO olala3w_online_daily VALUES('500','2016-05-11','22');
INSERT INTO olala3w_online_daily VALUES('501','2016-05-12','24');
INSERT INTO olala3w_online_daily VALUES('502','2016-05-13','24');
INSERT INTO olala3w_online_daily VALUES('503','2016-05-14','9');
INSERT INTO olala3w_online_daily VALUES('504','2016-05-15','2');
INSERT INTO olala3w_online_daily VALUES('505','2016-05-16','14');
INSERT INTO olala3w_online_daily VALUES('506','2016-05-17','15');
INSERT INTO olala3w_online_daily VALUES('507','2016-05-18','15');
INSERT INTO olala3w_online_daily VALUES('508','2016-05-19','15');
INSERT INTO olala3w_online_daily VALUES('509','2016-05-20','20');
INSERT INTO olala3w_online_daily VALUES('510','2016-05-21','6');
INSERT INTO olala3w_online_daily VALUES('511','2016-05-23','15');
INSERT INTO olala3w_online_daily VALUES('512','2016-05-24','7');
INSERT INTO olala3w_online_daily VALUES('513','2016-05-25','13');
INSERT INTO olala3w_online_daily VALUES('514','2016-05-26','4');
INSERT INTO olala3w_online_daily VALUES('515','2016-05-27','10');
INSERT INTO olala3w_online_daily VALUES('516','2016-05-28','4');
INSERT INTO olala3w_online_daily VALUES('517','2016-05-29','5');
INSERT INTO olala3w_online_daily VALUES('518','2016-05-30','13');
INSERT INTO olala3w_online_daily VALUES('519','2016-05-31','9');
INSERT INTO olala3w_online_daily VALUES('520','2016-06-01','9');
INSERT INTO olala3w_online_daily VALUES('521','2016-06-02','5');
INSERT INTO olala3w_online_daily VALUES('522','2016-06-03','7');
INSERT INTO olala3w_online_daily VALUES('523','2016-06-04','4');
INSERT INTO olala3w_online_daily VALUES('524','2016-06-06','10');
INSERT INTO olala3w_online_daily VALUES('525','2016-06-07','8');
INSERT INTO olala3w_online_daily VALUES('526','2016-06-08','9');
INSERT INTO olala3w_online_daily VALUES('527','2016-06-09','13');
INSERT INTO olala3w_online_daily VALUES('528','2016-06-10','11');
INSERT INTO olala3w_online_daily VALUES('529','2016-06-11','3');
INSERT INTO olala3w_online_daily VALUES('530','2016-06-13','11');
INSERT INTO olala3w_online_daily VALUES('531','2016-06-14','9');
INSERT INTO olala3w_online_daily VALUES('532','2016-06-15','2');
INSERT INTO olala3w_online_daily VALUES('533','2016-06-16','8');
INSERT INTO olala3w_online_daily VALUES('534','2016-06-17','11');
INSERT INTO olala3w_online_daily VALUES('535','2016-06-18','2');
INSERT INTO olala3w_online_daily VALUES('536','2016-06-20','10');
INSERT INTO olala3w_online_daily VALUES('537','2016-06-21','10');
INSERT INTO olala3w_online_daily VALUES('538','2016-06-22','9');
INSERT INTO olala3w_online_daily VALUES('539','2016-06-23','11');
INSERT INTO olala3w_online_daily VALUES('540','2016-06-24','3');
INSERT INTO olala3w_online_daily VALUES('541','2016-06-25','4');
INSERT INTO olala3w_online_daily VALUES('542','2016-06-27','7');
INSERT INTO olala3w_online_daily VALUES('543','2016-06-28','4');
INSERT INTO olala3w_online_daily VALUES('544','2016-06-29','10');
INSERT INTO olala3w_online_daily VALUES('545','2016-06-30','1');
INSERT INTO olala3w_online_daily VALUES('546','2016-07-01','9');
INSERT INTO olala3w_online_daily VALUES('547','2016-07-02','5');
INSERT INTO olala3w_online_daily VALUES('548','2016-07-03','2');
INSERT INTO olala3w_online_daily VALUES('549','2016-07-04','4');
INSERT INTO olala3w_online_daily VALUES('550','2016-07-05','4');
INSERT INTO olala3w_online_daily VALUES('551','2016-07-06','11');
INSERT INTO olala3w_online_daily VALUES('552','2016-07-07','2');
INSERT INTO olala3w_online_daily VALUES('553','2016-07-08','15');
INSERT INTO olala3w_online_daily VALUES('554','2016-07-09','5');
INSERT INTO olala3w_online_daily VALUES('555','2016-07-10','2');
INSERT INTO olala3w_online_daily VALUES('556','2016-07-11','3');
INSERT INTO olala3w_online_daily VALUES('557','2016-07-13','1');
INSERT INTO olala3w_online_daily VALUES('558','2016-07-14','1');
INSERT INTO olala3w_online_daily VALUES('559','2016-07-15','4');
INSERT INTO olala3w_online_daily VALUES('560','2016-07-18','67');
INSERT INTO olala3w_online_daily VALUES('561','2016-07-19','53');
INSERT INTO olala3w_online_daily VALUES('562','2016-07-20','16');
INSERT INTO olala3w_online_daily VALUES('563','2016-07-20','16');
INSERT INTO olala3w_online_daily VALUES('564','2016-07-21','14');
INSERT INTO olala3w_online_daily VALUES('565','2016-07-22','22');
INSERT INTO olala3w_online_daily VALUES('566','2016-07-23','27');
INSERT INTO olala3w_online_daily VALUES('567','2016-07-24','2');
INSERT INTO olala3w_online_daily VALUES('568','2016-07-25','44');
INSERT INTO olala3w_online_daily VALUES('569','2016-07-25','44');
INSERT INTO olala3w_online_daily VALUES('570','2016-07-26','38');
INSERT INTO olala3w_online_daily VALUES('571','2016-07-27','28');
INSERT INTO olala3w_online_daily VALUES('572','2016-07-28','24');
INSERT INTO olala3w_online_daily VALUES('573','2016-07-29','26');
INSERT INTO olala3w_online_daily VALUES('574','2016-07-30','17');
INSERT INTO olala3w_online_daily VALUES('575','2016-07-31','3');
INSERT INTO olala3w_online_daily VALUES('576','2016-08-01','58');
INSERT INTO olala3w_online_daily VALUES('577','2016-08-02','44');
INSERT INTO olala3w_online_daily VALUES('578','2016-08-03','73');
INSERT INTO olala3w_online_daily VALUES('579','2016-08-04','24');
INSERT INTO olala3w_online_daily VALUES('580','2016-08-05','25');
INSERT INTO olala3w_online_daily VALUES('581','2016-08-06','12');
INSERT INTO olala3w_online_daily VALUES('582','2016-08-08','40');
INSERT INTO olala3w_online_daily VALUES('583','2016-08-09','17');
INSERT INTO olala3w_online_daily VALUES('584','2016-08-10','33');
INSERT INTO olala3w_online_daily VALUES('585','2016-08-11','35');
INSERT INTO olala3w_online_daily VALUES('586','2016-08-12','29');
INSERT INTO olala3w_online_daily VALUES('587','2016-08-13','13');
INSERT INTO olala3w_online_daily VALUES('588','2016-08-15','19');
INSERT INTO olala3w_online_daily VALUES('589','2016-08-16','45');
INSERT INTO olala3w_online_daily VALUES('590','2016-08-17','25');
INSERT INTO olala3w_online_daily VALUES('591','2016-08-18','39');
INSERT INTO olala3w_online_daily VALUES('592','2016-08-19','10');
INSERT INTO olala3w_online_daily VALUES('593','2016-08-20','8');
INSERT INTO olala3w_online_daily VALUES('594','2016-08-21','6');
INSERT INTO olala3w_online_daily VALUES('595','2016-08-22','60');
INSERT INTO olala3w_online_daily VALUES('596','2016-08-23','45');
INSERT INTO olala3w_online_daily VALUES('597','2016-08-24','41');
INSERT INTO olala3w_online_daily VALUES('598','2016-08-25','27');
INSERT INTO olala3w_online_daily VALUES('599','2016-08-26','19');
INSERT INTO olala3w_online_daily VALUES('600','2016-08-27','28');
INSERT INTO olala3w_online_daily VALUES('601','2016-08-28','1');
INSERT INTO olala3w_online_daily VALUES('602','2016-08-29','58');
INSERT INTO olala3w_online_daily VALUES('603','2016-08-30','37');
INSERT INTO olala3w_online_daily VALUES('604','2016-08-31','57');
INSERT INTO olala3w_online_daily VALUES('605','2016-09-01','55');
INSERT INTO olala3w_online_daily VALUES('606','2016-09-03','33');
INSERT INTO olala3w_online_daily VALUES('607','2016-09-04','10');
INSERT INTO olala3w_online_daily VALUES('608','2016-09-05','71');
INSERT INTO olala3w_online_daily VALUES('609','2016-09-06','37');
INSERT INTO olala3w_online_daily VALUES('610','2016-09-07','35');
INSERT INTO olala3w_online_daily VALUES('611','2016-09-08','33');
INSERT INTO olala3w_online_daily VALUES('612','2016-09-09','29');
INSERT INTO olala3w_online_daily VALUES('613','2016-09-10','32');
INSERT INTO olala3w_online_daily VALUES('614','2016-09-11','5');
INSERT INTO olala3w_online_daily VALUES('615','2016-09-12','40');
INSERT INTO olala3w_online_daily VALUES('616','2016-09-13','35');
INSERT INTO olala3w_online_daily VALUES('617','2016-09-14','30');
INSERT INTO olala3w_online_daily VALUES('618','2016-09-15','33');
INSERT INTO olala3w_online_daily VALUES('619','2016-09-16','26');
INSERT INTO olala3w_online_daily VALUES('620','2016-09-17','18');
INSERT INTO olala3w_online_daily VALUES('621','2016-09-18','3');
INSERT INTO olala3w_online_daily VALUES('622','2016-09-19','42');
INSERT INTO olala3w_online_daily VALUES('623','2016-09-20','27');
INSERT INTO olala3w_online_daily VALUES('624','2016-09-21','52');
INSERT INTO olala3w_online_daily VALUES('625','2016-09-22','35');
INSERT INTO olala3w_online_daily VALUES('626','2016-09-23','45');
INSERT INTO olala3w_online_daily VALUES('627','2016-09-24','2');
INSERT INTO olala3w_online_daily VALUES('628','2016-09-26','1');
INSERT INTO olala3w_online_daily VALUES('629','2016-09-27','1');
INSERT INTO olala3w_online_daily VALUES('630','2016-09-27','1');
INSERT INTO olala3w_online_daily VALUES('631','2016-09-28','1');
INSERT INTO olala3w_online_daily VALUES('632','2016-11-01','3');
INSERT INTO olala3w_online_daily VALUES('633','2016-11-12','3');
INSERT INTO olala3w_online_daily VALUES('634','2016-11-14','2');
INSERT INTO olala3w_online_daily VALUES('635','2016-12-08','3');
INSERT INTO olala3w_online_daily VALUES('636','2016-12-09','3');
INSERT INTO olala3w_online_daily VALUES('637','2016-12-10','2');
INSERT INTO olala3w_online_daily VALUES('638','2016-12-15','4');
INSERT INTO olala3w_online_daily VALUES('639','2016-12-15','4');
INSERT INTO olala3w_online_daily VALUES('640','2016-12-16','1');
INSERT INTO olala3w_online_daily VALUES('641','2016-12-18','2');
INSERT INTO olala3w_online_daily VALUES('642','2016-12-24','1');
INSERT INTO olala3w_online_daily VALUES('643','2017-01-09','2');
INSERT INTO olala3w_online_daily VALUES('644','2017-01-13','2');
INSERT INTO olala3w_online_daily VALUES('645','2017-01-19','1');
INSERT INTO olala3w_online_daily VALUES('646','2017-02-07','1');
INSERT INTO olala3w_online_daily VALUES('647','2017-02-08','3');
INSERT INTO olala3w_online_daily VALUES('648','2017-02-14','4');
INSERT INTO olala3w_online_daily VALUES('649','2017-02-16','2');
INSERT INTO olala3w_online_daily VALUES('650','2017-02-21','2');
INSERT INTO olala3w_online_daily VALUES('651','2017-02-22','2');
INSERT INTO olala3w_online_daily VALUES('652','2017-02-23','1');
INSERT INTO olala3w_online_daily VALUES('653','2017-03-09','5');
INSERT INTO olala3w_online_daily VALUES('654','2017-03-09','5');
INSERT INTO olala3w_online_daily VALUES('655','2017-03-15','5');
INSERT INTO olala3w_online_daily VALUES('656','2017-05-03','12');
INSERT INTO olala3w_online_daily VALUES('657','2017-05-20','2');
INSERT INTO olala3w_online_daily VALUES('658','2017-05-23','11');
INSERT INTO olala3w_online_daily VALUES('659','2017-05-25','13');
INSERT INTO olala3w_online_daily VALUES('660','2017-06-28','2');
INSERT INTO olala3w_online_daily VALUES('661','2017-07-07','1');
INSERT INTO olala3w_online_daily VALUES('662','2017-08-01','197');
INSERT INTO olala3w_online_daily VALUES('663','2017-08-02','181');
INSERT INTO olala3w_online_daily VALUES('664','2017-08-03','958');
INSERT INTO olala3w_online_daily VALUES('665','2017-08-04','371');
INSERT INTO olala3w_online_daily VALUES('666','2017-08-05','123');
INSERT INTO olala3w_online_daily VALUES('667','2017-08-06','140');
INSERT INTO olala3w_online_daily VALUES('668','2017-08-07','271');
INSERT INTO olala3w_online_daily VALUES('669','2017-08-08','301');
INSERT INTO olala3w_online_daily VALUES('670','2017-08-09','174');
INSERT INTO olala3w_online_daily VALUES('671','2017-08-10','813');
INSERT INTO olala3w_online_daily VALUES('672','2017-08-11','1042');
INSERT INTO olala3w_online_daily VALUES('673','2017-08-12','248');
INSERT INTO olala3w_online_daily VALUES('674','2017-08-13','318');

-- --------------------------------------------------------

CREATE TABLE `olala3w_role_user` (
  `role_user_id` int(11) NOT NULL AUTO_INCREMENT,
  `role` int(11) NOT NULL DEFAULT '0',
  `user` int(11) NOT NULL DEFAULT '0',
  `created_time` int(11) NOT NULL DEFAULT '0',
  `created_user` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`role_user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=316 DEFAULT CHARSET=utf8;

INSERT INTO olala3w_role_user VALUES('62','1','1','1468833116','1');
INSERT INTO olala3w_role_user VALUES('186','64','1','1471425943','1');
INSERT INTO olala3w_role_user VALUES('292','61','64','1474453516','1');
INSERT INTO olala3w_role_user VALUES('293','61','63','1474453532','1');
INSERT INTO olala3w_role_user VALUES('294','67','52','1474453623','1');
INSERT INTO olala3w_role_user VALUES('295','59','80','1474453845','1');
INSERT INTO olala3w_role_user VALUES('296','67','80','1474453845','1');
INSERT INTO olala3w_role_user VALUES('297','67','97','1474453879','1');
INSERT INTO olala3w_role_user VALUES('298','61','72','1474605715','1');
INSERT INTO olala3w_role_user VALUES('299','67','72','1474605715','1');
INSERT INTO olala3w_role_user VALUES('300','51','53','1474609011','1');
INSERT INTO olala3w_role_user VALUES('301','68','52','1474609277','1');
INSERT INTO olala3w_role_user VALUES('302','68','55','1474609277','1');
INSERT INTO olala3w_role_user VALUES('303','68','57','1474609277','1');
INSERT INTO olala3w_role_user VALUES('304','68','61','1474609277','1');
INSERT INTO olala3w_role_user VALUES('305','68','71','1474609277','1');
INSERT INTO olala3w_role_user VALUES('306','68','99','1474609277','1');
INSERT INTO olala3w_role_user VALUES('311','69','58','1474609376','1');
INSERT INTO olala3w_role_user VALUES('312','69','80','1474609376','1');
INSERT INTO olala3w_role_user VALUES('313','69','84','1474609376','1');
INSERT INTO olala3w_role_user VALUES('314','69','97','1474609376','1');
INSERT INTO olala3w_role_user VALUES('315','1','2','1477963848','1');

-- --------------------------------------------------------

CREATE TABLE `olala3w_uploads_tmp` (
  `upload_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `status` int(1) NOT NULL DEFAULT '0',
  `list_img` text NOT NULL,
  `created_time` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`upload_id`)
) ENGINE=MyISAM AUTO_INCREMENT=839 DEFAULT CHARSET=utf8;


-- --------------------------------------------------------

