If you want to add an example file in the language of your choice feel free to send a pull request.
